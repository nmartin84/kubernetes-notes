<!--
SYNC IMPACT REPORT
==================
Version change: 1.5.0 -> 1.6.0
Bump rationale: MINOR - strengthens syntax-bearing note requirements for code rendering.
  Code syntax must be written in fenced code blocks, preferably with an info string, and
  generated HTML must render code with themed styling, line-number support, and a monospace
  font.

Prior - Version change: 1.4.0 -> 1.5.0
Prior rationale: MINOR - expands note content standards for syntax-bearing subjects.
  Notes about code, math, CLI commands, configuration, query languages, formulas, or any
  other syntax-governed system must include the relevant concrete syntax, examples,
  commands, formulas, or usage details needed to make the concept operational.

Prior - Version change: 1.3.0 -> 1.4.0
Prior rationale: MINOR - adds a default-ingestion workflow rule. User input is treated as
  source material for the knowledge management system unless the user explicitly says not
  to add it, asks for source-code work, or otherwise frames the request as repository/code
  maintenance rather than knowledge capture.

Prior - Version change: 1.2.0 -> 1.3.0
Prior rationale: MINOR - adds a binding PII minimization requirement for generated notes.
  Notes must omit or generalize personally identifying information unless it is directly
  cited or comes from a published public article, and even then only the minimum relevant
  identifying detail may be included.

Prior - Version change: 1.1.0 -> 1.2.0
Prior rationale: MINOR - (a) Principle V no longer mandates Mermaid; the agent chooses any
  self-contained, offline visual form (inline SVG preferred). (b) Principle IV/Workflow now
  produce HTML via a single repeatable generation command the agent runs after note changes
  (a small generator script is the only executable artifact). No principle removed.

Prior - Version change: 1.0.1 -> 1.1.0
Prior rationale: MINOR - moved to an AI-operated model (no app/CLI); HTML became an
  AI-authored, faithful-not-deterministic rendering.

Prior - Version change: 1.0.0 -> 1.0.1
Prior rationale: PATCH - named Mermaid as the RECOMMENDED default diagram format.

Prior - Version change: TEMPLATE (unratified) -> 1.0.0
Prior rationale: Initial ratification - first concrete constitution replacing the
  placeholder template. MAJOR baseline established.

Modified principles: (none)

Added principles: (none)

Added sections: (none)

Modified sections:
  - Note Anatomy & Content Standards - code syntax examples must use fenced code blocks;
    generated HTML must style code with line numbers and a monospace font.
  - Authoring & Generation Workflow - note review must confirm fenced code rendering for
    code syntax examples.

Removed sections: (none)

Templates requiring updates:
  - .specify/templates/plan-template.md - no change needed (Constitution Check derives
    gates generically from this file)
  - .specify/templates/spec-template.md - no change needed (no principle-specific mandatory
    sections introduced)
  - .specify/templates/tasks-template.md - no change needed (task categories remain
    compatible; syntax review fits existing note authoring tasks)
  - templates/note.html.j2 - updated to add line-number markup to rendered code blocks
  - assets/styles.css - updated to style fenced code blocks and line numbers

Follow-up TODOs: (none)
-->

# Knowledge Management (km) Constitution

## Core Principles

### I. Atomic Notes (Zettelkasten)

Every note MUST capture exactly one concept, idea, or claim Ã¢â‚¬â€ the smallest unit of
knowledge that stands on its own. A note that requires the reader to hold two
unrelated ideas in mind MUST be split. Each note MUST carry a stable, unique
identifier that never changes once assigned, so links remain durable as titles and
content evolve. Atomicity is what makes knowledge composable: small, single-purpose
notes can be linked, reused, and recombined without ambiguity.

### II. Accuracy & Source Integrity (NON-NEGOTIABLE)

Accuracy is the primary purpose of this repository and overrides convenience.
Every factual claim MUST be traceable to a cited source or be explicitly marked as
the author's own synthesis or opinion. Unverified or uncertain statements MUST be
labelled as such (e.g. `status: unverified`) rather than asserted as fact. A note
MUST NOT silently mix sourced fact with speculation.

Generated notes MUST minimize personally identifying information (PII). PII includes
names of private individuals, contact details, addresses, precise locations, account
identifiers, employer or school details, biometric or image identifiers, and uniquely
identifying life details. The agent MUST omit, anonymize, or generalize PII unless the
specific identifying detail is directly cited to a source or comes from a published,
public article used as a source for the note. Even when PII is allowed by this rule,
the note MUST include only the minimum identifying detail needed for the note's concept
and MUST NOT add uncited private context.

When a source is later found to contradict a note, the note MUST be corrected and the
change recorded - knowledge in this repository is expected to converge toward truth,
not accumulate errors.

### III. Connected Knowledge (PKM Linking)

A note in isolation is incomplete. Every note MUST include an explicit Relations
section that names its connections to other notes in the repository, using the stable
identifiers from Principle I. Links MUST be typed where the relationship is meaningful
(e.g. `extends`, `contradicts`, `example-of`, `prerequisite-of`) rather than left as
bare references. New notes SHOULD be linked to at least one existing note so the graph
stays connected; orphan notes are permitted only when genuinely no relationship exists,
and that absence SHOULD be noted. Links are first-class content, not decoration.

### IV. Markdown Source of Truth, HTML as Derivative

Markdown is the single canonical store of all knowledge. HTML files are derivative
renderings produced from the Markdown notes by a single, repeatable generation command,
which the agent runs after creating or updating notes. HTML MUST NOT be hand-edited as a
means of changing a note's content, and no knowledge may live only in HTML. Generated
pages are disposable: they can be deleted and rebuilt from the Markdown at any time, and
each MUST faithfully reflect its note's current source. Because notes may include
agent-authored visual content, byte-for-byte reproducibility is not the goal; faithful,
regenerable correspondence to the source is.

### V. Visual Illustration

Each note MUST include a visual representation of its concept where one can meaningfully
aid understanding Ã¢â‚¬â€ a diagram, graph, relationship map, illustration, or equivalent. The
agent chooses whatever form best fits the concept; no specific diagram tool is mandated.
Visuals SHOULD be authored in self-contained, version-controllable formats that render
offline without external services (inline SVG is preferred; static images or other
embeddable markup are acceptable). The visual lives alongside the Markdown in the note
source and is embedded into the note's HTML by the generation command. A note whose
concept is genuinely non-visual MAY substitute a structured summary, but the default
expectation is a visual aid.

## Note Anatomy & Content Standards

Beyond its core idea, every atomic note MUST retain the following, expressed in
Markdown front matter and body:

- **Identifier**: a stable, unique ID (Principle I), assigned once and never reused.
- **Title**: a concise, declarative statement of the single idea.
- **Core idea**: the atomic concept stated plainly, in the author's own words.
- **Elaboration / context**: the supporting explanation, conditions, and boundaries
  that make the idea precise Ã¢â‚¬â€ kept to this one concept only.
- **Syntax / examples**: when the note concerns code, math, CLI commands,
  configuration, query languages, formulas, APIs, markup, protocols, or any other
  syntax-governed system, the note MUST include the relevant concrete syntax,
  commands, formulas, code snippets, or usage examples needed to make the concept
  operational. Code syntax MUST be enclosed in fenced code blocks with an appropriate
  language or format info string when one applies (for example, `python`, `sql`,
  `bash`, `yaml`, or `json`). Generated HTML MUST render fenced code blocks with
  themed styling, line-number support, and a monospace font. These details MUST be
  precise enough to distinguish valid usage from nearby invalid or misleading usage.
- **Relations**: typed links to other notes (Principle III).
- **Visualization**: an embedded or referenced visual aid (Principle V).
- **Sources / references**: citations backing every factual claim (Principle II).
- **Metadata**: at minimum created date, last-updated date, tags, and a verification
  status; dates MUST be ISO 8601 (YYYY-MM-DD).

Notes MUST be written to be understood independently; necessary context is summarized
in the note rather than assumed from neighbouring notes.

## Authoring & Generation Workflow

- New knowledge enters as Markdown notes conforming to the Note Anatomy above.
- User input is presumed to be source material for the knowledge management system. Unless
  the user explicitly says not to add it, labels it as non-ingestion context, asks for
  source-code work, or requests updates to repository/application code, the agent SHOULD
  interpret the input as material to normalize into notes, link into the graph, and
  regenerate into the site under this workflow.
- The system is operated by an AI agent acting directly on the repository: it authors and
  links notes from the user's input, then runs a single, repeatable generation command to
  (re)build the HTML site. The only executable artifact is this generation command/script Ã¢â‚¬â€
  there is no larger application or interactive CLI.
- HTML and visual outputs are produced from the Markdown by the generation command and are
  never hand-edited to change content; each page MUST faithfully reflect its current
  Markdown source.
- Adding or editing a note MUST also update affected Relations on both ends so the
  knowledge graph stays bidirectionally consistent.
- Before a note is considered complete it MUST pass a review confirming: atomicity,
  cited or labelled claims, PII omitted/generalized unless permitted by Principle II,
  syntax-bearing topics include concrete syntax/examples, code syntax examples use fenced
  code blocks that render with line-number support, at least one relation (or a justified
  orphan), a visual aid (or justified exception), and required metadata present.
## Governance

This constitution supersedes other authoring conventions in this repository. Where a
practice conflicts with a principle here, the principle wins.

- **Amendments**: Changes to this document MUST be proposed with a written rationale,
  recorded in the Sync Impact Report at the top of this file, and accompanied by any
  needed updates to dependent templates and notes.
- **Versioning**: This document follows semantic versioning. MAJOR for backward-
  incompatible principle removals or redefinitions; MINOR for new principles or
  materially expanded guidance; PATCH for clarifications and non-semantic refinements.
- **Compliance review**: Note reviews (see Authoring & Generation Workflow) MUST verify
  conformance to these principles. Deviations MUST be justified in writing or corrected
  before the note is accepted.

**Version**: 1.6.0 | **Ratified**: 2026-06-25 | **Last Amended**: 2026-06-25
