<!-- SPECKIT START -->
For additional context about technologies to be used, project structure,
shell commands, and other important information, read the current plan:
`specs/001-core-knowledge-system/plan.md`

Active feature: Core Knowledge System (001). Hybrid model: an AI agent authors content and
a small generator builds the site. The user dumps knowledge + keywords (or scratch notes)
in a prompt; the agent mints atomic Zettelkasten notes as Markdown, links them into the
existing graph via typed relations (written on BOTH ends), and gives each note a
self-contained visualization of its choosing (inline SVG preferred — NOT a mandated tool).
After authoring, the agent runs `python generate.py` to (re)build the styled `site/`: one
HTML page per note with a modern look, the embedded visual, and an interactive Cytoscape
connection graph in the TOP-RIGHT corner (vendored, offline) that clicks through to related
notes. `notes/<id>-slug.md` is canonical; `site/` is disposable and rebuilt by the
generator. Stable ids are `YYYYMMDDHHMMSS`. Deliverables: `generate.py` (the only
executable artifact) + `templates/*.j2` + `assets/` (styles.css, vendored cytoscape.min.js),
plus guidance `AGENTS.md` (playbook) and `CONVENTIONS.md` (ids, relation vocabulary +
inverses, sourcing/verification, tags). Accuracy is non-negotiable: cite or label every
claim; never assert unverified info as fact. See plan.md, research.md, data-model.md,
contracts/, quickstart.md.
<!-- SPECKIT END -->
