/* Initializes the connection graph from the embedded #graph-data JSON.
   Used by both note pages (local neighbourhood) and the index (full graph).
   Clicking a node navigates to that note's page. Offline; needs cytoscape.min.js. */
(function () {
  var dataEl = document.getElementById("graph-data");
  var container = document.getElementById("graph");
  if (!dataEl || !container || typeof cytoscape === "undefined") return;

  var data;
  try { data = JSON.parse(dataEl.textContent); } catch (e) { return; }
  if (!data.elements || !data.elements.length) {
    container.innerHTML = '<p class="graph-empty">No connections yet</p>';
    return;
  }

  // Lay out after node sizes are set so spacing accounts for the real
  // (degree-scaled) node dimensions.
  var coseLayout = {
    name: "cose",
    animate: false,
    // Generous fit padding keeps the cluster compact and centred in the wide
    // panel instead of stretching to the edges.
    padding: 90,
    // Account for label boxes so nodes don't overlap their own text.
    nodeDimensionsIncludeLabels: true,
    // Enough repulsion to avoid overlap, but short edges so connected notes
    // stay close rather than flung apart.
    nodeRepulsion: 18000,
    idealEdgeLength: 80,
    edgeElasticity: 100,
    nestingFactor: 1.2,
    gravity: 0.3,
    componentSpacing: 80,
    nodeOverlap: 20,
    randomize: true,
    fit: true
  };

  var cy = cytoscape({
    container: container,
    elements: data.elements,
    wheelSensitivity: 0.2,
    style: [
      {
        selector: "node",
        style: {
          "background-color": "#6366f1",
          "label": "data(label)",
          "font-size": "11px",
          "color": "#dbe3f0",
          "text-wrap": "wrap",
          "text-max-width": "120px",
          "text-valign": "bottom",
          "text-margin-y": 4,
          // Size scales with connection count (see sizing pass below).
          "width": "mapData(deg, 0, 1, 16, 52)",
          "height": "mapData(deg, 0, 1, 16, 52)"
        }
      },
      {
        selector: "node[?current]",
        style: { "background-color": "#f472b6", "color": "#f8fafc", "font-weight": "bold" }
      },
      {
        selector: "edge",
        style: {
          "width": 1.5,
          "line-color": "#475569",
          "target-arrow-color": "#475569",
          "target-arrow-shape": "triangle",
          "arrow-scale": 0.8,
          "curve-style": "bezier",
          "label": "data(label)",
          "font-size": "7px",
          "color": "#7c8aa5",
          "text-rotation": "autorotate",
          "text-background-color": "#0b1220",
          "text-background-opacity": 0.85,
          "text-background-padding": 1
        }
      }
    ]
  });

  // Record each node's connection count as `deg`, normalised 0..1 against the
  // most-connected node, then re-point the size mapData at that range so the
  // busiest hubs render largest. Done before layout so spacing is correct.
  var maxDeg = 1;
  cy.nodes().forEach(function (n) { maxDeg = Math.max(maxDeg, n.degree(false)); });
  cy.batch(function () {
    cy.nodes().forEach(function (n) { n.data("deg", n.degree(false) / maxDeg); });
  });

  cy.layout(coseLayout).run();

  cy.on("tap", "node", function (evt) {
    var url = evt.target.data("url");
    if (url) window.location.href = url;
  });
  cy.nodes().forEach(function (n) { if (n.data("url")) n.style("cursor", "pointer"); });
})();
