#!/usr/bin/env python3
"""Generate the static knowledge site from notes/*.md.

Reads each Markdown note (YAML front matter + body), renders it to a styled HTML page
under site/, builds an index, computes connection-graph data for the top-right graph view,
and copies assets. Markdown is canonical; site/ is disposable and fully rebuilt each run.

Usage:
    python generate.py
"""
from __future__ import annotations

import json
import re
import shutil
import sys
from pathlib import Path

import yaml
import markdown
from jinja2 import Environment, FileSystemLoader, select_autoescape

ROOT = Path(__file__).resolve().parent
NOTES_DIR = ROOT / "notes"
SITE_DIR = ROOT / "site"
TEMPLATES_DIR = ROOT / "templates"
ASSETS_DIR = ROOT / "assets"

ASSET_FILES = ["styles.css", "cytoscape.min.js", "graph.js"]

FM_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n?(.*)$", re.S)


def pop_section(body: str, name: str):
    """Remove a `## <name>` section; return (inner_text_or_None, remaining_body)."""
    m = re.search(rf"(?ms)^##\s+{re.escape(name)}\s*$\n(.*?)(?=^##\s+|\Z)", body)
    if not m:
        return None, body
    return m.group(1).strip(), body[: m.start()] + body[m.end():]


def enrich_source_footnotes(sources_inner: str, meta: dict) -> str:
    """Append frontmatter source URLs to matching Markdown footnote definitions."""
    source_urls = {
        str(s.get("id", "")).strip(): str(s.get("url", "")).strip()
        for s in (meta.get("sources") or [])
        if str(s.get("id", "")).strip() and str(s.get("url", "")).strip()
    }
    if not source_urls:
        return sources_inner

    def add_link(match: re.Match) -> str:
        source_id = match.group(1)
        source_text = match.group(2).rstrip()
        url = source_urls.get(source_id)
        if not url or "http://" in source_text or "https://" in source_text:
            return match.group(0)
        return f"[^{source_id}]: {source_text} [Source](<{url}>)"

    return re.sub(r"(?m)^\[\^([^\]]+)\]:(.*)$", add_link, sources_inner)


def parse_note(path: Path) -> dict:
    raw = path.read_text(encoding="utf-8")
    m = FM_RE.match(raw)
    if not m:
        raise ValueError(f"{path.name}: missing or malformed YAML front matter")
    meta = yaml.safe_load(m.group(1)) or {}
    meta["slug"] = path.stem
    meta["body"] = m.group(2)
    meta["id"] = str(meta.get("id", "")).strip()
    if not meta["id"]:
        raise ValueError(f"{path.name}: missing id")
    return meta


def render_body(meta: dict):
    """Return (main_html, visualization_html, viz_alt)."""
    body = meta["body"]
    viz_inner, body = pop_section(body, "Visualization")
    _, body = pop_section(body, "Connections")        # rendered from front matter instead
    sources_inner, body = pop_section(body, "Sources")  # keep footnote defs, drop heading
    if sources_inner:
        sources_inner = enrich_source_footnotes(sources_inner, meta)
        body = body.rstrip() + "\n\n" + sources_inner + "\n"

    md = markdown.Markdown(extensions=["footnotes", "tables", "fenced_code"])
    main_html = md.convert(body)

    viz = meta.get("visualization") or {}
    kind = viz.get("kind")
    if kind in ("svg", "html"):
        viz_html = viz_inner or ""
    elif kind == "image":
        viz_html = f'<img src="{viz.get("src", "")}" alt="{viz.get("alt", "")}">'
    elif kind == "summary":
        viz_html = markdown.markdown(viz_inner or "")
    else:
        viz_html = viz_inner or ""
    return main_html, viz_html, viz.get("alt", "")


def short_label(meta: dict) -> str:
    """Condensed label for graph nodes: explicit `short_title`, else derived from slug."""
    st = (meta.get("short_title") or "").strip()
    if st:
        return st
    m = re.match(r"^\d+[-_]?(.*)$", meta["slug"])
    base = (m.group(1) if m else meta["slug"]).replace("-", " ").replace("_", " ").strip()
    return (base[:1].upper() + base[1:]) if base else meta["slug"]


def build() -> int:
    if not NOTES_DIR.exists():
        sys.exit("notes/ directory not found")

    notes = [parse_note(p) for p in sorted(NOTES_DIR.glob("*.md"))]
    index = {n["id"]: n for n in notes}
    warnings: list[str] = []

    env = Environment(
        loader=FileSystemLoader(str(TEMPLATES_DIR)),
        autoescape=select_autoescape(["html", "j2"]),
    )
    note_tpl = env.get_template("note.html.j2")
    index_tpl = env.get_template("index.html.j2")

    def note_view(m: dict) -> dict:
        return {"id": m["id"], "title": m["title"], "slug": m["slug"],
                "verification_status": m.get("verification_status"),
                "tags": m.get("tags") or []}

    def parent_of(m: dict) -> str:
        explicit = (m.get("parent_tag") or "").strip()
        if explicit:
            return explicit
        tags = m.get("tags") or []
        return tags[0] if tags else "untagged"

    parent_map: dict[str, list] = {}
    for n in notes:
        parent_map.setdefault(parent_of(n), []).append(n)

    by_count_then_name = lambda mapping: lambda k: (-len(mapping[k]), k)

    groups = []
    for parent in sorted(parent_map, key=by_count_then_name(parent_map)):
        members = sorted(parent_map[parent], key=lambda m: m["title"].lower())
        # related tags = every tag on these notes except the parent itself
        rel_map: dict[str, list] = {}
        for m in members:
            for t in (m.get("tags") or []):
                if t != parent:
                    rel_map.setdefault(t, []).append(m)
        related = []
        for t in sorted(rel_map, key=by_count_then_name(rel_map)):
            rmembers = sorted(rel_map[t], key=lambda m: m["title"].lower())
            related.append({"tag": t, "count": len(rmembers),
                            "notes": [note_view(m) for m in rmembers]})
        groups.append({
            "tag": parent, "count": len(members),
            "notes": [note_view(m) for m in members],
            "related": related,
        })

    if SITE_DIR.exists():
        shutil.rmtree(SITE_DIR)
    (SITE_DIR / "assets").mkdir(parents=True)

    # ---- per-note pages ----
    for n in notes:
        main_html, viz_html, viz_alt = render_body(n)

        rels = []
        nodes = {n["id"]: {"id": n["id"], "label": short_label(n),
                           "url": f"{n['slug']}.html", "current": True}}
        edges = []
        for i, r in enumerate(n.get("relations") or []):
            tgt = str(r.get("target"))
            tnote = index.get(tgt)
            if tnote:
                url, title, tshort = f"{tnote['slug']}.html", tnote["title"], short_label(tnote)
            else:
                url, title, tshort = None, None, f"{tgt} (missing)"
                warnings.append(f"{n['slug']}: dangling relation -> {tgt}")
            rels.append({"type": r.get("type"), "target": tgt,
                         "url": url, "title": title or f"{tgt} (missing)"})
            nodes.setdefault(tgt, {"id": tgt, "label": tshort,
                                   "url": url, "current": False})
            edges.append({"id": f"e{i}", "source": n["id"], "target": tgt,
                          "label": r.get("type")})

        if not (n.get("relations") or []):
            warnings.append(f"{n['slug']}: orphan (no relations)")

        elements = [{"data": d} for d in nodes.values()] + [{"data": e} for e in edges]
        html = note_tpl.render(note={
            "id": n["id"], "title": n["title"], "slug": n["slug"],
            "tags": n.get("tags") or [],
            "created": n.get("created"), "updated": n.get("updated"),
            "verification_status": n.get("verification_status"),
            "main_html": main_html, "visualization_html": viz_html, "viz_alt": viz_alt,
            "relations": rels, "graph_json": json.dumps({"elements": elements}),
        }, groups=groups)
        (SITE_DIR / f"{n['slug']}.html").write_text(html, encoding="utf-8")

    # ---- index + full graph ----
    full_nodes = {n["id"]: {"id": n["id"], "label": short_label(n),
                            "url": f"{n['slug']}.html", "current": False} for n in notes}
    full_edges, seen = [], set()
    for n in notes:
        for r in (n.get("relations") or []):
            a, b = n["id"], str(r.get("target"))
            if b not in full_nodes or frozenset((a, b)) in seen:
                continue
            seen.add(frozenset((a, b)))
            full_edges.append({"id": f"fe{len(full_edges)}", "source": a,
                               "target": b, "label": r.get("type")})
    full_elements = [{"data": d} for d in full_nodes.values()] + \
                    [{"data": e} for e in full_edges]

    all_tags = {t for n in notes for t in (n.get("tags") or ["untagged"])}

    index_html = index_tpl.render(
        groups=groups,
        total=len(notes),
        tag_count=len(all_tags),
        graph_json=json.dumps({"elements": full_elements}),
    )
    (SITE_DIR / "index.html").write_text(index_html, encoding="utf-8")

    # ---- assets ----
    for f in ASSET_FILES:
        src = ASSETS_DIR / f
        if not src.exists():
            warnings.append(f"missing asset: {f}")
            continue
        shutil.copy(src, SITE_DIR / "assets" / f)

    print(f"Generated {len(notes)} note page(s) + index into {SITE_DIR}/")
    if warnings:
        print("\nNotices:")
        for w in sorted(set(warnings)):
            print(f"  - {w}")
    return 0
if __name__ == "__main__":
    raise SystemExit(build())
