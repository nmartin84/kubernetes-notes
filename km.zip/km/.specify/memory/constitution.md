<!--
SYNC IMPACT REPORT
==================
Version change: 1.1.0 → 1.2.0
Bump rationale: MINOR — (a) Principle V no longer mandates Mermaid; the agent chooses any
  self-contained, offline visual form (inline SVG preferred). (b) Principle IV/Workflow now
  produce HTML via a single repeatable generation command the agent runs after note changes
  (a small generator script is the only executable artifact). No principle removed.

Prior — Version change: 1.1.0 → 1.2.0 superseded the following:
Prior — Version change: 1.0.1 → 1.1.0
Prior rationale: MINOR — moved to an AI-operated model (no app/CLI); HTML became an
  AI-authored, faithful-not-deterministic rendering.

Prior — Version change: 1.0.0 → 1.0.1
Prior rationale: PATCH — named Mermaid as the RECOMMENDED default diagram format.

Prior — Version change: TEMPLATE (unratified) → 1.0.0
Prior rationale: Initial ratification — first concrete constitution replacing the
  placeholder template. MAJOR baseline established.

Modified principles: (none — initial definition)
Added principles:
  - I. Atomic Notes (Zettelkasten)
  - II. Accuracy & Source Integrity (NON-NEGOTIABLE)
  - III. Connected Knowledge (PKM Linking)
  - IV. Markdown Source of Truth, HTML as Derivative
  - V. Visual Illustration

Added sections:
  - Note Anatomy & Content Standards
  - Authoring & Generation Workflow
  - Governance

Removed sections: (none)

Templates requiring updates:
  - .specify/templates/plan-template.md ✅ no change needed (Constitution Check
    derives gates generically from this file)
  - .specify/templates/spec-template.md ✅ no change needed (no principle-specific
    mandatory sections introduced)
  - .specify/templates/tasks-template.md ✅ no change needed (task categories remain
    compatible; visualization/HTML-generation tasks fit existing categories)

Follow-up TODOs: (none)
-->

# Knowledge Management (km) Constitution

## Core Principles

### I. Atomic Notes (Zettelkasten)

Every note MUST capture exactly one concept, idea, or claim — the smallest unit of
knowledge that stands on its own. A note that requires the reader to hold two
unrelated ideas in mind MUST be split. Each note MUST carry a stable, unique
identifier that never changes once assigned, so links remain durable as titles and
content evolve. Atomicity is what makes knowledge composable: small, single-purpose
notes can be linked, reused, and recombined without ambiguity.

### II. Accuracy & Source Integrity (NON-NEGOTIABLE)

Accuracy is the primary purpose of this repository and overrides convenience.
Every factual claim MUST be traceable to a cited source or be explicitly marked as
the author's own synthesis or opinion. Unverified or uncertain statements MUST be
labelled as such (e.g. `status: unverified`) rather than asserted as fact. A note
MUST NOT silently mix sourced fact with speculation. When a source is later found to
contradict a note, the note MUST be corrected and the change recorded — knowledge in
this repository is expected to converge toward truth, not accumulate errors.

### III. Connected Knowledge (PKM Linking)

A note in isolation is incomplete. Every note MUST include an explicit Relations
section that names its connections to other notes in the repository, using the stable
identifiers from Principle I. Links MUST be typed where the relationship is meaningful
(e.g. `extends`, `contradicts`, `example-of`, `prerequisite-of`) rather than left as
bare references. New notes SHOULD be linked to at least one existing note so the graph
stays connected; orphan notes are permitted only when genuinely no relationship exists,
and that absence SHOULD be noted. Links are first-class content, not decoration.

### IV. Markdown Source of Truth, HTML as Derivative

Markdown is the single canonical store of all knowledge. HTML files are derivative
renderings produced from the Markdown notes by a single, repeatable generation command,
which the agent runs after creating or updating notes. HTML MUST NOT be hand-edited as a
means of changing a note's content, and no knowledge may live only in HTML. Generated
pages are disposable: they can be deleted and rebuilt from the Markdown at any time, and
each MUST faithfully reflect its note's current source. Because notes may include
agent-authored visual content, byte-for-byte reproducibility is not the goal; faithful,
regenerable correspondence to the source is.

### V. Visual Illustration

Each note MUST include a visual representation of its concept where one can meaningfully
aid understanding — a diagram, graph, relationship map, illustration, or equivalent. The
agent chooses whatever form best fits the concept; no specific diagram tool is mandated.
Visuals SHOULD be authored in self-contained, version-controllable formats that render
offline without external services (inline SVG is preferred; static images or other
embeddable markup are acceptable). The visual lives alongside the Markdown in the note
source and is embedded into the note's HTML by the generation command. A note whose
concept is genuinely non-visual MAY substitute a structured summary, but the default
expectation is a visual aid.

## Note Anatomy & Content Standards

Beyond its core idea, every atomic note MUST retain the following, expressed in
Markdown front matter and body:

- **Identifier**: a stable, unique ID (Principle I), assigned once and never reused.
- **Title**: a concise, declarative statement of the single idea.
- **Core idea**: the atomic concept stated plainly, in the author's own words.
- **Elaboration / context**: the supporting explanation, conditions, and boundaries
  that make the idea precise — kept to this one concept only.
- **Relations**: typed links to other notes (Principle III).
- **Visualization**: an embedded or referenced visual aid (Principle V).
- **Sources / references**: citations backing every factual claim (Principle II).
- **Metadata**: at minimum created date, last-updated date, tags, and a verification
  status; dates MUST be ISO 8601 (YYYY-MM-DD).

Notes MUST be written to be understood independently; necessary context is summarized
in the note rather than assumed from neighbouring notes.

## Authoring & Generation Workflow

- New knowledge enters as Markdown notes conforming to the Note Anatomy above.
- The system is operated by an AI agent acting directly on the repository: it authors and
  links notes from the user's input, then runs a single, repeatable generation command to
  (re)build the HTML site. The only executable artifact is this generation command/script —
  there is no larger application or interactive CLI.
- HTML and visual outputs are produced from the Markdown by the generation command and are
  never hand-edited to change content; each page MUST faithfully reflect its current
  Markdown source.
- Adding or editing a note MUST also update affected Relations on both ends so the
  knowledge graph stays bidirectionally consistent.
- Before a note is considered complete it MUST pass a review confirming: atomicity,
  cited or labelled claims, at least one relation (or a justified orphan), a visual aid
  (or justified exception), and required metadata present.

## Governance

This constitution supersedes other authoring conventions in this repository. Where a
practice conflicts with a principle here, the principle wins.

- **Amendments**: Changes to this document MUST be proposed with a written rationale,
  recorded in the Sync Impact Report at the top of this file, and accompanied by any
  needed updates to dependent templates and notes.
- **Versioning**: This document follows semantic versioning. MAJOR for backward-
  incompatible principle removals or redefinitions; MINOR for new principles or
  materially expanded guidance; PATCH for clarifications and non-semantic refinements.
- **Compliance review**: Note reviews (see Authoring & Generation Workflow) MUST verify
  conformance to these principles. Deviations MUST be justified in writing or corrected
  before the note is accepted.

**Version**: 1.2.0 | **Ratified**: 2026-06-25 | **Last Amended**: 2026-06-25
