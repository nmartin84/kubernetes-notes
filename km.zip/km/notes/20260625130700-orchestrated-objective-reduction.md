---
id: "20260625130700"
title: "Orch-OR proposes that orchestrated quantum reductions in microtubules contribute to consciousness"
short_title: "Orch-OR"
tags: [consciousness, quantum-theory, neuroscience, microtubules, orch-or]
parent_tag: consciousness
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: hameroffpenrose2014
    citation: "Hameroff, S. & Penrose, R. - Consciousness in the universe: A review of the 'Orch OR' theory, Physics of Life Reviews 11, 39-78 (2014)"
    url: "https://doi.org/10.1016/j.plrev.2013.08.002"
  - id: tegmark2000
    citation: "Tegmark, M. - Importance of quantum decoherence in brain processes, Physical Review E 61, 4194-4206 (2000)"
    url: "https://doi.org/10.1103/PhysRevE.61.4194"
relations:
  - { type: related, target: "20260625130000" }
  - { type: related, target: "20260625130200" }
  - { type: related, target: "20260625130500" }
  - { type: requires, target: "20260625130600" }
  - { type: contradicts, target: "20260625130800" }
visualization:
  kind: svg
  alt: "Microtubules inside a neuron are shown as the proposed site of orchestrated quantum states that undergo objective reduction and are linked to conscious moments."
---

## Core idea

Orchestrated objective reduction, or Orch-OR, proposes that quantum states in neuronal
microtubules are organized by biological processes and undergo objective reductions that
contribute to conscious moments [^hameroffpenrose2014].

## Elaboration

The theory combines two claims: Penrose-style objective reduction supplies a physical
collapse event, and microtubules inside neurons supply a biological structure where those
events are proposed to be orchestrated [^hameroffpenrose2014]. Orch-OR is one of the best
known quantum-consciousness theories, but it is controversial. A major criticism is that
warm, wet brain tissue should decohere quantum states too quickly for the proposed neural
role, a challenge associated especially with Tegmark's 2000 estimate [^tegmark2000].

## Visualization

<svg viewBox="0 0 640 320" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Orch-OR microtubule proposal">
  <defs><marker id="ooa" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="320" fill="#0b1220"/>
  <path d="M64 196 C118 76, 232 50, 324 92 C410 132, 446 220, 570 168" fill="none" stroke="#475569" stroke-width="18" stroke-linecap="round"/>
  <path d="M92 190 C146 102, 232 86, 310 116 C390 146, 424 206, 548 174" fill="none" stroke="#111c33" stroke-width="42" stroke-linecap="round"/>
  <g fill="#6366f1" stroke="#a5b4fc" stroke-width="1">
    <circle cx="145" cy="150" r="13"/><circle cx="176" cy="133" r="13"/><circle cx="207" cy="122" r="13"/>
    <circle cx="238" cy="119" r="13"/><circle cx="269" cy="125" r="13"/><circle cx="300" cy="138" r="13"/>
    <circle cx="331" cy="154" r="13"/><circle cx="362" cy="171" r="13"/><circle cx="393" cy="185" r="13"/>
    <circle cx="424" cy="191" r="13"/><circle cx="455" cy="189" r="13"/>
  </g>
  <rect x="204" y="236" width="132" height="44" rx="8" fill="#1d2a4d" stroke="#6366f1"/>
  <text x="270" y="263" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">orchestration</text>
  <rect x="398" y="236" width="132" height="44" rx="8" fill="#102a1b" stroke="#22c55e"/>
  <text x="464" y="263" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">OR event</text>
  <line x1="318" y1="236" x2="395" y2="258" stroke="#94a3b8" stroke-width="2" marker-end="url(#ooa)"/>
  <text x="320" y="40" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">proposed quantum processing in microtubules</text>
</svg>

## Connections

- It is `related` to **quantum superposition** (20260625130000).
- It is `related` to **consciousness-caused collapse** (20260625130200).
- It is `related` to the **hard problem of consciousness** (20260625130500).
- It `requires` **objective reduction** (20260625130600).
- It `contradicts` **Tegmark's brain decoherence critique** (20260625130800).

## Sources

[^hameroffpenrose2014]: Hameroff & Penrose, "Consciousness in the universe" (2014).
[^tegmark2000]: Tegmark, "Importance of quantum decoherence in brain processes" (2000).
