---
id: "20260625120200"
title: "The Schwarzschild radius sets the size of a non-rotating black hole's event horizon"
tags: [astronomy, black-holes, general-relativity, mathematics]
parent_tag: black-holes
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: schwarzschild1916
    citation: "Schwarzschild, K. (1916), 'Über das Gravitationsfeld eines Massenpunktes nach der Einsteinschen Theorie', Sitzungsber. Preuss. Akad. Wiss."
  - id: mtw1973
    citation: "Misner, C. W., Thorne, K. S., & Wheeler, J. A. — Gravitation (W. H. Freeman, 1973)"
relations:
  - { type: prerequisite-of, target: "20260625120100" }
visualization:
  kind: svg
  alt: "Mass M feeds the formula r_s = 2GM/c², which yields the horizon radius; worked examples give the Sun ≈ 2.95 km and Earth ≈ 8.9 mm."
---

## Core idea

The Schwarzschild radius is the distance from the centre at which the event horizon of a
non-rotating, uncharged black hole forms, given by r_s = 2GM/c² — proportional to the
object's mass [^schwarzschild1916].

## Elaboration

Derived from Karl Schwarzschild's 1916 exact solution to Einstein's field equations, the
radius scales linearly with mass: compress any mass inside its Schwarzschild radius and it
becomes a black hole. The Sun's Schwarzschild radius is about 2.95 km; Earth's is about
8.9 mm. The formula is exact only for a spherically symmetric, non-spinning mass; rotating
(Kerr) black holes have a smaller horizon for the same mass [^mtw1973].

## Visualization

<svg viewBox="0 0 640 220" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Mass into the Schwarzschild radius formula yields the horizon radius">
  <defs><marker id="ah" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="220" fill="#0b1220"/>
  <rect x="30" y="78" width="120" height="44" rx="8" fill="#111c33" stroke="#475569"/><text x="90" y="105" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="14" text-anchor="middle">Mass M</text>
  <rect x="240" y="74" width="170" height="52" rx="8" fill="#1d2a4d" stroke="#6366f1"/><text x="325" y="106" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="15" text-anchor="middle">r_s = 2GM / c²</text>
  <rect x="500" y="78" width="120" height="44" rx="8" fill="#111c33" stroke="#475569"/><text x="560" y="105" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">radius r_s</text>
  <line x1="150" y1="100" x2="238" y2="100" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="410" y1="100" x2="498" y2="100" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <text x="325" y="170" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">Sun → ≈ 2.95 km   ·   Earth → ≈ 8.9 mm</text>
</svg>

## Connections

- It is a `prerequisite-of` the **event horizon**, whose radius it defines (→ 20260625120100).

## Sources

[^schwarzschild1916]: Schwarzschild, K. (1916) — the original solution defining r_s.
[^mtw1973]: Misner, Thorne & Wheeler, *Gravitation* (1973).
