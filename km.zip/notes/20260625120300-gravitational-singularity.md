---
id: "20260625120300"
title: "A gravitational singularity is the point of diverging curvature at a black hole's centre"
tags: [astronomy, black-holes, general-relativity, quantum-gravity]
parent_tag: black-holes
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: penrose1965
    citation: "Penrose, R. (1965), 'Gravitational Collapse and Space-Time Singularities', Phys. Rev. Lett. 14, 57"
    url: "https://doi.org/10.1103/PhysRevLett.14.57"
  - id: mtw1973
    citation: "Misner, C. W., Thorne, K. S., & Wheeler, J. A. — Gravitation (W. H. Freeman, 1973)"
relations:
  - { type: extends, target: "20260625120000" }
visualization:
  kind: svg
  alt: "Infalling matter from the event horizon reaches the singularity where curvature diverges, classical general relativity breaks down, and a quantum theory of gravity is needed."
---

## Core idea

A gravitational singularity is the location at a black hole's centre where general
relativity predicts spacetime curvature and density become infinite, and the known laws of
physics no longer apply [^penrose1965].

## Elaboration

Roger Penrose's 1965 singularity theorem showed that singularities are a generic
consequence of gravitational collapse in general relativity, not an artefact of perfect
symmetry — work recognised by the 2020 Nobel Prize in Physics. However, an *actual*
infinity is widely regarded as a sign that general relativity is incomplete at such
scales; most physicists expect a future theory of quantum gravity to replace the
singularity with something finite. The singularity is therefore a robust prediction of the
classical theory but not an established physical object [^mtw1973].

## Visualization

<svg viewBox="0 0 640 340" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="From event horizon and infalling matter to the singularity and the breakdown of classical gravity">
  <defs><marker id="ah" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="340" fill="#0b1220"/>
  <rect x="220" y="14" width="200" height="40" rx="8" fill="#111c33" stroke="#475569"/><text x="320" y="39" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Event horizon</text>
  <rect x="220" y="80" width="200" height="40" rx="8" fill="#111c33" stroke="#475569"/><text x="320" y="105" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Infalling matter</text>
  <rect x="180" y="146" width="280" height="40" rx="8" fill="#1d2a4d" stroke="#6366f1"/><text x="320" y="171" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Singularity: curvature → ∞</text>
  <rect x="170" y="212" width="300" height="40" rx="8" fill="#111c33" stroke="#475569"/><text x="320" y="237" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Classical general relativity breaks down</text>
  <rect x="190" y="278" width="260" height="40" rx="8" fill="#111c33" stroke="#475569"/><text x="320" y="303" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Quantum theory of gravity needed</text>
  <line x1="320" y1="54" x2="320" y2="78" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="320" y1="120" x2="320" y2="144" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="320" y1="186" x2="320" y2="210" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="320" y1="252" x2="320" y2="276" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
</svg>

## Connections

- It `extends` the core concept of a **black hole**, describing its interior endpoint (→ 20260625120000).

## Sources

[^penrose1965]: Penrose, R. (1965), *PRL* 14, 57 — the singularity theorem (2020 Nobel Prize).
[^mtw1973]: Misner, Thorne & Wheeler, *Gravitation* (1973).
