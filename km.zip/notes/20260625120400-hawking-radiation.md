---
id: "20260625120400"
title: "Hawking radiation is thermal radiation predicted to be emitted by black holes due to quantum effects"
tags: [astronomy, black-holes, quantum-mechanics, thermodynamics]
parent_tag: black-holes
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: hawking1974
    citation: "Hawking, S. W. (1974), 'Black hole explosions?', Nature 248, 30–31"
    url: "https://doi.org/10.1038/248030a0"
  - id: hawking1975
    citation: "Hawking, S. W. (1975), 'Particle Creation by Black Holes', Commun. Math. Phys. 43, 199–220"
relations:
  - { type: extends, target: "20260625120000" }
  - { type: related, target: "20260625120100" }
visualization:
  kind: svg
  alt: "Near the horizon a virtual particle pair appears; one escapes as Hawking radiation while its partner falls in, so the black hole loses mass and, over immense time, evaporates."
---

## Core idea

Hawking radiation is a faint thermal glow that quantum field theory predicts black holes
emit from just outside their event horizon, causing them to slowly lose mass and, over
vast timescales, evaporate [^hawking1974].

## Elaboration

In 1974 Stephen Hawking showed that applying quantum mechanics near the horizon makes a
black hole radiate as an (almost) perfect black body, with a temperature inversely
proportional to its mass — so smaller black holes are hotter and evaporate faster, while
stellar-mass and larger black holes are far colder than the cosmic microwave background
and are net *gaining* mass today [^hawking1975]. **This radiation has never been directly
observed**: for astrophysical black holes it is far too weak to detect with current
technology, so the prediction remains experimentally unconfirmed despite strong
theoretical support. It is significant because it links gravity, quantum mechanics, and
thermodynamics, and gives rise to the black-hole information paradox.

## Visualization

<svg viewBox="0 0 640 360" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Virtual pair production near the horizon leading to Hawking radiation, mass loss, and evaporation">
  <defs><marker id="ah" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="360" fill="#0b1220"/>
  <rect x="200" y="14" width="240" height="40" rx="8" fill="#111c33" stroke="#475569"/><text x="320" y="39" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Virtual pair near horizon</text>
  <rect x="60" y="96" width="220" height="40" rx="8" fill="#111c33" stroke="#475569"/><text x="170" y="121" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">One particle escapes</text>
  <rect x="360" y="96" width="220" height="40" rx="8" fill="#111c33" stroke="#475569"/><text x="470" y="121" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">Partner falls in</text>
  <rect x="40" y="180" width="260" height="40" rx="8" fill="#1d2a4d" stroke="#6366f1"/><text x="170" y="205" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">Hawking radiation observed</text>
  <rect x="350" y="180" width="240" height="40" rx="8" fill="#111c33" stroke="#475569"/><text x="470" y="205" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">Black hole loses mass</text>
  <rect x="350" y="264" width="240" height="40" rx="8" fill="#111c33" stroke="#475569"/><text x="470" y="289" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">Evaporates over immense time</text>
  <line x1="280" y1="54" x2="190" y2="94" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="360" y1="54" x2="450" y2="94" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="170" y1="136" x2="170" y2="178" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="470" y1="136" x2="470" y2="178" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="470" y1="220" x2="470" y2="262" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
</svg>

## Connections

- It `extends` the core concept of a **black hole** with a quantum refinement (→ 20260625120000).
- It is `related` to the **event horizon**, near which the radiation originates (→ 20260625120100).

## Sources

[^hawking1974]: Hawking, S. W. (1974), "Black hole explosions?", *Nature* 248, 30–31.
[^hawking1975]: Hawking, S. W. (1975), *Commun. Math. Phys.* 43, 199–220.
