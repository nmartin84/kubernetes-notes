---
id: "20260625120600"
title: "Spaghettification is the stretching of objects by extreme tidal forces near a black hole"
tags: [astronomy, black-holes, tidal-forces, gravity]
parent_tag: black-holes
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: hawking1988
    citation: "Hawking, S. W. (1988), A Brief History of Time (Bantam) — popularised the term 'spaghettification'"
  - id: mtw1973
    citation: "Misner, C. W., Thorne, K. S., & Wheeler, J. A. — Gravitation (W. H. Freeman, 1973)"
relations:
  - { type: related, target: "20260625120100" }
visualization:
  kind: svg
  alt: "A falling object feels a tidal force pulling its near end harder than its far end, producing vertical stretching and horizontal squeezing — spaghettification."
---

## Core idea

Spaghettification is the vertical stretching and horizontal compression that an object
undergoes near a black hole, caused by the steep gradient in gravitational pull between its
near and far ends (the tidal force) [^hawking1988].

## Elaboration

Gravity weakens with distance, so the part of a falling object closest to the black hole is
pulled much more strongly than the part farthest away. Near a black hole this difference
becomes enormous, drawing the object into a long, thin strand — hence "spaghettification."
For small (stellar-mass) black holes the tidal force becomes lethal *outside* the event
horizon; for supermassive black holes the horizon is so large that the tidal force there is
gentle, and an object could cross the horizon intact before being stretched apart closer to
the centre [^mtw1973].

## Visualization

<svg viewBox="0 0 640 340" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Tidal force on a falling object causes stretching and squeezing, i.e. spaghettification">
  <defs><marker id="ah" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="340" fill="#0b1220"/>
  <rect x="210" y="14" width="220" height="40" rx="8" fill="#111c33" stroke="#475569"/><text x="320" y="39" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Object falls toward BH</text>
  <rect x="160" y="84" width="320" height="40" rx="8" fill="#1d2a4d" stroke="#6366f1"/><text x="320" y="109" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">Tidal force: near end pulled harder than far end</text>
  <rect x="110" y="160" width="180" height="40" rx="8" fill="#111c33" stroke="#475569"/><text x="200" y="185" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">Vertical stretching</text>
  <rect x="350" y="160" width="180" height="40" rx="8" fill="#111c33" stroke="#475569"/><text x="440" y="185" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">Horizontal squeezing</text>
  <rect x="230" y="244" width="180" height="44" rx="8" fill="#172554" stroke="#818cf8"/><text x="320" y="271" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Spaghettification</text>
  <line x1="320" y1="54" x2="320" y2="82" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="280" y1="124" x2="210" y2="158" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="360" y1="124" x2="430" y2="158" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="220" y1="200" x2="290" y2="242" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="420" y1="200" x2="350" y2="242" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
</svg>

## Connections

- It is `related` to the **event horizon**, near which (or beyond which) the effect becomes extreme (→ 20260625120100).

## Sources

[^hawking1988]: Hawking, S. W. (1988), *A Brief History of Time* — popularised "spaghettification".
[^mtw1973]: Misner, Thorne & Wheeler, *Gravitation* (1973).
