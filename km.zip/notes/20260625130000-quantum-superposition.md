---
id: "20260625130000"
title: "Quantum superposition lets a system occupy a linear combination of states until it is measured"
tags: [physics, quantum-mechanics, quantum-foundations, superposition]
parent_tag: quantum-mechanics
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: dirac1930
    citation: "Dirac, P. A. M. — The Principles of Quantum Mechanics (Oxford University Press, 1930)"
  - id: feynman3
    citation: "Feynman, Leighton & Sands — The Feynman Lectures on Physics, Vol. III (Addison-Wesley, 1965)"
    url: "https://www.feynmanlectures.caltech.edu/III_toc.html"
relations:
  - { type: prerequisite-of, target: "20260625130100" }
  - { type: related, target: "20260625130300" }
  - { type: related, target: "20260625130700" }
visualization:
  kind: svg
  alt: "A quantum state written as alpha times |0> plus beta times |1> exists as both basis states at once; a measurement projects it onto a single definite outcome, |0> or |1>."
---

## Core idea

Quantum superposition is the principle that if a system can be in any of several distinct
states, it can also be in any linear combination of them — so until a measurement forces a
definite result, the system genuinely occupies all the superposed possibilities at once,
each with a complex amplitude [^dirac1930].

## Elaboration

Superposition follows directly from the linearity of the Schrödinger equation: solutions
add. A qubit in the state |ψ⟩ = α|0⟩ + β|1⟩ is not secretly in one state we are merely
ignorant of — interference experiments (most famously the double-slit) show the
superposed branches affect one another, which a classical "hidden" definite value cannot
reproduce [^feynman3]. On measurement the outcome is one basis state, obtained with
probability |α|² or |β|² (the Born rule). How that single outcome emerges from the
superposition is precisely what the **measurement problem** asks. Superposition is a
verified, daily-used feature of quantum mechanics — it underpins lasers, chemistry, and
quantum computing — even though its interpretation remains debated.

## Visualization

<svg viewBox="0 0 640 280" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="A superposition of two basis states collapses to one definite outcome on measurement">
  <defs><marker id="ar" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="280" fill="#0b1220"/>
  <rect x="30" y="108" width="240" height="64" rx="10" fill="#1d2a4d" stroke="#6366f1"/>
  <text x="150" y="135" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="14" text-anchor="middle">Superposition</text>
  <text x="150" y="158" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="15" text-anchor="middle">|ψ⟩ = α|0⟩ + β|1⟩</text>
  <rect x="300" y="116" width="120" height="48" rx="8" fill="#111c33" stroke="#475569"/>
  <text x="360" y="145" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">measure</text>
  <line x1="270" y1="140" x2="298" y2="140" stroke="#94a3b8" stroke-width="2" marker-end="url(#ar)"/>
  <rect x="470" y="54" width="140" height="48" rx="8" fill="#0e1830" stroke="#22c55e"/>
  <text x="540" y="83" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="15" text-anchor="middle">|0⟩  (prob |α|²)</text>
  <rect x="470" y="178" width="140" height="48" rx="8" fill="#0e1830" stroke="#22c55e"/>
  <text x="540" y="207" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="15" text-anchor="middle">|1⟩  (prob |β|²)</text>
  <line x1="420" y1="132" x2="468" y2="86" stroke="#94a3b8" stroke-width="2" marker-end="url(#ar)"/>
  <line x1="420" y1="148" x2="468" y2="198" stroke="#94a3b8" stroke-width="2" marker-end="url(#ar)"/>
  <text x="320" y="252" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">one definite outcome per measurement (Born rule)</text>
</svg>

## Connections

- It is a `prerequisite-of` the **quantum measurement problem** (→ 20260625130100).
- It is `related` to **quantum decoherence**, which suppresses superposition interference (→ 20260625130300).
- It is `related` to **Orch-OR**, which posits superposition inside neurons (→ 20260625130700).

## Sources

[^dirac1930]: Dirac, P. A. M., *The Principles of Quantum Mechanics* (1930) — the superposition principle.
[^feynman3]: Feynman, Leighton & Sands, *The Feynman Lectures on Physics*, Vol. III (1965) — double-slit and amplitudes.
