---
id: "20260625130100"
title: "The quantum measurement problem asks why definite outcomes appear from superpositions"
short_title: "Measurement problem"
tags: [physics, quantum-mechanics, quantum-foundations, consciousness, measurement]
parent_tag: quantum-mechanics
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: maudlin1995
    citation: "Maudlin, T. - Three measurement problems, Topoi 14, 7-15 (1995)"
    url: "https://doi.org/10.1007/BF00763473"
  - id: schlosshauer2007
    citation: "Schlosshauer, M. - Decoherence and the Quantum-to-Classical Transition (Springer, 2007)"
relations:
  - { type: requires, target: "20260625130000" }
  - { type: extended-by, target: "20260625130200" }
  - { type: related, target: "20260625130300" }
  - { type: related, target: "20260625130400" }
  - { type: related, target: "20260625130600" }
visualization:
  kind: svg
  alt: "A superposed quantum state evolves smoothly by the Schrodinger equation, while a measurement record shows one definite result; the measurement problem is the gap between those descriptions."
---

## Core idea

The quantum measurement problem is the tension between linear quantum evolution, which
preserves superpositions, and measurement experience, which yields one definite recorded
outcome [^maudlin1995].

## Elaboration

In standard quantum mechanics, a system can evolve into a superposition of macroscopically
different measurement records. The Born rule gives probabilities for possible outcomes,
but the formalism still needs an account of why a single outcome is experienced in a
particular run [^maudlin1995]. Interpretations respond differently: collapse theories add
physical reduction, many-worlds denies unique global collapse, Bohmian mechanics adds
definite configurations, decoherence explains why interference becomes practically
unavailable, and consciousness-based views place the observer's mind inside the account.
This is why the topic forms the main bridge between quantum theory and claims about
consciousness [^schlosshauer2007].

## Visualization

<svg viewBox="0 0 640 300" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Measurement problem diagram">
  <defs><marker id="mpa" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="300" fill="#0b1220"/>
  <rect x="28" y="76" width="170" height="70" rx="8" fill="#111c33" stroke="#475569"/>
  <text x="113" y="106" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Initial system</text>
  <text x="113" y="128" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">psi = aA + bB</text>
  <rect x="238" y="76" width="170" height="70" rx="8" fill="#111c33" stroke="#475569"/>
  <text x="323" y="106" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Unitary dynamics</text>
  <text x="323" y="128" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">both branches persist</text>
  <rect x="448" y="40" width="164" height="52" rx="8" fill="#102a1b" stroke="#22c55e"/>
  <text x="530" y="71" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Record: A</text>
  <rect x="448" y="130" width="164" height="52" rx="8" fill="#2b1520" stroke="#fb7185"/>
  <text x="530" y="161" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Record: B</text>
  <line x1="198" y1="111" x2="236" y2="111" stroke="#94a3b8" stroke-width="2" marker-end="url(#mpa)"/>
  <line x1="408" y1="102" x2="446" y2="72" stroke="#94a3b8" stroke-width="2" marker-end="url(#mpa)"/>
  <line x1="408" y1="120" x2="446" y2="150" stroke="#94a3b8" stroke-width="2" marker-end="url(#mpa)"/>
  <rect x="150" y="220" width="340" height="44" rx="8" fill="#1d2a4d" stroke="#6366f1"/>
  <text x="320" y="247" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Why is one outcome experienced?</text>
</svg>

## Connections

- It `requires` **quantum superposition** (20260625130000).
- It is `extended-by` **consciousness-caused collapse** (20260625130200).
- It is `related` to **quantum decoherence** (20260625130300).
- It is `related` to the **von Neumann measurement chain** (20260625130400).
- It is `related` to **objective reduction** (20260625130600).

## Sources

[^maudlin1995]: Maudlin, "Three measurement problems" (1995).
[^schlosshauer2007]: Schlosshauer, *Decoherence and the Quantum-to-Classical Transition* (2007).
