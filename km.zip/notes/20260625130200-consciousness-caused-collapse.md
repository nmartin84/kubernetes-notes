---
id: "20260625130200"
title: "Consciousness-caused collapse makes mind responsible for definite quantum outcomes"
short_title: "Consciousness collapse"
tags: [consciousness, quantum-foundations, measurement, philosophy-of-mind]
parent_tag: consciousness
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: londonbauer1939
    citation: "London, F. & Bauer, E. - La theorie de l'observation en mecanique quantique (Hermann, 1939)"
  - id: wigner1961
    citation: "Wigner, E. P. - Remarks on the mind-body question, in The Scientist Speculates (1961)"
relations:
  - { type: extends, target: "20260625130100" }
  - { type: related, target: "20260625130300" }
  - { type: related, target: "20260625130400" }
  - { type: related, target: "20260625130500" }
  - { type: related, target: "20260625130700" }
  - { type: related, target: "20260625130900" }
visualization:
  kind: svg
  alt: "A measurement apparatus becomes correlated with a quantum system, then a conscious observer is placed at the final stage where a definite experience is proposed to collapse the state."
---

## Core idea

Consciousness-caused collapse is the view that a quantum state becomes definite only when
it is registered in conscious experience, rather than when it interacts with an ordinary
physical measuring device [^wigner1961].

## Elaboration

The proposal arose from the measurement-chain problem: if the system, apparatus, and
observer's brain are all physical systems, then quantum theory can in principle describe
all of them as entangled [^londonbauer1939]. Consciousness-collapse views stop that chain
at experience itself. The view is historically important because it directly joins quantum
measurement to the mind-body problem, but it is not part of standard laboratory quantum
mechanics and remains a minority interpretation. Decoherence and other interpretations
aim to explain definite appearances without making consciousness a new physical collapse
mechanism [^wigner1961].

## Visualization

<svg viewBox="0 0 640 300" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Consciousness collapse chain">
  <defs><marker id="cca" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="300" fill="#0b1220"/>
  <rect x="38" y="92" width="120" height="58" rx="8" fill="#111c33" stroke="#475569"/>
  <text x="98" y="126" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">System</text>
  <rect x="205" y="92" width="120" height="58" rx="8" fill="#111c33" stroke="#475569"/>
  <text x="265" y="126" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Apparatus</text>
  <rect x="372" y="92" width="120" height="58" rx="8" fill="#111c33" stroke="#475569"/>
  <text x="432" y="126" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Brain state</text>
  <rect x="510" y="72" width="98" height="98" rx="49" fill="#1d2a4d" stroke="#6366f1"/>
  <text x="559" y="116" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Experience</text>
  <text x="559" y="137" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">collapse?</text>
  <line x1="158" y1="121" x2="203" y2="121" stroke="#94a3b8" stroke-width="2" marker-end="url(#cca)"/>
  <line x1="325" y1="121" x2="370" y2="121" stroke="#94a3b8" stroke-width="2" marker-end="url(#cca)"/>
  <line x1="492" y1="121" x2="508" y2="121" stroke="#94a3b8" stroke-width="2" marker-end="url(#cca)"/>
  <text x="320" y="222" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">The cut is placed at conscious awareness, not at the detector.</text>
</svg>

## Connections

- It `extends` the **quantum measurement problem** (20260625130100).
- It is `related` to **quantum decoherence** (20260625130300), which offers a non-consciousness route to classical appearances.
- It is `related` to the **von Neumann measurement chain** (20260625130400).
- It is `related` to the **hard problem of consciousness** (20260625130500).
- It is `related` to **Orch-OR** (20260625130700).
- It is `related` to **quantum cognition** (20260625130900).

## Sources

[^londonbauer1939]: London & Bauer, *La theorie de l'observation en mecanique quantique* (1939).
[^wigner1961]: Wigner, "Remarks on the mind-body question" (1961).
