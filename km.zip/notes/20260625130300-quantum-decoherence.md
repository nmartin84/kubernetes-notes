---
id: "20260625130300"
title: "Quantum decoherence suppresses interference when systems entangle with their environments"
short_title: "Decoherence"
tags: [physics, quantum-mechanics, quantum-foundations, decoherence, measurement]
parent_tag: quantum-mechanics
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: zurek2003
    citation: "Zurek, W. H. - Decoherence, einselection, and the quantum origins of the classical, Reviews of Modern Physics 75, 715-775 (2003)"
    url: "https://doi.org/10.1103/RevModPhys.75.715"
  - id: schlosshauer2007
    citation: "Schlosshauer, M. - Decoherence and the Quantum-to-Classical Transition (Springer, 2007)"
relations:
  - { type: related, target: "20260625130000" }
  - { type: related, target: "20260625130100" }
  - { type: related, target: "20260625130200" }
  - { type: related, target: "20260625130600" }
  - { type: prerequisite-of, target: "20260625130800" }
visualization:
  kind: svg
  alt: "A coherent quantum superposition loses observable interference as information leaks into many environmental degrees of freedom."
---

## Core idea

Quantum decoherence is the loss of observable interference between components of a
superposition when a system becomes entangled with uncontrolled environmental degrees of
freedom [^zurek2003].

## Elaboration

Decoherence does not usually require a conscious observer, and it does not by itself pick
one outcome from the global quantum state. Instead, it explains why some states become
stable pointer states and why interference between macroscopically different alternatives
becomes practically inaccessible [^schlosshauer2007]. This makes decoherence central to
modern discussions of the measurement problem and to criticism of proposals that require
long-lived, functionally important quantum coherence inside warm biological tissue.

## Visualization

<svg viewBox="0 0 640 300" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Decoherence diagram">
  <defs><marker id="dca" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="300" fill="#0b1220"/>
  <rect x="36" y="92" width="170" height="64" rx="8" fill="#1d2a4d" stroke="#6366f1"/>
  <text x="121" y="119" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Coherent system</text>
  <text x="121" y="140" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">A + B interferes</text>
  <circle cx="330" cy="124" r="42" fill="#111c33" stroke="#475569"/>
  <text x="330" y="120" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">environment</text>
  <text x="330" y="140" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="11" text-anchor="middle">records leaks</text>
  <rect x="454" y="68" width="150" height="48" rx="8" fill="#102a1b" stroke="#22c55e"/>
  <text x="529" y="98" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Pointer A</text>
  <rect x="454" y="148" width="150" height="48" rx="8" fill="#102a1b" stroke="#22c55e"/>
  <text x="529" y="178" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Pointer B</text>
  <line x1="206" y1="124" x2="286" y2="124" stroke="#94a3b8" stroke-width="2" marker-end="url(#dca)"/>
  <line x1="372" y1="110" x2="452" y2="92" stroke="#94a3b8" stroke-width="2" marker-end="url(#dca)"/>
  <line x1="372" y1="138" x2="452" y2="172" stroke="#94a3b8" stroke-width="2" marker-end="url(#dca)"/>
  <text x="320" y="238" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Interference is dispersed into system-environment correlations.</text>
</svg>

## Connections

- It is `related` to **quantum superposition** (20260625130000).
- It is `related` to the **quantum measurement problem** (20260625130100).
- It is `related` to **consciousness-caused collapse** (20260625130200).
- It is `related` to **objective reduction** (20260625130600).
- It is a `prerequisite-of` **Tegmark's brain decoherence critique** (20260625130800).

## Sources

[^zurek2003]: Zurek, "Decoherence, einselection, and the quantum origins of the classical" (2003).
[^schlosshauer2007]: Schlosshauer, *Decoherence and the Quantum-to-Classical Transition* (2007).
