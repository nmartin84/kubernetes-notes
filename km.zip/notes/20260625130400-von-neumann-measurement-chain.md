---
id: "20260625130400"
title: "The von Neumann measurement chain shows that the quantum-classical cut can be shifted"
short_title: "Measurement chain"
tags: [physics, quantum-foundations, measurement, consciousness, philosophy]
parent_tag: quantum-foundations
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: vonneumann1932
    citation: "von Neumann, J. - Mathematische Grundlagen der Quantenmechanik (Springer, 1932); English translation: Mathematical Foundations of Quantum Mechanics (Princeton, 1955)"
  - id: wigner1961
    citation: "Wigner, E. P. - Remarks on the mind-body question, in The Scientist Speculates (1961)"
relations:
  - { type: related, target: "20260625130100" }
  - { type: related, target: "20260625130200" }
  - { type: related, target: "20260625130500" }
visualization:
  kind: svg
  alt: "A quantum system, apparatus, observer body, and observer mind form a chain; the quantum-classical cut can be drawn at different points."
---

## Core idea

The von Neumann measurement chain is the idea that a measured system, apparatus, sensory
organs, and observer can all be treated as linked physical systems, so the location of the
quantum-classical cut is not fixed by the basic formalism [^vonneumann1932].

## Elaboration

The chain matters for consciousness debates because moving the cut farther toward the
observer raises the question of whether conscious experience has a special role in making
outcomes definite [^wigner1961]. In practical physics, the cut is normally placed wherever
the apparatus can be treated classically for the calculation at hand. As a foundational
issue, however, the movable cut exposes why "measurement" is not a primitive laboratory
word in interpretations that try to describe the whole measuring arrangement quantum
mechanically.

## Visualization

<svg viewBox="0 0 640 300" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Von Neumann chain diagram">
  <defs><marker id="vna" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="300" fill="#0b1220"/>
  <g font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">
    <rect x="30" y="92" width="112" height="56" rx="8" fill="#111c33" stroke="#475569"/>
    <text x="86" y="125" fill="#e2e8f0">System</text>
    <rect x="178" y="92" width="112" height="56" rx="8" fill="#111c33" stroke="#475569"/>
    <text x="234" y="125" fill="#e2e8f0">Apparatus</text>
    <rect x="326" y="92" width="112" height="56" rx="8" fill="#111c33" stroke="#475569"/>
    <text x="382" y="125" fill="#e2e8f0">Body/brain</text>
    <rect x="474" y="92" width="112" height="56" rx="8" fill="#1d2a4d" stroke="#6366f1"/>
    <text x="530" y="125" fill="#e2e8f0">Experience</text>
  </g>
  <line x1="142" y1="120" x2="176" y2="120" stroke="#94a3b8" stroke-width="2" marker-end="url(#vna)"/>
  <line x1="290" y1="120" x2="324" y2="120" stroke="#94a3b8" stroke-width="2" marker-end="url(#vna)"/>
  <line x1="438" y1="120" x2="472" y2="120" stroke="#94a3b8" stroke-width="2" marker-end="url(#vna)"/>
  <line x1="302" y1="58" x2="302" y2="194" stroke="#fbbf24" stroke-width="3" stroke-dasharray="8 8"/>
  <text x="302" y="218" fill="#fbbf24" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">possible cut</text>
  <line x1="458" y1="58" x2="458" y2="194" stroke="#fbbf24" stroke-width="3" stroke-dasharray="8 8"/>
  <text x="458" y="238" fill="#fbbf24" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">another possible cut</text>
</svg>

## Connections

- It is `related` to the **quantum measurement problem** (20260625130100).
- It is `related` to **consciousness-caused collapse** (20260625130200).
- It is `related` to the **hard problem of consciousness** (20260625130500).

## Sources

[^vonneumann1932]: von Neumann, *Mathematical Foundations of Quantum Mechanics* (1932/1955).
[^wigner1961]: Wigner, "Remarks on the mind-body question" (1961).
