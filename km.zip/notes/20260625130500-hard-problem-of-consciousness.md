---
id: "20260625130500"
title: "The hard problem of consciousness asks why physical processing is accompanied by experience"
short_title: "Hard problem"
tags: [consciousness, philosophy-of-mind, qualia, neuroscience, quantum-theory]
parent_tag: consciousness
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: chalmers1995
    citation: "Chalmers, D. J. - Facing up to the problem of consciousness, Journal of Consciousness Studies 2(3), 200-219 (1995)"
relations:
  - { type: related, target: "20260625130200" }
  - { type: related, target: "20260625130400" }
  - { type: related, target: "20260625130700" }
  - { type: related, target: "20260625130900" }
  - { type: related, target: "20260625133900" }
visualization:
  kind: svg
  alt: "Neural and computational functions explain behavior and report, while the hard problem points to subjective experience as an additional explanatory target."
---

## Core idea

The hard problem of consciousness is the question of why and how physical or functional
processes are accompanied by subjective experience at all [^chalmers1995].

## Elaboration

Chalmers contrasted the hard problem with "easy" problems such as discrimination,
attention, report, and behavioral control, which are difficult scientific problems but can
be framed in terms of mechanisms and functions [^chalmers1995]. Quantum theories of
consciousness often appeal to this gap: they claim that classical computation or ordinary
neurobiology leaves something unexplained. That appeal is philosophical motivation, not
experimental evidence that quantum processes generate consciousness.

## Visualization

<svg viewBox="0 0 640 300" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Hard problem diagram">
  <defs><marker id="hpa" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="300" fill="#0b1220"/>
  <rect x="44" y="76" width="176" height="70" rx="8" fill="#111c33" stroke="#475569"/>
  <text x="132" y="104" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Physical processing</text>
  <text x="132" y="126" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">neurons, computation</text>
  <rect x="420" y="50" width="176" height="58" rx="8" fill="#102a1b" stroke="#22c55e"/>
  <text x="508" y="84" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Behavior and report</text>
  <rect x="420" y="156" width="176" height="58" rx="8" fill="#1d2a4d" stroke="#6366f1"/>
  <text x="508" y="190" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Subjective experience</text>
  <line x1="220" y1="104" x2="418" y2="80" stroke="#94a3b8" stroke-width="2" marker-end="url(#hpa)"/>
  <line x1="220" y1="126" x2="418" y2="184" stroke="#94a3b8" stroke-width="2" stroke-dasharray="7 7" marker-end="url(#hpa)"/>
  <text x="318" y="174" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">why experience?</text>
</svg>

## Connections

- It is `related` to **consciousness-caused collapse** (20260625130200).
- It is `related` to the **von Neumann measurement chain** (20260625130400).
- It is `related` to **Orch-OR** (20260625130700).
- It is `related` to **quantum cognition** (20260625130900).
- It is `related` to the **quantum consciousness hypothesis** note (20260625133900).

## Sources

[^chalmers1995]: Chalmers, "Facing up to the problem of consciousness" (1995).
