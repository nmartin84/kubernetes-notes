---
id: "20260625130600"
title: "Objective reduction proposes that wavefunction collapse is a real physical process"
short_title: "Objective reduction"
tags: [physics, quantum-foundations, collapse-theories, gravity, consciousness]
parent_tag: quantum-foundations
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: penrose1996
    citation: "Penrose, R. - On gravity's role in quantum state reduction, General Relativity and Gravitation 28, 581-600 (1996)"
    url: "https://doi.org/10.1007/BF02105068"
  - id: diosi1987
    citation: "Diosi, L. - A universal master equation for the gravitational violation of quantum mechanics, Physics Letters A 120, 377-381 (1987)"
    url: "https://doi.org/10.1016/0375-9601(87)90681-5"
relations:
  - { type: related, target: "20260625130100" }
  - { type: related, target: "20260625130300" }
  - { type: prerequisite-of, target: "20260625130700" }
  - { type: related, target: "20260625130800" }
visualization:
  kind: svg
  alt: "A growing superposition reaches an objective threshold and reduces to one branch without requiring a conscious observer."
---

## Core idea

Objective reduction theories treat wavefunction collapse as a real physical event, not
merely an update of knowledge or a special effect of conscious observation [^penrose1996].

## Elaboration

Penrose's gravitational version argues that superpositions involving sufficiently
different spacetime geometries become unstable and reduce after a characteristic time
related to gravitational self-energy [^penrose1996]. Diosi proposed a related gravity-linked
collapse dynamics [^diosi1987]. These ideas are important for consciousness debates because
Orch-OR uses Penrose-style objective reduction as the proposed physical event that becomes
linked to moments of awareness. Objective reduction remains speculative and is distinct
from standard decoherence, which suppresses interference without adding an objective
single-outcome collapse.

## Visualization

<svg viewBox="0 0 640 300" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Objective reduction threshold">
  <defs><marker id="ora" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="300" fill="#0b1220"/>
  <path d="M70 218 C150 190, 190 130, 260 116 C320 104, 378 122, 438 82" fill="none" stroke="#6366f1" stroke-width="4"/>
  <path d="M70 218 C150 232, 190 252, 260 238 C320 226, 378 184, 438 208" fill="none" stroke="#22c55e" stroke-width="4"/>
  <line x1="462" y1="46" x2="462" y2="246" stroke="#fbbf24" stroke-width="3" stroke-dasharray="8 8"/>
  <text x="462" y="268" fill="#fbbf24" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">OR threshold</text>
  <line x1="482" y1="146" x2="552" y2="146" stroke="#94a3b8" stroke-width="2" marker-end="url(#ora)"/>
  <rect x="554" y="118" width="62" height="56" rx="8" fill="#111c33" stroke="#475569"/>
  <text x="585" y="151" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">one</text>
  <text x="260" y="62" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">superposed alternatives diverge</text>
</svg>

## Connections

- It is `related` to the **quantum measurement problem** (20260625130100).
- It is `related` to **quantum decoherence** (20260625130300).
- It is a `prerequisite-of` **Orch-OR** (20260625130700).
- It is `related` to **Tegmark's brain decoherence critique** (20260625130800).

## Sources

[^penrose1996]: Penrose, "On gravity's role in quantum state reduction" (1996).
[^diosi1987]: Diosi, "A universal master equation for the gravitational violation of quantum mechanics" (1987).
