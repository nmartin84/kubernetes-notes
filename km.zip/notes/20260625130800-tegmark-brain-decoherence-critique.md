---
id: "20260625130800"
title: "Tegmark's brain-decoherence critique argues that neural quantum states decohere too quickly"
short_title: "Brain decoherence critique"
tags: [consciousness, quantum-decoherence, neuroscience, microtubules, critique]
parent_tag: consciousness
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: tegmark2000
    citation: "Tegmark, M. - Importance of quantum decoherence in brain processes, Physical Review E 61, 4194-4206 (2000)"
    url: "https://doi.org/10.1103/PhysRevE.61.4194"
  - id: hagan2002
    citation: "Hagan, S., Hameroff, S. R. & Tuszynski, J. A. - Quantum computation in brain microtubules? Decoherence and biological feasibility, Physical Review E 65, 061901 (2002)"
    url: "https://doi.org/10.1103/PhysRevE.65.061901"
relations:
  - { type: requires, target: "20260625130300" }
  - { type: related, target: "20260625130600" }
  - { type: contradicts, target: "20260625130700" }
  - { type: related, target: "20260625133900" }
visualization:
  kind: svg
  alt: "A proposed coherent brain state is shown being rapidly disrupted by thermal and environmental interactions before it can influence neural timescales."
---

## Core idea

Tegmark's critique estimates that quantum superpositions relevant to neural processing in
the brain would decohere far faster than ordinary neural firing times, undermining many
quantum-brain proposals [^tegmark2000].

## Elaboration

The argument treats the brain as a warm, wet environment where ions, molecules, and other
degrees of freedom rapidly record information about any delicate quantum state
[^tegmark2000]. Hameroff and collaborators disputed aspects of the estimates and argued
for more favorable microtubule conditions [^hagan2002]. The continuing dispute is not over
whether decoherence exists; it is over whether any protected, biologically meaningful
quantum coherence can persist long enough to matter for cognition or consciousness.

## Visualization

<svg viewBox="0 0 640 300" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Brain decoherence critique">
  <defs><marker id="tga" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="300" fill="#0b1220"/>
  <rect x="54" y="98" width="154" height="58" rx="8" fill="#1d2a4d" stroke="#6366f1"/>
  <text x="131" y="132" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">coherent state</text>
  <circle cx="320" cy="126" r="52" fill="#111c33" stroke="#475569"/>
  <text x="320" y="120" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">warm brain</text>
  <text x="320" y="141" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">environment</text>
  <rect x="450" y="68" width="140" height="48" rx="8" fill="#2b1520" stroke="#fb7185"/>
  <text x="520" y="98" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">decohered</text>
  <rect x="450" y="154" width="140" height="48" rx="8" fill="#111c33" stroke="#475569"/>
  <text x="520" y="184" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">neural timescale</text>
  <line x1="208" y1="126" x2="266" y2="126" stroke="#94a3b8" stroke-width="2" marker-end="url(#tga)"/>
  <line x1="372" y1="110" x2="448" y2="94" stroke="#94a3b8" stroke-width="2" marker-end="url(#tga)"/>
  <line x1="520" y1="118" x2="520" y2="152" stroke="#fb7185" stroke-width="2" stroke-dasharray="7 7" marker-end="url(#tga)"/>
  <text x="320" y="244" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Critique: coherence is lost before neural processing can use it.</text>
</svg>

## Connections

- It `requires` **quantum decoherence** (20260625130300).
- It is `related` to **objective reduction** (20260625130600).
- It `contradicts` **Orch-OR** (20260625130700).
- It is `related` to the **quantum consciousness hypothesis** note (20260625133900).

## Sources

[^tegmark2000]: Tegmark, "Importance of quantum decoherence in brain processes" (2000).
[^hagan2002]: Hagan, Hameroff & Tuszynski, "Quantum computation in brain microtubules?" (2002).
