---
id: "20260625130900"
title: "Quantum cognition uses quantum probability models without requiring quantum brain physics"
short_title: "Quantum cognition"
tags: [cognition, consciousness, psychology, quantum-probability, decision-theory]
parent_tag: cognition
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: busemeyerbruza2012
    citation: "Busemeyer, J. R. & Bruza, P. D. - Quantum Models of Cognition and Decision (Cambridge University Press, 2012)"
  - id: pothosbusemeyer2013
    citation: "Pothos, E. M. & Busemeyer, J. R. - Can quantum probability provide a new direction for cognitive modeling?, Behavioral and Brain Sciences 36, 255-274 (2013)"
    url: "https://doi.org/10.1017/S0140525X12001525"
relations:
  - { type: related, target: "20260625130200" }
  - { type: related, target: "20260625130500" }
visualization:
  kind: svg
  alt: "Quantum cognition maps questions and decisions onto quantum-like probability spaces, while a separate boundary marks that this does not imply microscopic quantum computation in the brain."
---

## Core idea

Quantum cognition applies the mathematics of quantum probability to human judgment and
decision patterns, without assuming that the brain literally performs microscopic quantum
computations [^busemeyerbruza2012].

## Elaboration

The approach uses ideas such as contextuality, incompatible questions, order effects, and
interference-like probability terms to model cognitive data that can be awkward for some
classical probability models [^pothosbusemeyer2013]. It is therefore a modeling framework
for cognition, not a claim that consciousness collapses wavefunctions or that neurons use
long-lived quantum coherence. This distinction prevents a common category error in
discussions of consciousness and quantum theory.

## Visualization

<svg viewBox="0 0 640 300" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Quantum cognition distinction">
  <defs><marker id="qca" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="300" fill="#0b1220"/>
  <rect x="54" y="74" width="190" height="64" rx="8" fill="#1d2a4d" stroke="#6366f1"/>
  <text x="149" y="101" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Quantum probability</text>
  <text x="149" y="123" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">modeling toolkit</text>
  <rect x="396" y="74" width="190" height="64" rx="8" fill="#102a1b" stroke="#22c55e"/>
  <text x="491" y="101" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Cognitive behavior</text>
  <text x="491" y="123" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">order/context effects</text>
  <line x1="244" y1="106" x2="394" y2="106" stroke="#94a3b8" stroke-width="2" marker-end="url(#qca)"/>
  <line x1="320" y1="168" x2="320" y2="246" stroke="#fbbf24" stroke-width="3" stroke-dasharray="8 8"/>
  <text x="320" y="266" fill="#fbbf24" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">not a claim of quantum brain hardware</text>
</svg>

## Connections

- It is `related` to **consciousness-caused collapse** (20260625130200).
- It is `related` to the **hard problem of consciousness** (20260625130500).

## Sources

[^busemeyerbruza2012]: Busemeyer & Bruza, *Quantum Models of Cognition and Decision* (2012).
[^pothosbusemeyer2013]: Pothos & Busemeyer, "Can quantum probability provide a new direction for cognitive modeling?" (2013).
