---
id: "20260625131100"
title: "AI datacenter electricity demand grows when compute scaling outruns efficiency gains"
short_title: "Electricity demand"
tags: [ai, datacenters, electricity, energy-demand, infrastructure]
parent_tag: ai-datacenters
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: iea2025
    citation: "International Energy Agency - Energy and AI (2025)"
    url: "https://www.iea.org/reports/energy-and-ai"
  - id: lbnl2024
    citation: "Shehabi, A., Newkirk, A., Smith, S. J., Hubbard, A., & Lei, N. - 2024 United States Data Center Energy Usage Report, Lawrence Berkeley National Laboratory (2024)"
relations:
  - { type: extends, target: "20260625131000" }
  - { type: related, target: "20260625131200" }
  - { type: prerequisite-of, target: "20260625131300" }
  - { type: related, target: "20260625131400" }
  - { type: related, target: "20260625131800" }
  - { type: related, target: "20260625131900" }
visualization:
  kind: svg
  alt: "A rising compute demand curve is partly offset by efficiency improvements, but net electricity demand still rises when workloads grow faster than efficiency."
---

## Core idea

AI datacenter electricity demand rises when growth in training, inference, and accelerator
deployment exceeds improvements in model, chip, and facility efficiency [^iea2025].

## Elaboration

Datacenters were once a case study in efficiency: better virtualization, hyperscale
operations, and improved cooling slowed electricity growth even as digital traffic rose.
The AI boom changes the balance because dense GPU and accelerator clusters add large,
continuous loads. The IEA estimates that a typical AI-focused datacenter can use as much
electricity as 100,000 households, while the largest new projects can be much larger
[^iea2025]. In the United States, LBNL estimated 2023 data-center electricity consumption
at 176 TWh, about 4.4% of national electricity use, with scenarios reaching 6.7% to 12.0%
of U.S. electricity consumption by 2028 [^lbnl2024].

## Visualization

<svg viewBox="0 0 640 310" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Compute growth and efficiency gains create net electricity demand">
  <rect width="640" height="310" fill="#0b1220"/>
  <line x1="76" y1="244" x2="570" y2="244" stroke="#475569" stroke-width="2"/>
  <line x1="76" y1="244" x2="76" y2="48" stroke="#475569" stroke-width="2"/>
  <path d="M88 224 C170 190, 234 146, 318 92 C398 42, 482 44, 554 38" fill="none" stroke="#6366f1" stroke-width="4"/>
  <path d="M88 224 C170 208, 244 190, 330 178 C420 164, 486 142, 554 126" fill="none" stroke="#22c55e" stroke-width="4"/>
  <path d="M88 224 C170 196, 244 164, 330 130 C420 98, 486 98, 554 86" fill="none" stroke="#fbbf24" stroke-width="4"/>
  <text x="474" y="42" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="13">compute demand</text>
  <text x="440" y="132" fill="#86efac" font-family="system-ui,sans-serif" font-size="13">efficiency gain</text>
  <text x="430" y="90" fill="#fde68a" font-family="system-ui,sans-serif" font-size="13">net electricity</text>
  <text x="320" y="282" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">If workloads grow faster than efficiency, total load grows.</text>
</svg>

## Connections

- It `extends` **AI datacenters** (20260625131000).
- It is `related` to **grid stress and siting** (20260625131200).
- It is a `prerequisite-of` **carbon emissions accounting** (20260625131300).
- It is `related` to **cooling water use** (20260625131400).
- It is `related` to **efficiency rebound and transparency** (20260625131800).
- It is `related` to **PC waste heat recovery** (20260625131900), the household-scale version of compute becoming heat.

## Sources

[^iea2025]: International Energy Agency, *Energy and AI* (2025).
[^lbnl2024]: Shehabi et al., *2024 United States Data Center Energy Usage Report* (2024).

