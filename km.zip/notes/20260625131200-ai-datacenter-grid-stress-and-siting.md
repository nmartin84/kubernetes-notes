---
id: "20260625131200"
title: "AI datacenter siting can turn global electricity growth into local grid stress"
short_title: "Grid stress"
tags: [ai, datacenters, electricity-grid, siting, infrastructure]
parent_tag: ai-datacenters
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: iea2025
    citation: "International Energy Agency - Energy and AI (2025)"
    url: "https://www.iea.org/reports/energy-and-ai"
  - id: chen2026
    citation: "Chen, D. et al. - Concentrated siting of AI data centers drives regional power-system stress under rising global compute demand (arXiv, 2026)"
    url: "https://arxiv.org/abs/2604.06198"
relations:
  - { type: extends, target: "20260625131000" }
  - { type: related, target: "20260625131100" }
  - { type: related, target: "20260625131600" }
  - { type: related, target: "20260625131700" }
visualization:
  kind: svg
  alt: "Many AI datacenters cluster around one constrained grid node, producing local bottlenecks even if the national grid has enough generation in aggregate."
---

## Core idea

AI datacenter impacts are highly local because large loads often cluster near fiber,
cheap land, tax incentives, and existing grid interconnection points [^iea2025].

## Elaboration

A global electricity share can look manageable while still causing severe local planning
problems. The IEA reports that nearly half of U.S. datacenter capacity is in five regional
clusters and that 50% of U.S. datacenters under development are in pre-existing large
clusters, raising bottleneck risk [^iea2025]. A 2026 modeling study similarly found that
concentrated AI compute capacity can create high regional power-system stress in places
such as Virginia, Oregon, and Ireland, even when more diversified systems absorb new load
more easily [^chen2026]. Siting is therefore an environmental variable, not just a real
estate decision.

## Visualization

<svg viewBox="0 0 640 310" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Datacenter clustering causes local grid stress">
  <rect width="640" height="310" fill="#0b1220"/>
  <circle cx="320" cy="158" r="62" fill="#111c33" stroke="#fbbf24" stroke-width="3"/>
  <text x="320" y="154" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">constrained</text>
  <text x="320" y="174" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">grid node</text>
  <g fill="#1d2a4d" stroke="#6366f1">
    <rect x="100" y="72" width="96" height="42" rx="7"/>
    <rect x="120" y="190" width="96" height="42" rx="7"/>
    <rect x="444" y="68" width="96" height="42" rx="7"/>
    <rect x="458" y="196" width="96" height="42" rx="7"/>
    <rect x="266" y="42" width="108" height="42" rx="7"/>
  </g>
  <g fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">
    <text x="148" y="98">AI DC</text><text x="168" y="216">AI DC</text>
    <text x="492" y="94">AI DC</text><text x="506" y="222">AI DC</text>
    <text x="320" y="68">AI DC</text>
  </g>
  <g stroke="#94a3b8" stroke-width="2">
    <line x1="196" y1="96" x2="270" y2="128"/>
    <line x1="216" y1="208" x2="270" y2="184"/>
    <line x1="444" y1="92" x2="370" y2="128"/>
    <line x1="458" y1="210" x2="370" y2="184"/>
    <line x1="320" y1="84" x2="320" y2="96"/>
  </g>
  <text x="320" y="276" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Concentrated load can create local bottlenecks before aggregate supply runs out.</text>
</svg>

## Connections

- It `extends` **AI datacenters** (20260625131000).
- It is `related` to **AI datacenter electricity demand** (20260625131100).
- It is `related` to **community environmental impacts** (20260625131600).
- It is `related` to **sustainability interventions** (20260625131700).

## Sources

[^iea2025]: International Energy Agency, *Energy and AI* (2025).
[^chen2026]: Chen et al., "Concentrated siting of AI data centers..." (2026 preprint).
