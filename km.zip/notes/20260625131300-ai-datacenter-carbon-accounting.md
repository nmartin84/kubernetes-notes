---
id: "20260625131300"
title: "AI datacenter carbon impact depends on marginal electricity, utilization, and accounting boundaries"
short_title: "Carbon accounting"
tags: [ai, datacenters, carbon-emissions, electricity, accounting]
parent_tag: ai-datacenters
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: iea2025
    citation: "International Energy Agency - Energy and AI (2025)"
    url: "https://www.iea.org/reports/energy-and-ai"
  - id: hyperscale2026
    citation: "Guidi, G. et al. - Assessing the Carbon Emissions and Energy Consumption of U.S. Hyperscale Data Centers (arXiv, 2026)"
    url: "https://arxiv.org/abs/2606.05420"
relations:
  - { type: extends, target: "20260625131000" }
  - { type: requires, target: "20260625131100" }
  - { type: related, target: "20260625131500" }
  - { type: related, target: "20260625131700" }
  - { type: related, target: "20260625131800" }
visualization:
  kind: svg
  alt: "Datacenter emissions are calculated from IT load, facility overhead, grid carbon intensity, utilization, and embodied hardware emissions."
---

## Core idea

The carbon impact of an AI datacenter is not determined by compute alone; it depends on
electricity quantity, grid carbon intensity, whether new load changes marginal generation,
facility overhead, utilization, and embodied hardware emissions [^iea2025].

## Elaboration

A clean annual power purchase agreement can reduce a company's market-based emissions
claim, but local and hourly grid effects still matter if the datacenter increases fossil
generation or delays fossil retirements. A 2026 preprint estimating U.S. hyperscale
datacenters found electricity consumption of roughly 68 to 99 TWh for 403 facilities from
May 2024 to April 2025, with associated emissions of about 37 to 54 million metric tons of
CO2 and an electricity-weighted carbon intensity above the national average in its central
scenario [^hyperscale2026]. Accounting boundaries also matter: prompt-level estimates can
look small, while fleet-level inference volume and embodied hardware can dominate total
impact.

## Visualization

<svg viewBox="0 0 640 320" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="AI datacenter carbon accounting components">
  <defs><marker id="carb" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="320" fill="#0b1220"/>
  <rect x="52" y="72" width="132" height="48" rx="8" fill="#111c33" stroke="#475569"/>
  <rect x="52" y="170" width="132" height="48" rx="8" fill="#111c33" stroke="#475569"/>
  <rect x="254" y="120" width="132" height="48" rx="8" fill="#1d2a4d" stroke="#6366f1"/>
  <rect x="456" y="72" width="132" height="48" rx="8" fill="#111c33" stroke="#475569"/>
  <rect x="456" y="170" width="132" height="48" rx="8" fill="#111c33" stroke="#475569"/>
  <g fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">
    <text x="118" y="101">IT load</text>
    <text x="118" y="199">PUE overhead</text>
    <text x="320" y="149">electricity use</text>
    <text x="522" y="101">grid carbon</text>
    <text x="522" y="199">embodied hardware</text>
  </g>
  <line x1="184" y1="96" x2="252" y2="132" stroke="#94a3b8" stroke-width="2" marker-end="url(#carb)"/>
  <line x1="184" y1="194" x2="252" y2="156" stroke="#94a3b8" stroke-width="2" marker-end="url(#carb)"/>
  <line x1="386" y1="132" x2="454" y2="96" stroke="#94a3b8" stroke-width="2" marker-end="url(#carb)"/>
  <line x1="386" y1="156" x2="454" y2="194" stroke="#94a3b8" stroke-width="2" marker-end="url(#carb)"/>
  <text x="320" y="268" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Carbon claims change when boundaries or hourly grid effects change.</text>
</svg>

## Connections

- It `extends` **AI datacenters** (20260625131000).
- It `requires` **AI datacenter electricity demand** (20260625131100).
- It is `related` to **hardware supply chains and e-waste** (20260625131500).
- It is `related` to **sustainability interventions** (20260625131700).
- It is `related` to **efficiency rebound and transparency** (20260625131800).

## Sources

[^iea2025]: International Energy Agency, *Energy and AI* (2025).
[^hyperscale2026]: Guidi et al., "Assessing the Carbon Emissions and Energy Consumption of U.S. Hyperscale Data Centers" (2026 preprint).
