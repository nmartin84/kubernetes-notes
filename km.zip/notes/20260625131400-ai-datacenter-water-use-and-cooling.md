---
id: "20260625131400"
title: "AI datacenter water impact depends on cooling design, power generation, and watershed stress"
short_title: "Cooling water"
tags: [ai, datacenters, water, cooling, environment]
parent_tag: ai-datacenters
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: mytton2021
    citation: "Mytton, D. - Data centre water consumption, npj Clean Water 4, 11 (2021)"
    url: "https://doi.org/10.1038/s41545-021-00101-w"
  - id: siddik2021
    citation: "Siddik, M. A. B., Shehabi, A., & Marston, L. - The environmental footprint of data centers in the United States, Environmental Research Letters 16, 064017 (2021)"
    url: "https://doi.org/10.1088/1748-9326/abfba1"
relations:
  - { type: extends, target: "20260625131000" }
  - { type: related, target: "20260625131100" }
  - { type: related, target: "20260625131600" }
  - { type: related, target: "20260625131700" }
visualization:
  kind: svg
  alt: "Datacenter water footprint is split into onsite cooling water, offsite electricity-generation water, and upstream semiconductor water."
---

## Core idea

AI datacenter water impact comes from direct cooling, indirect water used to generate
electricity, and upstream hardware manufacturing, and its severity depends on local water
stress [^mytton2021].

## Elaboration

Evaporative cooling can reduce electricity used for chillers, but it consumes water. Dry
or closed-loop cooling can reduce water use, but may raise electricity demand or capital
cost. This creates a water-energy tradeoff rather than a single best design for every
location. U.S. data-center water research also shows why local context matters: direct
water use in a water-stressed watershed has a different environmental meaning from the
same number of liters in a water-abundant region [^siddik2021]. Water Usage Effectiveness
helps compare onsite operations, but it does not by itself capture watershed stress or
electricity-related water use.

## Visualization

<svg viewBox="0 0 640 320" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="AI datacenter water footprint components">
  <defs><marker id="wat" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="320" fill="#0b1220"/>
  <rect x="244" y="120" width="152" height="62" rx="8" fill="#1d2a4d" stroke="#6366f1"/>
  <text x="320" y="148" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">AI datacenter</text>
  <text x="320" y="168" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">heat removal</text>
  <rect x="56" y="58" width="150" height="46" rx="8" fill="#111c33" stroke="#38bdf8"/>
  <rect x="434" y="58" width="150" height="46" rx="8" fill="#111c33" stroke="#38bdf8"/>
  <rect x="244" y="242" width="152" height="46" rx="8" fill="#111c33" stroke="#38bdf8"/>
  <g fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">
    <text x="131" y="86">onsite cooling</text>
    <text x="509" y="86">power generation</text>
    <text x="320" y="270">chip manufacturing</text>
  </g>
  <line x1="206" y1="86" x2="260" y2="122" stroke="#94a3b8" stroke-width="2" marker-end="url(#wat)"/>
  <line x1="434" y1="86" x2="380" y2="122" stroke="#94a3b8" stroke-width="2" marker-end="url(#wat)"/>
  <line x1="320" y1="242" x2="320" y2="184" stroke="#94a3b8" stroke-width="2" marker-end="url(#wat)"/>
</svg>

## Connections

- It `extends` **AI datacenters** (20260625131000).
- It is `related` to **AI datacenter electricity demand** (20260625131100).
- It is `related` to **community environmental impacts** (20260625131600).
- It is `related` to **sustainability interventions** (20260625131700).

## Sources

[^mytton2021]: Mytton, "Data centre water consumption" (2021).
[^siddik2021]: Siddik, Shehabi & Marston, "The environmental footprint of data centers in the United States" (2021).
