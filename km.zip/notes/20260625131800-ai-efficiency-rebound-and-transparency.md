---
id: "20260625131800"
title: "AI efficiency gains reduce unit impact but can increase total demand without transparency and limits"
short_title: "Rebound and transparency"
tags: [ai, datacenters, efficiency, rebound-effect, transparency]
parent_tag: ai-datacenters
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: iea2025
    citation: "International Energy Agency - Energy and AI (2025)"
    url: "https://www.iea.org/reports/energy-and-ai"
  - id: koomey2024
    citation: "Koomey, J. & Masanet, E. - To better understand AI's growing energy use, analysts need a data revolution, Joule (2024)"
    url: "https://doi.org/10.1016/j.joule.2024.04.015"
  - id: google2025
    citation: "Elsworth, C. et al. - Measuring the environmental impact of delivering AI at Google Scale (arXiv, 2025)"
    url: "https://arxiv.org/abs/2508.15734"
relations:
  - { type: extends, target: "20260625131000" }
  - { type: related, target: "20260625131100" }
  - { type: related, target: "20260625131300" }
  - { type: related, target: "20260625131500" }
  - { type: related, target: "20260625131700" }
visualization:
  kind: svg
  alt: "Efficiency lowers impact per AI task, but lower costs can increase task volume, making total impact depend on both unit efficiency and demand growth."
---

## Core idea

AI efficiency gains lower environmental impact per task, but total impact can still rise
if cheaper and better AI causes enough additional use, larger models, or more datacenter
buildout [^iea2025].

## Elaboration

This is a rebound problem. Better chips, models, and serving systems can reduce energy per
prompt or per training step, but lower cost often expands deployment. That makes aggregate
electricity, water, carbon, and hardware demand depend on both unit efficiency and total
volume. Transparency is the practical bottleneck: analysts need consistent facility-level,
workload-level, and supply-chain data to distinguish real efficiency progress from burden
shifting or accounting artifacts [^koomey2024]. Production studies can help when they make
the accounting boundary explicit, as in full-stack measurement of AI serving energy,
carbon, water, overhead, and idle capacity [^google2025].

## Visualization

<svg viewBox="0 0 640 320" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Efficiency rebound in AI datacenters">
  <rect width="640" height="320" fill="#0b1220"/>
  <line x1="86" y1="244" x2="560" y2="244" stroke="#475569" stroke-width="2"/>
  <line x1="86" y1="244" x2="86" y2="52" stroke="#475569" stroke-width="2"/>
  <path d="M104 86 C190 110, 270 138, 352 170 C430 200, 498 218, 548 226" fill="none" stroke="#22c55e" stroke-width="4"/>
  <path d="M104 226 C180 204, 254 164, 336 112 C420 60, 494 58, 548 70" fill="none" stroke="#6366f1" stroke-width="4"/>
  <path d="M104 196 C184 178, 270 150, 352 136 C432 126, 500 132, 548 142" fill="none" stroke="#fbbf24" stroke-width="4"/>
  <text x="390" y="88" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="13">use volume</text>
  <text x="390" y="216" fill="#86efac" font-family="system-ui,sans-serif" font-size="13">impact per task</text>
  <text x="390" y="144" fill="#fde68a" font-family="system-ui,sans-serif" font-size="13">total impact</text>
  <text x="320" y="282" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Total footprint can rise even as each task gets cleaner.</text>
</svg>

## Connections

- It `extends` **AI datacenters** (20260625131000).
- It is `related` to **AI datacenter electricity demand** (20260625131100).
- It is `related` to **carbon emissions accounting** (20260625131300).
- It is `related` to **hardware supply chains and e-waste** (20260625131500).
- It is `related` to **sustainability interventions** (20260625131700).

## Sources

[^iea2025]: International Energy Agency, *Energy and AI* (2025).
[^koomey2024]: Koomey & Masanet, "To better understand AI's growing energy use, analysts need a data revolution" (2024).
[^google2025]: Elsworth et al., "Measuring the environmental impact of delivering AI at Google Scale" (2025 preprint).
