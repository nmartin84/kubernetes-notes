---
id: "20260625131900"
title: "A PC's waste heat is most useful as space heating, not as recovered electricity"
short_title: "PC waste heat"
tags: [personal-computing, energy, heat, thermodynamics, sustainability]
parent_tag: practical-energy
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: cengel2015
    citation: "Cengel, Y. A. & Boles, M. A. - Thermodynamics: An Engineering Approach, 8th ed. (McGraw-Hill, 2015)"
  - id: goldsmid2010
    citation: "Goldsmid, H. J. - Introduction to Thermoelectricity (Springer, 2010)"
  - id: incropera2011
    citation: "Incropera, F. P. et al. - Fundamentals of Heat and Mass Transfer, 7th ed. (Wiley, 2011)"
relations:
  - { type: related, target: "20260625131100" }
  - { type: related, target: "20260625131700" }
visualization:
  kind: svg
  alt: "Electricity enters a PC, becomes computation and almost entirely low-grade heat, then either warms the room efficiently or is poorly recovered by a thermoelectric generator."
---

## Core idea

A regular person can most easily use a PC's waste heat by treating the PC as a space
heater; converting that low-temperature heat back into electricity is technically possible
but usually inefficient and impractical [^cengel2015].

## Elaboration

Almost all electrical power consumed by a PC eventually becomes heat in the room: CPU and
GPU switching losses, power-supply losses, fan power, storage activity, and monitor energy
all end up as thermal energy after the useful computation is done. A 500 W gaming PC is
therefore roughly a 500 W heater while it is running. If the room already needs heat, that
waste heat can offset other electric or fuel-based heating. If the room needs cooling, the
same heat becomes a burden because air conditioning must remove it.

Recovering electricity from PC heat is a poor everyday strategy. Thermoelectric generators
need a temperature difference between hot and cold sides, and their efficiency is low when
the heat source is only tens of degrees Celsius above room temperature [^goldsmid2010].
Adding a thermoelectric module can also make PC cooling worse unless the heat sink and
airflow are redesigned. Water heating is more plausible with a custom liquid loop and heat
exchanger, but it adds leak risk, maintenance, and complexity. For normal users, useful
space heating is the practical form of recovery [^incropera2011].

## Visualization

<svg viewBox="0 0 640 320" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="PC waste heat recovery options">
  <defs><marker id="pwh" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="320" fill="#0b1220"/>
  <rect x="42" y="126" width="126" height="58" rx="8" fill="#111c33" stroke="#475569"/>
  <text x="105" y="151" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">electricity</text>
  <text x="105" y="171" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">wall power</text>
  <rect x="238" y="112" width="164" height="86" rx="8" fill="#1d2a4d" stroke="#6366f1"/>
  <text x="320" y="145" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="14" text-anchor="middle">PC</text>
  <text x="320" y="167" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">compute becomes heat</text>
  <rect x="472" y="54" width="126" height="52" rx="8" fill="#102a1b" stroke="#22c55e"/>
  <text x="535" y="84" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">room heating</text>
  <rect x="472" y="204" width="126" height="52" rx="8" fill="#2b1520" stroke="#fb7185"/>
  <text x="535" y="227" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">tiny electrical</text>
  <text x="535" y="243" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">recovery</text>
  <line x1="168" y1="155" x2="236" y2="155" stroke="#94a3b8" stroke-width="2" marker-end="url(#pwh)"/>
  <line x1="402" y1="138" x2="470" y2="84" stroke="#94a3b8" stroke-width="2" marker-end="url(#pwh)"/>
  <line x1="402" y1="172" x2="470" y2="226" stroke="#94a3b8" stroke-width="2" marker-end="url(#pwh)"/>
  <text x="320" y="282" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Best ordinary use: put the heat where warmth is already useful.</text>
</svg>

## Connections

- It is `related` to **AI datacenter electricity demand** (20260625131100), because compute power becomes heat at every scale.
- It is `related` to **AI datacenter sustainability interventions** (20260625131700), because heat reuse and efficiency only help when measured at the system level.

## Sources

[^cengel2015]: Cengel & Boles, *Thermodynamics: An Engineering Approach* (2015), first-law framing of energy conversion and heat/work limits.
[^goldsmid2010]: Goldsmid, *Introduction to Thermoelectricity* (2010), thermoelectric conversion and temperature-difference dependence.
[^incropera2011]: Incropera et al., *Fundamentals of Heat and Mass Transfer* (2011), practical heat-transfer constraints for moving heat to a useful sink.
