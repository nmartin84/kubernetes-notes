---
id: "20260625132000"
title: "JOIN types in data engineering define how datasets are matched, preserved, or expanded"
short_title: "JOIN types"
tags: [data-engineering, sql, joins, databases, analytics]
parent_tag: data-engineering
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: postgres-joins
    citation: "PostgreSQL Documentation - Table Expressions: Joined Tables"
    url: "https://www.postgresql.org/docs/current/queries-table-expressions.html"
  - id: spark-joins
    citation: "Apache Spark SQL Documentation - JOIN"
    url: "https://spark.apache.org/docs/latest/sql-ref-syntax-qry-select-join.html"
  - id: duckdb-from-join
    citation: "DuckDB Documentation - FROM and JOIN Clauses"
    url: "https://duckdb.org/docs/current/sql/query_syntax/from.html"
relations:
  - { type: extended-by, target: "20260625132100" }
  - { type: extended-by, target: "20260625132200" }
  - { type: extended-by, target: "20260625132300" }
  - { type: extended-by, target: "20260625132400" }
  - { type: extended-by, target: "20260625132500" }
  - { type: extended-by, target: "20260625132600" }
  - { type: extended-by, target: "20260625132700" }
  - { type: extended-by, target: "20260625132800" }
visualization:
  kind: svg
  alt: "A map of join types showing matched rows, preserved unmatched rows, Cartesian expansion, existence filtering, anti filtering, self matching, and as-of temporal matching."
---

## Core idea

JOIN types define what a data pipeline does when it combines two datasets: keep only
matches, preserve unmatched rows, multiply combinations, filter by existence, compare a
relation to itself, or attach the nearest ordered record [^postgres-joins].

## Elaboration

In data engineering, join choice is a correctness decision before it is a performance
decision. An inner join can silently drop facts with missing dimension keys. An outer join
can preserve unmatched rows but introduces nulls that downstream transformations must
handle. A cross join can intentionally create combinations but can also explode row counts.
Semi and anti joins are common for existence checks and exception reporting in distributed
engines such as Spark [^spark-joins]. As-of joins appear in temporal analytics where each
left row needs the nearest qualifying right-side event, such as the most recent price before
a trade [^duckdb-from-join].

## Visualization

<svg viewBox="0 0 640 330" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Join type map">
  <defs><marker id="jt" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="330" fill="#0b1220"/>
  <rect x="244" y="126" width="152" height="70" rx="8" fill="#1d2a4d" stroke="#6366f1"/>
  <text x="320" y="155" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="14" text-anchor="middle">JOIN choice</text>
  <text x="320" y="176" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">row preservation rule</text>
  <g fill="#111c33" stroke="#475569">
    <rect x="44" y="44" width="122" height="42" rx="8"/>
    <rect x="258" y="42" width="122" height="42" rx="8"/>
    <rect x="474" y="44" width="122" height="42" rx="8"/>
    <rect x="44" y="238" width="122" height="42" rx="8"/>
    <rect x="258" y="246" width="122" height="42" rx="8"/>
    <rect x="474" y="238" width="122" height="42" rx="8"/>
  </g>
  <g fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">
    <text x="105" y="70">inner</text><text x="319" y="68">outer</text><text x="535" y="70">cross</text>
    <text x="105" y="264">semi / anti</text><text x="319" y="272">self</text><text x="535" y="264">as-of</text>
  </g>
  <line x1="166" y1="72" x2="246" y2="132" stroke="#94a3b8" stroke-width="2" marker-end="url(#jt)"/>
  <line x1="319" y1="84" x2="319" y2="124" stroke="#94a3b8" stroke-width="2" marker-end="url(#jt)"/>
  <line x1="474" y1="72" x2="394" y2="132" stroke="#94a3b8" stroke-width="2" marker-end="url(#jt)"/>
  <line x1="166" y1="252" x2="246" y2="190" stroke="#94a3b8" stroke-width="2" marker-end="url(#jt)"/>
  <line x1="319" y1="246" x2="319" y2="198" stroke="#94a3b8" stroke-width="2" marker-end="url(#jt)"/>
  <line x1="474" y1="252" x2="394" y2="190" stroke="#94a3b8" stroke-width="2" marker-end="url(#jt)"/>
</svg>

## Connections

- It is elaborated by notes on inner, outer, cross, semi, anti, self, as-of, and predicate-form joins.

## Sources

[^postgres-joins]: PostgreSQL Documentation, "Table Expressions," joined tables section.
[^spark-joins]: Apache Spark SQL Documentation, "JOIN."
[^duckdb-from-join]: DuckDB Documentation, "FROM and JOIN Clauses."