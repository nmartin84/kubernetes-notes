---
id: "20260625132800"
title: "JOIN predicate forms control both matching logic and output schema"
short_title: "Join predicates"
tags: [data-engineering, sql, joins, predicates, schema]
parent_tag: data-engineering
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: postgres-joins
    citation: "PostgreSQL Documentation - Table Expressions: Joined Tables"
    url: "https://www.postgresql.org/docs/current/queries-table-expressions.html"
  - id: spark-joins
    citation: "Apache Spark SQL Documentation - JOIN"
    url: "https://spark.apache.org/docs/latest/sql-ref-syntax-qry-select-join.html"
relations:
  - { type: extends, target: "20260625132000" }
visualization:
  kind: svg
  alt: "ON, USING, and NATURAL are shown as three ways to define join predicates, with NATURAL marked as schema-change sensitive."
---

## Core idea

JOIN predicates define which rows match, and SQL forms such as `ON`, `USING`, and `NATURAL`
also influence the output columns [^postgres-joins].

## Elaboration

`ON` is the most general join predicate form because it accepts a boolean expression.
`USING` is shorthand for equality comparisons over same-named columns and suppresses the
duplicate output columns for those keys [^postgres-joins]. `NATURAL` builds a `USING` list
from all column names common to both inputs, which makes it concise but risky in data
engineering: a later schema change that adds a same-named column can silently change the
join condition [^postgres-joins]. Spark SQL supports `ON` and `USING` as join criteria and
also supports natural join syntax [^spark-joins].

## Visualization

<svg viewBox="0 0 640 280" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Join predicate forms">
  <defs><marker id="jp" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="280" fill="#0b1220"/>
  <rect x="250" y="112" width="140" height="54" rx="8" fill="#1d2a4d" stroke="#6366f1"/>
  <text x="320" y="145" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">join match</text>
  <g fill="#111c33" stroke="#475569">
    <rect x="70" y="54" width="122" height="44" rx="8"/>
    <rect x="259" y="38" width="122" height="44" rx="8"/>
    <rect x="448" y="54" width="122" height="44" rx="8"/>
  </g>
  <g fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">
    <text x="131" y="81">ON boolean</text>
    <text x="320" y="65">USING keys</text>
    <text x="509" y="81">NATURAL</text>
  </g>
  <text x="509" y="116" fill="#fb7185" font-family="system-ui,sans-serif" font-size="11" text-anchor="middle">schema sensitive</text>
  <line x1="192" y1="82" x2="258" y2="114" stroke="#94a3b8" stroke-width="2" marker-end="url(#jp)"/>
  <line x1="320" y1="82" x2="320" y2="110" stroke="#94a3b8" stroke-width="2" marker-end="url(#jp)"/>
  <line x1="448" y1="82" x2="382" y2="114" stroke="#94a3b8" stroke-width="2" marker-end="url(#jp)"/>
  <text x="320" y="224" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Predicate form changes matching and sometimes output schema.</text>
</svg>

## Connections

- It `extends` **JOIN types in data engineering** (20260625132000).

## Sources

[^postgres-joins]: PostgreSQL Documentation, "Table Expressions," joined tables section.
[^spark-joins]: Apache Spark SQL Documentation, "JOIN."