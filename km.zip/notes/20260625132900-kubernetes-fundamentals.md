---
id: "20260625132900"
title: "Kubernetes manages containerized applications by reconciling declared desired state"
short_title: "Kubernetes fundamentals"
tags: [kubernetes, containers, orchestration, platform-engineering]
parent_tag: kubernetes
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: k8s-overview
    citation: "Kubernetes Documentation - Overview"
    url: "https://kubernetes.io/docs/concepts/overview/"
  - id: k8s-objects
    citation: "Kubernetes Documentation - Kubernetes Objects"
    url: "https://kubernetes.io/docs/concepts/overview/working-with-objects/"
relations:
  - { type: extended-by, target: "20260625133000" }
  - { type: extended-by, target: "20260625133100" }
  - { type: extended-by, target: "20260625133200" }
  - { type: extended-by, target: "20260625133300" }
  - { type: extended-by, target: "20260625133400" }
  - { type: extended-by, target: "20260625133500" }
  - { type: extended-by, target: "20260625133600" }
  - { type: extended-by, target: "20260625133700" }
  - { type: extended-by, target: "20260625133800" }
visualization:
  kind: svg
  alt: "Desired state enters the Kubernetes API; controllers reconcile actual workloads toward it."
---

## Core idea

Kubernetes is a container orchestration platform where users declare desired state and the system continuously works to make actual cluster state match it [^k8s-overview].

## Elaboration

The core mental model is reconciliation. Users submit API objects that describe intent: workloads, replica counts, networking, configuration, and storage. Kubernetes control loops observe current state and take actions to reduce the difference between current and desired state [^k8s-objects]. This is why Kubernetes is normally operated through durable object definitions rather than one-off container start commands.

## Visualization

<svg viewBox="0 0 640 260" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Kubernetes reconciliation loop"><defs><marker id="a" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs><rect width="640" height="260" fill="#0b1220"/><rect x="50" y="100" width="130" height="54" rx="8" fill="#111c33" stroke="#475569"/><text x="115" y="132" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">desired state</text><rect x="255" y="82" width="130" height="90" rx="8" fill="#1d2a4d" stroke="#6366f1"/><text x="320" y="118" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">API + controllers</text><text x="320" y="142" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">reconcile</text><rect x="460" y="100" width="130" height="54" rx="8" fill="#102a1b" stroke="#22c55e"/><text x="525" y="132" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">actual state</text><line x1="180" y1="127" x2="253" y2="127" stroke="#94a3b8" stroke-width="2" marker-end="url(#a)"/><line x1="385" y1="127" x2="458" y2="127" stroke="#94a3b8" stroke-width="2" marker-end="url(#a)"/></svg>

## Connections

- It is elaborated by notes on cluster architecture, API objects, Pods, Deployments, Services, Ingress, Namespaces/labels, ConfigMaps/Secrets, and Volumes.

## Sources

[^k8s-overview]: Kubernetes Documentation, "Overview."
[^k8s-objects]: Kubernetes Documentation, "Kubernetes Objects."