---
id: "20260625133000"
title: "A Kubernetes cluster separates control-plane decisions from worker-node execution"
short_title: "Cluster architecture"
tags: [kubernetes, cluster-architecture, control-plane, nodes]
parent_tag: kubernetes
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: k8s-architecture
    citation: "Kubernetes Documentation - Cluster Architecture"
    url: "https://kubernetes.io/docs/concepts/architecture/"
relations:
  - { type: extends, target: "20260625132900" }
visualization:
  kind: svg
  alt: "The control plane contains API, scheduler, controllers, and state storage; worker nodes run Pods."
---

## Core idea

A Kubernetes cluster has a control plane that makes and records cluster-level decisions, and worker nodes that run application Pods [^k8s-architecture].

## Elaboration

The control plane exposes the API server, stores cluster state, schedules Pods, and runs controllers. Worker nodes provide compute capacity and run components such as kubelet and a container runtime so Pods can be started, monitored, and reported back [^k8s-architecture]. This split lets users interact with one API while the cluster distributes work across nodes.

## Visualization

<svg viewBox="0 0 640 260" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Control plane and worker nodes"><rect width="640" height="260" fill="#0b1220"/><rect x="58" y="54" width="220" height="150" rx="10" fill="#1d2a4d" stroke="#6366f1"/><text x="168" y="86" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="14" text-anchor="middle">control plane</text><text x="168" y="120" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">API, scheduler, controllers</text><rect x="360" y="54" width="220" height="150" rx="10" fill="#102a1b" stroke="#22c55e"/><text x="470" y="86" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="14" text-anchor="middle">worker nodes</text><text x="470" y="120" fill="#86efac" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">kubelet, runtime, Pods</text></svg>

## Connections

- It `extends` **Kubernetes fundamentals** (20260625132900).

## Sources

[^k8s-architecture]: Kubernetes Documentation, "Cluster Architecture."