---
id: "20260625133100"
title: "Kubernetes objects are persistent API records of desired cluster state"
short_title: "API objects"
tags: [kubernetes, api, objects, desired-state]
parent_tag: kubernetes
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: k8s-objects
    citation: "Kubernetes Documentation - Kubernetes Objects"
    url: "https://kubernetes.io/docs/concepts/overview/working-with-objects/"
relations:
  - { type: extends, target: "20260625132900" }
visualization:
  kind: svg
  alt: "A Kubernetes object has metadata, spec, and status fields."
---

## Core idea

Kubernetes objects are persistent records in the Kubernetes API that represent desired state for cluster resources and the observed status of those resources [^k8s-objects].

## Elaboration

A typical Kubernetes object has metadata, a `spec` that describes intended state, and a `status` that records current observed state. Controllers use those fields to reconcile resources. For example, a Deployment spec can declare how many replicas should exist, while status reports whether the rollout has achieved that state [^k8s-objects].

## Visualization

<svg viewBox="0 0 640 260" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Kubernetes object anatomy"><rect width="640" height="260" fill="#0b1220"/><rect x="210" y="46" width="220" height="168" rx="10" fill="#1d2a4d" stroke="#6366f1"/><text x="320" y="76" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="14" text-anchor="middle">Kubernetes object</text><g fill="#111c33" stroke="#475569"><rect x="238" y="100" width="164" height="28" rx="6"/><rect x="238" y="138" width="164" height="28" rx="6"/><rect x="238" y="176" width="164" height="28" rx="6"/></g><g fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle"><text x="320" y="119">metadata</text><text x="320" y="157">spec</text><text x="320" y="195">status</text></g></svg>

## Connections

- It `extends` **Kubernetes fundamentals** (20260625132900).

## Sources

[^k8s-objects]: Kubernetes Documentation, "Kubernetes Objects."