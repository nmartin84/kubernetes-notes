---
id: "20260625133300"
title: "A Deployment manages replicated Pods and performs rollout changes declaratively"
short_title: "Deployments"
tags: [kubernetes, deployments, workloads, rollouts]
parent_tag: kubernetes
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: k8s-deployments
    citation: "Kubernetes Documentation - Deployments"
    url: "https://kubernetes.io/docs/concepts/workloads/controllers/deployment/"
relations:
  - { type: extends, target: "20260625132900" }
  - { type: related, target: "20260625133200" }
  - { type: related, target: "20260625133400" }
visualization:
  kind: svg
  alt: "A Deployment owns a ReplicaSet, which maintains multiple Pods."
---

## Core idea

A Deployment is a workload controller that declaratively manages replicated Pods and updates them through controlled rollouts [^k8s-deployments].

## Elaboration

Deployments are the common default for stateless applications. The user declares a Pod template and replica count; Kubernetes creates lower-level ReplicaSets and Pods to satisfy that desired state. When the template changes, such as using a new container image, the Deployment can roll out the change while tracking progress [^k8s-deployments].

## Visualization

<svg viewBox="0 0 640 260" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Deployment to Pods"><defs><marker id="d" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs><rect width="640" height="260" fill="#0b1220"/><rect x="70" y="104" width="124" height="48" rx="8" fill="#1d2a4d" stroke="#6366f1"/><text x="132" y="133" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Deployment</text><rect x="258" y="104" width="124" height="48" rx="8" fill="#111c33" stroke="#475569"/><text x="320" y="133" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">ReplicaSet</text><g fill="#102a1b" stroke="#22c55e"><rect x="472" y="58" width="80" height="34" rx="7"/><rect x="472" y="112" width="80" height="34" rx="7"/><rect x="472" y="166" width="80" height="34" rx="7"/></g><g fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle"><text x="512" y="80">Pod</text><text x="512" y="134">Pod</text><text x="512" y="188">Pod</text></g><line x1="194" y1="128" x2="256" y2="128" stroke="#94a3b8" stroke-width="2" marker-end="url(#d)"/><line x1="382" y1="128" x2="470" y2="128" stroke="#94a3b8" stroke-width="2" marker-end="url(#d)"/></svg>

## Connections

- It `extends` **Kubernetes fundamentals** (20260625132900).
- It is `related` to **Pods** (20260625133200).
- It is `related` to **Services** (20260625133400).

## Sources

[^k8s-deployments]: Kubernetes Documentation, "Deployments."