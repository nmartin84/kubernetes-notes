---
id: "20260625133400"
title: "A Service gives stable network access to changing sets of Kubernetes Pods"
short_title: "Services"
tags: [kubernetes, services, networking, service-discovery]
parent_tag: kubernetes
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: k8s-service
    citation: "Kubernetes Documentation - Service"
    url: "https://kubernetes.io/docs/concepts/services-networking/service/"
relations:
  - { type: extends, target: "20260625132900" }
  - { type: related, target: "20260625133300" }
  - { type: related, target: "20260625133500" }
visualization:
  kind: svg
  alt: "A Service selects multiple Pods and provides one stable endpoint for clients."
---

## Core idea

A Kubernetes Service provides a stable network abstraction for accessing a changing set of Pods selected by labels [^k8s-service].

## Elaboration

Pods are replaceable and receive their own IP addresses, so clients should not depend on a particular Pod IP. A Service defines how to find a group of Pods and gives clients a stable name and virtual endpoint for reaching them [^k8s-service]. This is the foundation of Kubernetes service discovery and load distribution inside the cluster.

## Visualization

<svg viewBox="0 0 640 260" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Service selects Pods"><defs><marker id="s" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs><rect width="640" height="260" fill="#0b1220"/><rect x="66" y="104" width="110" height="48" rx="8" fill="#111c33" stroke="#475569"/><text x="121" y="133" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">client</text><rect x="266" y="90" width="110" height="76" rx="8" fill="#1d2a4d" stroke="#6366f1"/><text x="321" y="121" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Service</text><text x="321" y="143" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">stable DNS/IP</text><g fill="#102a1b" stroke="#22c55e"><rect x="480" y="52" width="78" height="32" rx="7"/><rect x="480" y="112" width="78" height="32" rx="7"/><rect x="480" y="172" width="78" height="32" rx="7"/></g><g fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle"><text x="519" y="73">Pod</text><text x="519" y="133">Pod</text><text x="519" y="193">Pod</text></g><line x1="176" y1="128" x2="264" y2="128" stroke="#94a3b8" stroke-width="2" marker-end="url(#s)"/><line x1="376" y1="128" x2="478" y2="128" stroke="#94a3b8" stroke-width="2" marker-end="url(#s)"/></svg>

## Connections

- It `extends` **Kubernetes fundamentals** (20260625132900).
- It is `related` to **Deployments** (20260625133300).
- It is `related` to **Ingress** (20260625133500).

## Sources

[^k8s-service]: Kubernetes Documentation, "Service."