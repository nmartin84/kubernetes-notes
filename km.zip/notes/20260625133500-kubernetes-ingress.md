---
id: "20260625133500"
title: "Ingress routes external HTTP and HTTPS traffic to Services inside a Kubernetes cluster"
short_title: "Ingress"
tags: [kubernetes, ingress, networking, http]
parent_tag: kubernetes
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: k8s-ingress
    citation: "Kubernetes Documentation - Ingress"
    url: "https://kubernetes.io/docs/concepts/services-networking/ingress/"
relations:
  - { type: extends, target: "20260625132900" }
  - { type: related, target: "20260625133400" }
visualization:
  kind: svg
  alt: "External HTTP traffic enters an Ingress, which routes by host or path to internal Services."
---

## Core idea

Ingress is a Kubernetes API object for managing external HTTP and HTTPS access to Services inside a cluster [^k8s-ingress].

## Elaboration

A Service gives stable access to Pods, but it does not by itself define HTTP host or path routing rules. Ingress supplies those routing rules, such as sending requests for one host or path to one Service and another path to a different Service [^k8s-ingress]. An Ingress controller is required to implement the rules.

## Visualization

<svg viewBox="0 0 640 260" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Ingress routes HTTP to Services"><defs><marker id="i" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs><rect width="640" height="260" fill="#0b1220"/><rect x="62" y="104" width="108" height="48" rx="8" fill="#111c33" stroke="#475569"/><text x="116" y="133" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">internet</text><rect x="262" y="84" width="116" height="88" rx="8" fill="#1d2a4d" stroke="#6366f1"/><text x="320" y="119" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Ingress</text><text x="320" y="142" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">routes</text><rect x="480" y="66" width="104" height="40" rx="8" fill="#102a1b" stroke="#22c55e"/><rect x="480" y="154" width="104" height="40" rx="8" fill="#102a1b" stroke="#22c55e"/><text x="532" y="91" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">Service A</text><text x="532" y="179" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">Service B</text><line x1="170" y1="128" x2="260" y2="128" stroke="#94a3b8" stroke-width="2" marker-end="url(#i)"/><line x1="378" y1="112" x2="478" y2="88" stroke="#94a3b8" stroke-width="2" marker-end="url(#i)"/><line x1="378" y1="144" x2="478" y2="174" stroke="#94a3b8" stroke-width="2" marker-end="url(#i)"/></svg>

## Connections

- It `extends` **Kubernetes fundamentals** (20260625132900).
- It is `related` to **Services** (20260625133400).

## Sources

[^k8s-ingress]: Kubernetes Documentation, "Ingress."