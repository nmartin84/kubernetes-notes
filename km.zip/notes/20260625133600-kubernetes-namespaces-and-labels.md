---
id: "20260625133600"
title: "Namespaces group Kubernetes resources while labels select and connect them"
short_title: "Namespaces and labels"
tags: [kubernetes, namespaces, labels, selectors, organization]
parent_tag: kubernetes
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: k8s-namespaces
    citation: "Kubernetes Documentation - Namespaces"
    url: "https://kubernetes.io/docs/concepts/overview/working-with-objects/namespaces/"
  - id: k8s-labels
    citation: "Kubernetes Documentation - Labels and Selectors"
    url: "https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/"
relations:
  - { type: extends, target: "20260625132900" }
visualization:
  kind: svg
  alt: "Namespace boxes contain objects; labels attach to objects and selectors choose matching objects."
---

## Core idea

Namespaces provide scoped groupings for Kubernetes resources, while labels and selectors identify sets of objects for organization and loose coupling [^k8s-namespaces] [^k8s-labels].

## Elaboration

Namespaces are useful when many teams, environments, or applications share a cluster. They scope names and can become boundaries for policies and quotas, but they are not complete isolation by themselves [^k8s-namespaces]. Labels are key-value pairs attached to objects, and selectors query those labels so Services, controllers, and commands can refer to dynamic sets of resources [^k8s-labels].

## Visualization

<svg viewBox="0 0 640 260" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Namespaces and labels"><rect width="640" height="260" fill="#0b1220"/><rect x="70" y="58" width="220" height="132" rx="10" fill="#1d2a4d" stroke="#6366f1"/><rect x="350" y="58" width="220" height="132" rx="10" fill="#102a1b" stroke="#22c55e"/><text x="180" y="88" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">namespace: dev</text><text x="460" y="88" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">namespace: prod</text><g fill="#111c33" stroke="#475569"><rect x="105" y="118" width="72" height="32" rx="7"/><rect x="190" y="118" width="72" height="32" rx="7"/><rect x="385" y="118" width="72" height="32" rx="7"/><rect x="470" y="118" width="72" height="32" rx="7"/></g><g fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="11" text-anchor="middle"><text x="141" y="139">app=api</text><text x="226" y="139">app=web</text><text x="421" y="139">app=api</text><text x="506" y="139">app=web</text></g></svg>

## Connections

- It `extends` **Kubernetes fundamentals** (20260625132900).

## Sources

[^k8s-namespaces]: Kubernetes Documentation, "Namespaces."
[^k8s-labels]: Kubernetes Documentation, "Labels and Selectors."