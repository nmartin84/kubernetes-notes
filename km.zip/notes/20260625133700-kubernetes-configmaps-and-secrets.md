---
id: "20260625133700"
title: "ConfigMaps and Secrets externalize application configuration from container images"
short_title: "Config and Secrets"
tags: [kubernetes, configmaps, secrets, configuration]
parent_tag: kubernetes
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: k8s-configmap
    citation: "Kubernetes Documentation - ConfigMaps"
    url: "https://kubernetes.io/docs/concepts/configuration/configmap/"
  - id: k8s-secret
    citation: "Kubernetes Documentation - Secrets"
    url: "https://kubernetes.io/docs/concepts/configuration/secret/"
relations:
  - { type: extends, target: "20260625132900" }
visualization:
  kind: svg
  alt: "A Pod receives non-sensitive settings from a ConfigMap and sensitive values from a Secret."
---

## Core idea

ConfigMaps and Secrets let Kubernetes provide configuration data to Pods without baking that data into container images [^k8s-configmap] [^k8s-secret].

## Elaboration

A ConfigMap stores non-confidential configuration such as flags, URLs, or config files. A Secret stores sensitive data such as credentials, tokens, or keys, although secure use still requires appropriate access control and encryption choices [^k8s-secret]. Pods can consume both through environment variables, command arguments, or mounted files.

## Visualization

<svg viewBox="0 0 640 260" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="ConfigMaps and Secrets feed Pods"><defs><marker id="c" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs><rect width="640" height="260" fill="#0b1220"/><rect x="80" y="62" width="128" height="44" rx="8" fill="#111c33" stroke="#475569"/><text x="144" y="89" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">ConfigMap</text><rect x="80" y="154" width="128" height="44" rx="8" fill="#2b1520" stroke="#fb7185"/><text x="144" y="181" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Secret</text><rect x="420" y="92" width="138" height="76" rx="10" fill="#1d2a4d" stroke="#6366f1"/><text x="489" y="124" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="14" text-anchor="middle">Pod</text><text x="489" y="146" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">env vars / files</text><line x1="208" y1="84" x2="418" y2="116" stroke="#94a3b8" stroke-width="2" marker-end="url(#c)"/><line x1="208" y1="176" x2="418" y2="146" stroke="#94a3b8" stroke-width="2" marker-end="url(#c)"/></svg>

## Connections

- It `extends` **Kubernetes fundamentals** (20260625132900).

## Sources

[^k8s-configmap]: Kubernetes Documentation, "ConfigMaps."
[^k8s-secret]: Kubernetes Documentation, "Secrets."