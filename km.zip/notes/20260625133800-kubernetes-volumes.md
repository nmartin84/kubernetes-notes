---
id: "20260625133800"
title: "Kubernetes Volumes give containers storage that is separate from the container image"
short_title: "Volumes"
tags: [kubernetes, volumes, storage, pods]
parent_tag: kubernetes
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: k8s-volumes
    citation: "Kubernetes Documentation - Volumes"
    url: "https://kubernetes.io/docs/concepts/storage/volumes/"
relations:
  - { type: extends, target: "20260625132900" }
  - { type: related, target: "20260625133200" }
visualization:
  kind: svg
  alt: "A Pod mounts a Volume into one or more containers so data is available outside the container image filesystem."
---

## Core idea

A Kubernetes Volume provides storage that can be mounted into containers in a Pod and is managed separately from the container image filesystem [^k8s-volumes].

## Elaboration

Container filesystems are usually ephemeral from the application's point of view: when a container is replaced, local changes can disappear. Volumes solve different storage needs, from sharing files between containers in one Pod to mounting persistent storage backed by a storage provider [^k8s-volumes]. The exact lifecycle depends on the Volume type.

## Visualization

<svg viewBox="0 0 640 260" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Volume mounted into a Pod"><defs><marker id="v" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs><rect width="640" height="260" fill="#0b1220"/><rect x="160" y="48" width="320" height="166" rx="12" fill="#1d2a4d" stroke="#6366f1"/><text x="320" y="78" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="15" text-anchor="middle">Pod</text><rect x="206" y="110" width="86" height="42" rx="8" fill="#111c33" stroke="#475569"/><rect x="348" y="110" width="86" height="42" rx="8" fill="#111c33" stroke="#475569"/><text x="249" y="136" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">container</text><text x="391" y="136" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">container</text><rect x="252" y="176" width="136" height="32" rx="8" fill="#102a1b" stroke="#22c55e"/><text x="320" y="197" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">Volume</text><line x1="249" y1="152" x2="292" y2="174" stroke="#94a3b8" stroke-width="2" marker-end="url(#v)"/><line x1="391" y1="152" x2="348" y2="174" stroke="#94a3b8" stroke-width="2" marker-end="url(#v)"/></svg>

## Connections

- It `extends` **Kubernetes fundamentals** (20260625132900).
- It is `related` to **Pods** (20260625133200).

## Sources

[^k8s-volumes]: Kubernetes Documentation, "Volumes."