---
id: "20260625133900"
title: "Orch-OR is a controversial hypothesis that links consciousness to quantum processes in the brain"
short_title: "Quantum consciousness hypothesis"
tags: [consciousness, quantum-theory, orch-or, neuroscience, philosophy-of-mind]
parent_tag: consciousness
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: hameroffpenrose2014
    citation: "Hameroff, S. & Penrose, R. - Consciousness in the universe: A review of the 'Orch OR' theory, Physics of Life Reviews 11, 39-78 (2014)"
    url: "https://doi.org/10.1016/j.plrev.2013.08.002"
  - id: tegmark2000
    citation: "Tegmark, M. - Importance of quantum decoherence in brain processes, Physical Review E 61, 4194-4206 (2000)"
    url: "https://doi.org/10.1103/PhysRevE.61.4194"
  - id: chalmers1995
    citation: "Chalmers, D. J. - Facing up to the problem of consciousness, Journal of Consciousness Studies 2(3), 200-219 (1995)"
relations:
  - { type: extends, target: "20260625130700" }
  - { type: related, target: "20260625130500" }
  - { type: related, target: "20260625130800" }
visualization:
  kind: svg
  alt: "The Orch-OR hypothesis links microtubule quantum states and objective reduction to conscious moments, while a critique path marks decoherence and lack of consensus."
---

## Core idea

Orch-OR is a controversial quantum-consciousness hypothesis: it proposes that consciousness
is connected to orchestrated quantum processes in neuronal microtubules, but it is not a
scientific consensus that consciousness exists independently of the brain or simply "runs
on quantum mechanics" [^hameroffpenrose2014].

## Elaboration

Hameroff and Penrose argue that moments of consciousness are associated with orchestrated
objective reductions of quantum states in microtubules inside neurons [^hameroffpenrose2014].
This makes Orch-OR different from ordinary brain-as-classical-computer accounts and gives
it a direct link to the hard problem of consciousness: the theory tries to explain why
physical processing is accompanied by subjective experience [^chalmers1995]. The careful
version of the claim is not that the brain is irrelevant, but that some brain processes may
have a quantum-gravitational ingredient that standard neuroscience does not capture.

The theory remains contested. A major objection is that warm biological tissue should cause
relevant quantum states to decohere too quickly for the proposed role in cognition or
consciousness [^tegmark2000]. Therefore, the note should be understood as a description of
a minority hypothesis and its motivation, not as a settled conclusion that scientists in
general believe consciousness comes from outside the brain.

## Visualization

<svg viewBox="0 0 640 320" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Orch-OR quantum consciousness hypothesis and critique">
  <defs><marker id="qch" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="320" fill="#0b1220"/>
  <rect x="58" y="92" width="142" height="58" rx="8" fill="#111c33" stroke="#475569"/>
  <text x="129" y="116" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">neurons</text>
  <text x="129" y="137" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">brain substrate</text>
  <rect x="248" y="72" width="150" height="78" rx="8" fill="#1d2a4d" stroke="#6366f1"/>
  <text x="323" y="101" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">microtubules</text>
  <text x="323" y="123" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">proposed quantum states</text>
  <rect x="448" y="92" width="142" height="58" rx="8" fill="#102a1b" stroke="#22c55e"/>
  <text x="519" y="116" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">conscious moment</text>
  <text x="519" y="137" fill="#86efac" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">Orch-OR claim</text>
  <rect x="248" y="214" width="150" height="54" rx="8" fill="#2b1520" stroke="#fb7185"/>
  <text x="323" y="237" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">decoherence</text>
  <text x="323" y="255" fill="#fda4af" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">major critique</text>
  <line x1="200" y1="121" x2="246" y2="112" stroke="#94a3b8" stroke-width="2" marker-end="url(#qch)"/>
  <line x1="398" y1="112" x2="446" y2="121" stroke="#94a3b8" stroke-width="2" marker-end="url(#qch)"/>
  <line x1="323" y1="152" x2="323" y2="212" stroke="#fb7185" stroke-width="2" stroke-dasharray="7 7" marker-end="url(#qch)"/>
  <text x="320" y="294" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">A proposed brain-based quantum mechanism, not a settled consensus.</text>
</svg>

## Connections

- It `extends` **Orch-OR** (20260625130700) by separating the popular claim from the narrower theory.
- It is `related` to the **hard problem of consciousness** (20260625130500), which motivates quantum-consciousness theories.
- It is `related` to **Tegmark's brain-decoherence critique** (20260625130800), a major objection to quantum-brain proposals.

## Sources

[^hameroffpenrose2014]: Hameroff & Penrose, "Consciousness in the universe" (2014).
[^tegmark2000]: Tegmark, "Importance of quantum decoherence in brain processes" (2000).
[^chalmers1995]: Chalmers, "Facing up to the problem of consciousness" (1995).