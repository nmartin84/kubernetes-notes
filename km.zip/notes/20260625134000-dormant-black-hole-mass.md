---
id: "20260625134000"
title: "JWST made the first stellar-dynamical mass measurement of a dormant black hole in the distant universe"
short_title: "Dormant BH at z≈2"
tags: [astronomy, black-holes, supermassive-black-holes, jwst, gravitational-lensing, stellar-dynamics, early-universe]
parent_tag: black-holes
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: newman2026
    citation: "Newman, A. B., et al. (2026), 'A stellar dynamical mass measurement of an inactive black hole at redshift 2', Science 392(6802), 1065–1068"
    url: "https://arxiv.org/abs/2503.17478"
  - id: ucl2026
    citation: "University College London News (2026), 'Researchers weigh the most distant dormant black hole'"
    url: "https://www.ucl.ac.uk/news/2026/jun/researchers-weigh-most-distant-dormant-black-hole"
relations:
  - { type: example-of, target: "20260625120000" }
  - { type: related, target: "20260625120500" }
visualization:
  kind: svg
  alt: "A pipeline: the lensed galaxy MRG-M0138 at z = 1.95, magnified ~30x by a foreground galaxy-cluster lens, lets JWST resolve stellar motions inside the black hole's sphere of influence, yielding a dormant black hole mass of about 6 billion solar masses."
---

## Core idea

Astronomers used JWST to make the first **stellar-dynamical** mass measurement of a
*dormant* (non-accreting) supermassive black hole in the distant universe — weighing the
black hole at the centre of the gravitationally lensed galaxy MRG-M0138 (z = 1.95) at about
**6 × 10⁹ solar masses** (6.0 ₋₁.₇⁺²·¹ × 10⁹ M☉) [^newman2026].

## Elaboration

Most distant black holes are weighed only when they are *active* — blazing as quasars or
active galactic nuclei as gas falls in. This one is **dormant**: it emits essentially no
light of its own, so its presence could previously only be assumed. Its mass was instead
inferred purely from the **gravitational pull on surrounding stars** [^ucl2026].

- **Method — stellar dynamics.** JWST integral-field spectroscopy spatially resolved the
  velocities of stars within the black hole's *sphere of influence* (the region where its
  gravity dominates stellar motion); dynamical modelling then converted those velocities
  into a mass [^newman2026].
- **Enabled by gravitational lensing.** A foreground galaxy cluster magnifies MRG-M0138 by
  roughly 30× and produces multiple lensed images, which is what made it possible to resolve
  the tiny central region from ~10 billion light-years away. The result is about **15× more
  distant** than any previous stellar-dynamical black-hole mass [^ucl2026].
- **Significance.** The black hole is *overmassive* relative to its host galaxy's bulge mass
  (though still consistent with the black hole–stellar velocity dispersion correlation),
  supporting the picture that some supermassive black holes grew rapidly — even outpacing
  their galaxies — in the early universe [^newman2026].

## Visualization

<svg viewBox="0 0 640 260" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Lensed galaxy MRG-M0138 magnified ~30x lets JWST resolve stellar motions in the black hole's sphere of influence, giving a mass near 6 billion solar masses">
  <defs><marker id="ah" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs>
  <rect width="640" height="260" fill="#0b1220"/>
  <text x="320" y="34" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="14" text-anchor="middle">First stellar-dynamical mass of a dormant black hole (z ≈ 2)</text>
  <rect x="8" y="100" width="150" height="80" rx="8" fill="#111c33" stroke="#475569"/>
  <text x="83" y="135" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle"><tspan x="83">Galaxy MRG-M0138</tspan><tspan x="83" dy="18">z = 1.95</tspan></text>
  <rect x="178" y="100" width="150" height="80" rx="8" fill="#111c33" stroke="#475569"/>
  <text x="253" y="135" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle"><tspan x="253">Cluster lens</tspan><tspan x="253" dy="18">~30× magnification</tspan></text>
  <rect x="348" y="100" width="150" height="80" rx="8" fill="#111c33" stroke="#475569"/>
  <text x="423" y="127" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle"><tspan x="423">JWST stellar</tspan><tspan x="423" dy="18">dynamics in</tspan><tspan x="423" dy="18">sphere of influence</tspan></text>
  <rect x="518" y="100" width="114" height="80" rx="8" fill="#1d2a4d" stroke="#6366f1"/>
  <text x="575" y="135" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle"><tspan x="575">Dormant BH</tspan><tspan x="575" dy="18">~6×10⁹ M☉</tspan></text>
  <line x1="158" y1="140" x2="176" y2="140" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="328" y1="140" x2="346" y2="140" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <line x1="498" y1="140" x2="516" y2="140" stroke="#94a3b8" stroke-width="2" marker-end="url(#ah)"/>
  <text x="320" y="228" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">Mass inferred from stellar motion — not from accretion light</text>
</svg>

## Connections

- It is an `example-of` the core concept of a **black hole** (→ 20260625120000).
- Its dormancy — the near-absence of an **accretion disk**'s glow — is what made it
  invisible to traditional methods; `related` (→ 20260625120500).

## Sources

[^newman2026]: Newman, A. B., et al. (2026), "A stellar dynamical mass measurement of an inactive black hole at redshift 2," *Science* 392(6802), 1065–1068.
[^ucl2026]: University College London News (2026), "Researchers weigh the most distant dormant black hole."
