---
id: "20260625140100"
title: "A Python class statement creates a class object and binds its name"
short_title: "Class definition"
tags: [python, classes, class-statement, oop]
parent_tag: python
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: py-tutorial-classes
    citation: "Python Documentation - Tutorial: Classes"
    url: "https://docs.python.org/3/tutorial/classes.html"
relations:
  - { type: extends, target: "20260625140000" }
visualization:
  kind: svg
  alt: "The class statement executes a namespace body and produces a class object bound to the class name."
---

## Core idea

A Python `class` statement executes a class body, creates a class object, and binds that
object to the class name [^py-tutorial-classes].

## Elaboration

The statements inside a class body define names in the class namespace. Function
definitions inside the body become function objects stored on the class, and attribute
assignments become class attributes. The result is an object that can be called to create
instances and inspected like other Python objects.

## Syntax / example

The `class` statement names the class, optionally lists base classes, and executes an
indented body:

```python
class Name:
    class_attribute = "shared"

    def method(self):
        return self.class_attribute
```

With inheritance, base classes go in parentheses:

```python
class Child(Parent):
    pass
```

The class body is executable Python code, so assignments and function definitions in that
body become names stored on the resulting class object.
## Visualization

<svg viewBox="0 0 640 240" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Class statement creates a class object"><defs><marker id="cd" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs><rect width="640" height="240" fill="#0b1220"/><rect x="72" y="92" width="148" height="52" rx="8" fill="#111c33" stroke="#475569"/><text x="146" y="123" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">class body</text><rect x="272" y="82" width="130" height="72" rx="8" fill="#1d2a4d" stroke="#6366f1"/><text x="337" y="112" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">class object</text><text x="337" y="134" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">namespace</text><rect x="470" y="92" width="100" height="52" rx="8" fill="#102a1b" stroke="#22c55e"/><text x="520" y="123" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Name</text><line x1="220" y1="118" x2="270" y2="118" stroke="#94a3b8" stroke-width="2" marker-end="url(#cd)"/><line x1="402" y1="118" x2="468" y2="118" stroke="#94a3b8" stroke-width="2" marker-end="url(#cd)"/></svg>

## Connections

- It `extends` **Python classes** (20260625140000).

## Sources

[^py-tutorial-classes]: Python Documentation, "Tutorial: Classes."