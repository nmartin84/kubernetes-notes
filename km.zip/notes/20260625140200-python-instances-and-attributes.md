---
id: "20260625140200"
title: "Python instances hold per-object state through attributes"
short_title: "Instances and attributes"
tags: [python, classes, instances, attributes, oop]
parent_tag: python
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: py-tutorial-classes
    citation: "Python Documentation - Tutorial: Classes"
    url: "https://docs.python.org/3/tutorial/classes.html"
relations:
  - { type: extends, target: "20260625140000" }
visualization:
  kind: svg
  alt: "Two instances of one class each hold separate attribute dictionaries for their own state."
---

## Core idea

A Python instance is an object created from a class, and its attributes hold state specific
to that object [^py-tutorial-classes].

## Elaboration

Instance attributes are usually assigned with `self.name = value` inside methods such as
`__init__`, but Python also allows attribute assignment elsewhere unless a class customizes
that behavior. Separate instances can have different attribute values even though they use
the same class methods. This separation is the usual basis of object state in Python.

## Syntax / example

Instance attributes are commonly assigned through `self`:

```python
class User:
    def __init__(self, name):
        self.name = name
        self.login_count = 0

    def record_login(self):
        self.login_count += 1

ada = User("Ada")
grace = User("Grace")
ada.record_login()

print(ada.login_count)    # 1
print(grace.login_count)  # 0
```

Both objects use the same class, but each instance has its own `name` and `login_count`.
## Visualization

<svg viewBox="0 0 640 240" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Instances have separate attributes"><rect width="640" height="240" fill="#0b1220"/><rect x="112" y="64" width="170" height="110" rx="8" fill="#102a1b" stroke="#22c55e"/><rect x="358" y="64" width="170" height="110" rx="8" fill="#102a1b" stroke="#22c55e"/><text x="197" y="94" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="14" text-anchor="middle">user_a</text><text x="443" y="94" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="14" text-anchor="middle">user_b</text><text x="197" y="126" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">name = 'Ada'</text><text x="443" y="126" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">name = 'Grace'</text><text x="320" y="210" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">same class, separate per-instance state</text></svg>

## Connections

- It `extends` **Python classes** (20260625140000).

## Sources

[^py-tutorial-classes]: Python Documentation, "Tutorial: Classes."