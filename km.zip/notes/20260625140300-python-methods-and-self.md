---
id: "20260625140300"
title: "Python instance methods receive the instance explicitly as self"
short_title: "Methods and self"
tags: [python, classes, methods, self, oop]
parent_tag: python
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: py-tutorial-classes
    citation: "Python Documentation - Tutorial: Classes"
    url: "https://docs.python.org/3/tutorial/classes.html"
relations:
  - { type: extends, target: "20260625140000" }
visualization:
  kind: svg
  alt: "Calling obj.method(arg) binds obj as self and passes arg to the function stored on the class."
---

## Core idea

A Python instance method is a function stored on a class that receives the instance as its
first argument when called through an instance [^py-tutorial-classes].

## Elaboration

By convention, the first parameter of an instance method is named `self`. Calling
`obj.method(x)` is effectively a bound-method call where `obj` is supplied as the first
argument. This explicit `self` makes instance state access visible in method definitions:
methods read or update object state through expressions such as `self.balance`.

## Syntax / example

Instance methods define `self` explicitly, but callers do not pass it manually:

```python
class Counter:
    def increment(self, amount=1):
        self.value += amount

    def reset(self):
        self.value = 0

counter = Counter()
counter.reset()
counter.increment(3)
```

This call:

```python
counter.increment(3)
```

is equivalent in effect to calling the function through the class and passing the instance
explicitly:

```python
Counter.increment(counter, 3)
```
## Visualization

<svg viewBox="0 0 640 240" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Bound method supplies self"><defs><marker id="m" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs><rect width="640" height="240" fill="#0b1220"/><rect x="72" y="92" width="142" height="48" rx="8" fill="#102a1b" stroke="#22c55e"/><text x="143" y="121" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">obj.method(x)</text><rect x="266" y="76" width="144" height="80" rx="8" fill="#1d2a4d" stroke="#6366f1"/><text x="338" y="108" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">method(self, x)</text><text x="338" y="132" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">self = obj</text><line x1="214" y1="116" x2="264" y2="116" stroke="#94a3b8" stroke-width="2" marker-end="url(#m)"/></svg>

## Connections

- It `extends` **Python classes** (20260625140000).

## Sources

[^py-tutorial-classes]: Python Documentation, "Tutorial: Classes."