---
id: "20260625140400"
title: "The __init__ method initializes a newly created Python instance"
short_title: "__init__"
tags: [python, classes, init, constructors, oop]
parent_tag: python
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: py-tutorial-classes
    citation: "Python Documentation - Tutorial: Classes"
    url: "https://docs.python.org/3/tutorial/classes.html"
  - id: py-datamodel
    citation: "Python Documentation - Data Model: object.__init__"
    url: "https://docs.python.org/3/reference/datamodel.html#object.__init__"
relations:
  - { type: extends, target: "20260625140000" }
visualization:
  kind: svg
  alt: "Calling a class creates an instance and then initializes its attributes through __init__."
---

## Core idea

`__init__` is the initialization method Python calls after a new instance has been created,
so it is the usual place to set initial instance attributes [^py-tutorial-classes].

## Elaboration

Although `__init__` is often casually called a constructor, Python's lower-level creation
hook is `__new__`; `__init__` initializes the already-created object [^py-datamodel]. For
ordinary classes, this distinction rarely matters. A typical `__init__` accepts arguments
from the class call and assigns fields such as `self.name` or `self.balance`.

## Syntax / example

`__init__` receives the new instance as `self` and any arguments passed to the class call:

```python
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

p = Point(3, 4)
print(p.x, p.y)  # 3 4
```

For ordinary classes, `__init__` should return `None` implicitly. Returning another value
from `__init__` is invalid:

```python
class Bad:
    def __init__(self):
        return 123  # TypeError when Bad() is called
```
## Visualization

<svg viewBox="0 0 640 240" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Class call initializes instance"><defs><marker id="i" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs><rect width="640" height="240" fill="#0b1220"/><rect x="74" y="92" width="130" height="48" rx="8" fill="#111c33" stroke="#475569"/><text x="139" y="121" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">User('Ada')</text><rect x="260" y="72" width="132" height="88" rx="8" fill="#1d2a4d" stroke="#6366f1"/><text x="326" y="106" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">__init__</text><text x="326" y="130" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">set attributes</text><rect x="454" y="92" width="112" height="48" rx="8" fill="#102a1b" stroke="#22c55e"/><text x="510" y="121" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">instance</text><line x1="204" y1="116" x2="258" y2="116" stroke="#94a3b8" stroke-width="2" marker-end="url(#i)"/><line x1="392" y1="116" x2="452" y2="116" stroke="#94a3b8" stroke-width="2" marker-end="url(#i)"/></svg>

## Connections

- It `extends` **Python classes** (20260625140000).

## Sources

[^py-tutorial-classes]: Python Documentation, "Tutorial: Classes."
[^py-datamodel]: Python Documentation, "Data Model: object.__init__."