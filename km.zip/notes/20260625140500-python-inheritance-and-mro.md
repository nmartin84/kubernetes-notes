---
id: "20260625140500"
title: "Python inheritance reuses behavior through a method resolution order"
short_title: "Inheritance and MRO"
tags: [python, classes, inheritance, mro, oop]
parent_tag: python
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: py-tutorial-classes
    citation: "Python Documentation - Tutorial: Classes"
    url: "https://docs.python.org/3/tutorial/classes.html"
  - id: py-datamodel
    citation: "Python Documentation - Data Model: Custom Classes"
    url: "https://docs.python.org/3/reference/datamodel.html#custom-classes"
relations:
  - { type: extends, target: "20260625140000" }
visualization:
  kind: svg
  alt: "A subclass points to base classes; attribute lookup follows the method resolution order until a matching name is found."
---

## Core idea

Python inheritance lets a class derive behavior from base classes, and attribute lookup
follows the class's method resolution order when names are not found directly [^py-tutorial-classes].

## Elaboration

A subclass can override methods from a base class or call inherited behavior through
`super()`. Python supports multiple inheritance, so the method resolution order matters:
it defines the linear search path used for attributes and methods [^py-datamodel]. Good
class hierarchies keep that lookup path understandable; otherwise composition is often a
simpler design.

## Syntax / example

A subclass lists its base class in parentheses and can override or extend inherited
methods:

```python
class Animal:
    def speak(self):
        return "..."

class Dog(Animal):
    def speak(self):
        return "woof"

print(Dog().speak())  # woof
```

`super()` delegates to the next class in the method resolution order:

```python
class LoggedDog(Dog):
    def speak(self):
        sound = super().speak()
        return f"logged: {sound}"

print(LoggedDog.__mro__)
```

`__mro__` shows the lookup path Python follows when resolving methods and attributes.
## Visualization

<svg viewBox="0 0 640 260" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Inheritance and method resolution order"><defs><marker id="h" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs><rect width="640" height="260" fill="#0b1220"/><rect x="248" y="46" width="144" height="48" rx="8" fill="#111c33" stroke="#475569"/><text x="320" y="75" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Base</text><rect x="248" y="156" width="144" height="48" rx="8" fill="#1d2a4d" stroke="#6366f1"/><text x="320" y="185" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">Subclass</text><line x1="320" y1="156" x2="320" y2="96" stroke="#94a3b8" stroke-width="2" marker-end="url(#h)"/><text x="430" y="128" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="13">lookup follows MRO</text></svg>

## Connections

- It `extends` **Python classes** (20260625140000).

## Sources

[^py-tutorial-classes]: Python Documentation, "Tutorial: Classes."
[^py-datamodel]: Python Documentation, "Data Model: Custom Classes."