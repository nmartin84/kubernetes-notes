---
id: "20260625140600"
title: "Python special methods let classes participate in language operations"
short_title: "Special methods"
tags: [python, classes, special-methods, data-model, protocols]
parent_tag: python
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: py-datamodel-special
    citation: "Python Documentation - Data Model: Special method names"
    url: "https://docs.python.org/3/reference/datamodel.html#special-method-names"
relations:
  - { type: extends, target: "20260625140000" }
visualization:
  kind: svg
  alt: "Special methods connect Python syntax like len, iteration, addition, string conversion, and indexing to class-defined behavior."
---

## Core idea

Special methods such as `__repr__`, `__len__`, `__iter__`, and `__add__` let class
instances integrate with Python syntax and built-in operations [^py-datamodel-special].

## Elaboration

Python's data model defines special method names that customize how objects behave in core
language operations. For example, `len(obj)` calls length behavior, `for x in obj` uses
iteration behavior, and `obj + other` can dispatch to addition behavior. These methods make
classes feel native when they implement a clear protocol rather than forcing callers to use
ad hoc method names.

## Syntax / example

Special methods use double-underscore names and are invoked by Python syntax or built-ins:

```python
class Bag:
    def __init__(self, items):
        self.items = list(items)

    def __len__(self):
        return len(self.items)

    def __iter__(self):
        return iter(self.items)

    def __repr__(self):
        return f"Bag({self.items!r})"

bag = Bag(["a", "b"])
print(len(bag))   # calls bag.__len__()
print(list(bag))  # calls bag.__iter__()
print(bag)        # calls bag.__repr__()
```

Special methods are normally looked up on the class, so defining them consistently on the
class is the standard pattern.
## Visualization

<svg viewBox="0 0 640 260" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Special methods connect syntax to class behavior"><rect width="640" height="260" fill="#0b1220"/><rect x="248" y="94" width="144" height="72" rx="8" fill="#1d2a4d" stroke="#6366f1"/><text x="320" y="124" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="14" text-anchor="middle">class</text><text x="320" y="146" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">special methods</text><g fill="#111c33" stroke="#475569"><rect x="60" y="54" width="104" height="34" rx="7"/><rect x="60" y="170" width="104" height="34" rx="7"/><rect x="476" y="54" width="104" height="34" rx="7"/><rect x="476" y="170" width="104" height="34" rx="7"/></g><g fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle"><text x="112" y="76">len(obj)</text><text x="112" y="192">str(obj)</text><text x="528" y="76">obj + x</text><text x="528" y="192">for x in obj</text></g></svg>

## Connections

- It `extends` **Python classes** (20260625140000).

## Sources

[^py-datamodel-special]: Python Documentation, "Data Model: Special method names."