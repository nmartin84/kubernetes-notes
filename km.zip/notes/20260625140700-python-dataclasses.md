---
id: "20260625140700"
title: "Python dataclasses reduce boilerplate for classes that mainly store data"
short_title: "Dataclasses"
tags: [python, classes, dataclasses, data-modeling]
parent_tag: python
created: 2026-06-25
updated: 2026-06-25
verification_status: cited
sources:
  - id: py-dataclasses
    citation: "Python Documentation - dataclasses"
    url: "https://docs.python.org/3/library/dataclasses.html"
relations:
  - { type: extends, target: "20260625140000" }
visualization:
  kind: svg
  alt: "A dataclass decorator reads annotated fields and generates common methods such as init and repr."
---

## Core idea

A Python dataclass is a class decorated with `@dataclass` so Python can generate common
methods for classes that primarily store data [^py-dataclasses].

## Elaboration

The `dataclasses` module inspects type-annotated fields and can generate methods such as
`__init__`, `__repr__`, and comparison methods depending on decorator options
[^py-dataclasses]. Dataclasses are useful for plain data records and value-like objects,
but they are still normal Python classes: methods, validation, inheritance, and custom
behavior can be added when needed.

## Syntax / example

A dataclass uses type-annotated fields and the `@dataclass` decorator:

```python
from dataclasses import dataclass

@dataclass
class User:
    name: str
    active: bool = True

ada = User("Ada")
print(ada)  # User(name='Ada', active=True)
```

The decorator generates common methods such as `__init__` and `__repr__` by default. Options
change the generated behavior:

```python
@dataclass(frozen=True, order=True)
class Version:
    major: int
    minor: int
```

`frozen=True` makes instances immutable through normal attribute assignment, and
`order=True` generates ordering comparisons from the declared field order.
## Visualization

<svg viewBox="0 0 640 260" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Dataclass decorator generates boilerplate"><defs><marker id="dc" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs><rect width="640" height="260" fill="#0b1220"/><rect x="70" y="94" width="150" height="58" rx="8" fill="#111c33" stroke="#475569"/><text x="145" y="119" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">annotated fields</text><text x="145" y="140" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">name: str</text><rect x="276" y="86" width="110" height="74" rx="8" fill="#1d2a4d" stroke="#6366f1"/><text x="331" y="119" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">@dataclass</text><text x="331" y="141" fill="#a5b4fc" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">decorator</text><rect x="450" y="94" width="132" height="58" rx="8" fill="#102a1b" stroke="#22c55e"/><text x="516" y="119" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">generated</text><text x="516" y="140" fill="#86efac" font-family="system-ui,sans-serif" font-size="12" text-anchor="middle">__init__, __repr__</text><line x1="220" y1="123" x2="274" y2="123" stroke="#94a3b8" stroke-width="2" marker-end="url(#dc)"/><line x1="386" y1="123" x2="448" y2="123" stroke="#94a3b8" stroke-width="2" marker-end="url(#dc)"/></svg>

## Connections

- It `extends` **Python classes** (20260625140000).

## Sources

[^py-dataclasses]: Python Documentation, "dataclasses."