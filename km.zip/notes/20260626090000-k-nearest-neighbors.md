---
id: "20260626090000"
title: "K-nearest neighbors predicts from the labels or values of nearby training examples"
short_title: "K-nearest neighbors"
tags: [machine-learning, supervised-learning, classification, regression, algorithms]
parent_tag: machine-learning
created: 2026-06-26
updated: 2026-06-26
verification_status: cited
sources:
  - id: cover-hart1967
    citation: "Cover, T. M. and Hart, P. E. (1967), 'Nearest neighbor pattern classification,' IEEE Transactions on Information Theory"
    url: "https://doi.org/10.1109/TIT.1967.1053964"
  - id: sklearn-neighbors
    citation: "scikit-learn User Guide - Nearest Neighbors"
    url: "https://scikit-learn.org/stable/modules/neighbors.html"
relations:
  - { type: related, target: "20260626090100" }
  - { type: related, target: "20260626090200" }
  - { type: related, target: "20260626090300" }
visualization:
  kind: svg
  alt: "A query point is classified by the majority label among its k closest labeled training points."
---

## Core idea

K-nearest neighbors, usually written k-NN, is an instance-based supervised learning method:
to predict for a new point, find the `k` training examples closest to it under a chosen
distance metric, then combine their labels or values [^cover-hart1967].

## Elaboration

For classification, k-NN predicts the class that appears most often among the `k` nearest
neighbors. For regression, it predicts an average, often a simple mean or a distance-weighted
mean. The algorithm is called non-parametric because it does not learn a fixed equation with
coefficients during training; the training step mostly stores examples, and the expensive
work happens at prediction time [^sklearn-neighbors].

The main choices are the number of neighbors, the distance metric, feature scaling, and the
weighting rule. Small `k` values create flexible, noisy decision boundaries. Larger `k` values
smooth the boundary but can hide small local patterns. Because distances dominate the result,
features should usually be scaled before fitting, and high-dimensional data can make all
points look similarly far away.

## Syntax / example

The core classification rule is majority vote among the nearest labels:

```text
Given training pairs (x_i, y_i), query point x, and distance d:

N_k(x) = the k training points with smallest d(x, x_i)

classification:
y_hat = mode({ y_i : x_i in N_k(x) })

regression:
y_hat = mean({ y_i : x_i in N_k(x) })
```

A minimal scikit-learn classifier uses a pipeline so feature scaling is applied before the
neighbor search:

```python
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

X, y = load_iris(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.25,
    random_state=42,
    stratify=y,
)

model = make_pipeline(
    StandardScaler(),
    KNeighborsClassifier(n_neighbors=5, weights="uniform", metric="minkowski"),
)

model.fit(X_train, y_train)
print(model.predict(X_test[:3]))
print(model.score(X_test, y_test))
```

A simple brute-force version shows the mechanics without indexing structures:

```python
from collections import Counter
from math import dist


def predict_one(query, X_train, y_train, k=3):
    ranked = sorted(
        zip(X_train, y_train),
        key=lambda row: dist(query, row[0]),
    )
    labels = [label for _, label in ranked[:k]]
    return Counter(labels).most_common(1)[0][0]
```

## Visualization

<svg viewBox="0 0 640 320" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="K-nearest neighbors majority vote"><defs><marker id="knn-arrow" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs><rect width="640" height="320" fill="#0b1220"/><circle cx="316" cy="154" r="92" fill="none" stroke="#818cf8" stroke-width="2" stroke-dasharray="6 6"/><circle cx="316" cy="154" r="7" fill="#f8fafc"/><text x="330" y="158" fill="#f8fafc" font-family="system-ui,sans-serif" font-size="13">query</text><g fill="#38bdf8"><circle cx="254" cy="118" r="8"/><circle cx="284" cy="208" r="8"/><circle cx="350" cy="92" r="8"/><circle cx="404" cy="186" r="8"/></g><g fill="#f472b6"><rect x="246" y="170" width="16" height="16" rx="3"/><rect x="360" y="168" width="16" height="16" rx="3"/><rect x="286" y="90" width="16" height="16" rx="3"/></g><g fill="#64748b"><circle cx="112" cy="80" r="6"/><circle cx="506" cy="78" r="6"/><rect x="120" y="236" width="12" height="12" rx="2"/><rect x="520" y="244" width="12" height="12" rx="2"/></g><line x1="316" y1="154" x2="254" y2="118" stroke="#94a3b8" stroke-width="1.5"/><line x1="316" y1="154" x2="254" y2="178" stroke="#94a3b8" stroke-width="1.5"/><line x1="316" y1="154" x2="368" y2="176" stroke="#94a3b8" stroke-width="1.5"/><line x1="316" y1="154" x2="284" y2="208" stroke="#94a3b8" stroke-width="1.5"/><line x1="316" y1="154" x2="350" y2="92" stroke="#94a3b8" stroke-width="1.5"/><rect x="210" y="268" width="220" height="34" rx="8" fill="#111c33" stroke="#475569"/><text x="320" y="290" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">k = 5, majority label wins</text><line x1="430" y1="285" x2="500" y2="285" stroke="#94a3b8" stroke-width="2" marker-end="url(#knn-arrow)"/><text x="545" y="290" fill="#38bdf8" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">blue</text></svg>

## Connections

- It is `related` to **Graph clustering** (20260626090100) because nearest-neighbor relationships can be used to construct similarity graphs for clustering.
- It is `related` to **PCA** (20260626090200) and **feature reduction methods** (20260626090300) because dimensionality reduction changes the distance geometry used by k-NN.

## Sources

[^cover-hart1967]: Cover and Hart, "Nearest neighbor pattern classification" (1967).
[^sklearn-neighbors]: scikit-learn User Guide, "Nearest Neighbors."