---
id: "20260626090100"
title: "Graph clustering finds communities of nodes with denser internal connections"
short_title: "Graph clustering"
tags: [machine-learning, graph-algorithms, clustering, community-detection, networks]
parent_tag: machine-learning
created: 2026-06-26
updated: 2026-06-26
verification_status: cited
sources:
  - id: girvan-newman2002
    citation: "Girvan, M. and Newman, M. E. J. (2002), 'Community structure in social and biological networks,' PNAS"
    url: "https://doi.org/10.1073/pnas.122653799"
  - id: newman2006
    citation: "Newman, M. E. J. (2006), 'Modularity and community structure in networks,' PNAS"
    url: "https://doi.org/10.1073/pnas.0601602103"
  - id: networkx-communities
    citation: "NetworkX Documentation - Communities algorithms"
    url: "https://networkx.org/documentation/stable/reference/algorithms/community.html"
relations:
  - { type: related, target: "20260626090000" }
  - { type: related, target: "20260626090300" }
visualization:
  kind: svg
  alt: "A graph is divided into three node communities with many internal edges and fewer cross-community edges."
---

## Core idea

Graph clustering, also called community detection in network science, partitions nodes into
groups whose internal connections are denser or stronger than their connections to the rest
of the graph [^girvan-newman2002].

## Elaboration

The input is a graph `G = (V, E)`, optionally with weighted edges. The output is a partition
of nodes into communities, usually represented as sets of node IDs. Unlike ordinary tabular
clustering, graph clustering works from relationships: edges, weights, paths, cuts, random
walks, or spectral structure.

Common approaches include divisive methods such as Girvan-Newman, which remove high
edge-betweenness links; modularity maximization, which searches for partitions with more
within-community edges than expected under a null model; label propagation; Louvain/Leiden
style multilevel optimization; and spectral methods based on graph matrices [^networkx-communities].

The result is not automatically ground truth. Community definitions depend on the graph
construction, edge weights, resolution parameter, and objective function. In similarity-based
machine learning, a graph can be built from nearest-neighbor relationships, then clustered to
find local structure in the data.

## Syntax / example

A common modularity objective compares observed edges against the expected edges from a
degree-preserving null model:

```text
G = (V, E)
A_ij = adjacency value between nodes i and j
k_i = weighted degree of node i
m = total edge weight / 2
c_i = community assignment for node i
gamma = resolution parameter

Q = (1 / 2m) * sum_ij [A_ij - gamma * (k_i * k_j / 2m)] * 1(c_i = c_j)
```

Higher `Q` means the partition places more edge weight inside communities than expected by
the null model, though modularity has known limits and should not be treated as the only
validation criterion [^newman2006].

A minimal NetworkX example using greedy modularity communities:

```python
import networkx as nx

G = nx.Graph()
G.add_weighted_edges_from(
    [
        ("a", "b", 3.0),
        ("a", "c", 2.0),
        ("b", "c", 2.5),
        ("d", "e", 3.0),
        ("d", "f", 2.0),
        ("e", "f", 2.5),
        ("c", "d", 0.2),
    ]
)

communities = nx.community.greedy_modularity_communities(G, weight="weight")
for index, community in enumerate(communities, start=1):
    print(index, sorted(community))
```

A similarity graph can also be built from tabular vectors before clustering:

```python
from sklearn.neighbors import kneighbors_graph
import networkx as nx

X = [
    [0.0, 0.1],
    [0.2, 0.0],
    [8.0, 8.1],
    [8.2, 8.0],
]

adjacency = kneighbors_graph(X, n_neighbors=1, mode="connectivity", include_self=False)
G = nx.from_scipy_sparse_array(adjacency)
communities = nx.community.greedy_modularity_communities(G)
```

## Visualization

<svg viewBox="0 0 640 320" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Graph clustering communities"><rect width="640" height="320" fill="#0b1220"/><g stroke="#334155" stroke-width="2"><line x1="130" y1="92" x2="182" y2="128"/><line x1="130" y1="92" x2="106" y2="154"/><line x1="182" y1="128" x2="106" y2="154"/><line x1="330" y1="70" x2="384" y2="118"/><line x1="330" y1="70" x2="298" y2="142"/><line x1="384" y1="118" x2="298" y2="142"/><line x1="454" y1="218" x2="528" y2="202"/><line x1="454" y1="218" x2="500" y2="260"/><line x1="528" y1="202" x2="500" y2="260"/><line x1="182" y1="128" x2="298" y2="142" stroke="#64748b" stroke-dasharray="6 6"/><line x1="384" y1="118" x2="454" y2="218" stroke="#64748b" stroke-dasharray="6 6"/></g><g fill="none" stroke-width="2" stroke-dasharray="7 7"><circle cx="140" cy="126" r="72" stroke="#38bdf8"/><circle cx="337" cy="111" r="76" stroke="#f472b6"/><circle cx="494" cy="226" r="76" stroke="#22c55e"/></g><g><circle cx="130" cy="92" r="11" fill="#38bdf8"/><circle cx="182" cy="128" r="11" fill="#38bdf8"/><circle cx="106" cy="154" r="11" fill="#38bdf8"/><circle cx="330" cy="70" r="11" fill="#f472b6"/><circle cx="384" cy="118" r="11" fill="#f472b6"/><circle cx="298" cy="142" r="11" fill="#f472b6"/><circle cx="454" cy="218" r="11" fill="#22c55e"/><circle cx="528" cy="202" r="11" fill="#22c55e"/><circle cx="500" cy="260" r="11" fill="#22c55e"/></g><rect x="196" y="264" width="248" height="34" rx="8" fill="#111c33" stroke="#475569"/><text x="320" y="286" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">dense inside, sparse between</text></svg>

## Connections

- It is `related` to **K-nearest neighbors** (20260626090000) because k-NN can construct similarity graphs that are then clustered.
- It is `related` to **linear vs non-linear feature reduction methods** (20260626090300) because many non-linear reductions use neighborhood or affinity graphs.

## Sources

[^girvan-newman2002]: Girvan and Newman, "Community structure in social and biological networks" (2002).
[^newman2006]: Newman, "Modularity and community structure in networks" (2006).
[^networkx-communities]: NetworkX Documentation, "Communities."