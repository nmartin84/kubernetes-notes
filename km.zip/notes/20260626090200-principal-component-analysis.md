---
id: "20260626090200"
title: "Principal component analysis reduces features by projecting data onto high-variance orthogonal directions"
short_title: "PCA"
tags: [machine-learning, dimensionality-reduction, pca, linear-algebra, feature-engineering]
parent_tag: machine-learning
created: 2026-06-26
updated: 2026-06-26
verification_status: cited
sources:
  - id: pearson1901
    citation: "Pearson, K. (1901), 'On lines and planes of closest fit to systems of points in space,' Philosophical Magazine"
    url: "https://doi.org/10.1080/14786440109462720"
  - id: sklearn-pca
    citation: "scikit-learn User Guide - Principal component analysis"
    url: "https://scikit-learn.org/stable/modules/decomposition.html#pca"
relations:
  - { type: related, target: "20260626090300" }
  - { type: related, target: "20260626090000" }
visualization:
  kind: svg
  alt: "A cloud of two-dimensional points is projected onto the first principal component, the direction of greatest variance."
---

## Core idea

Principal component analysis, or PCA, is a linear dimensionality reduction method that
re-expresses centered data along orthogonal directions ordered by how much variance they
explain [^pearson1901].

## Elaboration

PCA replaces correlated input features with principal components. The first component is the
linear direction with maximum projected variance; each later component is orthogonal to the
previous ones and captures the largest remaining variance. Keeping only the first few
components gives a lower-dimensional representation that preserves as much variance as a
linear projection can under the PCA objective [^sklearn-pca].

PCA is useful for compression, visualization, denoising, and preprocessing before algorithms
that struggle with many correlated features. It is not a supervised feature selector: it does
not know the target label, and high-variance directions are not always the most predictive
directions. Scaling matters because PCA is variance-based; features with larger numeric
scales can dominate unless the data is standardized first.

## Syntax / example

For a centered data matrix `X` with `n` samples, PCA can be written through the covariance
matrix or through singular value decomposition:

```text
Center the data:
X_centered = X - mean(X, axis=0)

Covariance form:
C = (1 / (n - 1)) * X_centered.T @ X_centered
C v_j = lambda_j v_j

Projection onto the first k components:
Z = X_centered @ V_k

SVD form:
X_centered = U Sigma V.T
Z = X_centered @ V_k.T
```

In scikit-learn, use a pipeline when features need scaling before PCA:

```python
from sklearn.datasets import load_wine
from sklearn.decomposition import PCA
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

X, y = load_wine(return_X_y=True)

pca_model = make_pipeline(
    StandardScaler(),
    PCA(n_components=2, random_state=42),
)

X_reduced = pca_model.fit_transform(X)
pca = pca_model.named_steps["pca"]

print(X_reduced.shape)
print(pca.explained_variance_ratio_)
print(pca.explained_variance_ratio_.sum())
```

Use `explained_variance_ratio_` to check how much variance the retained components preserve:

```python
PCA(n_components=0.95)
```

That form asks PCA to retain enough components to explain about 95 percent of the variance.

## Visualization

<svg viewBox="0 0 640 320" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="PCA projection onto first principal component"><defs><marker id="pca-arrow" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs><rect width="640" height="320" fill="#0b1220"/><g fill="#38bdf8" opacity="0.9"><circle cx="178" cy="218" r="6"/><circle cx="212" cy="198" r="6"/><circle cx="240" cy="182" r="6"/><circle cx="276" cy="166" r="6"/><circle cx="310" cy="144" r="6"/><circle cx="344" cy="130" r="6"/><circle cx="382" cy="108" r="6"/><circle cx="420" cy="92" r="6"/><circle cx="252" cy="208" r="6"/><circle cx="330" cy="174" r="6"/><circle cx="388" cy="138" r="6"/></g><line x1="142" y1="238" x2="474" y2="68" stroke="#f472b6" stroke-width="4" marker-end="url(#pca-arrow)"/><line x1="316" y1="154" x2="255" y2="35" stroke="#64748b" stroke-width="2" stroke-dasharray="6 6"/><text x="474" y="60" fill="#f472b6" font-family="system-ui,sans-serif" font-size="13">PC1</text><text x="234" y="32" fill="#94a3b8" font-family="system-ui,sans-serif" font-size="13">PC2</text><rect x="170" y="264" width="300" height="34" rx="8" fill="#111c33" stroke="#475569"/><text x="320" y="286" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">keep directions with the most variance</text></svg>

## Connections

- It is `related` to **linear vs non-linear feature reduction methods** (20260626090300) because PCA is the standard linear baseline.
- It is `related` to **K-nearest neighbors** (20260626090000) because reducing noisy or correlated dimensions can improve distance-based models.

## Sources

[^pearson1901]: Pearson, "On lines and planes of closest fit to systems of points in space" (1901).
[^sklearn-pca]: scikit-learn User Guide, "Principal component analysis."