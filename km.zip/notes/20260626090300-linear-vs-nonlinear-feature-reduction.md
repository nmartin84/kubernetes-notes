---
id: "20260626090300"
title: "Linear and non-linear feature reduction methods trade interpretability for curved-structure preservation"
short_title: "Feature reduction methods"
tags: [machine-learning, dimensionality-reduction, feature-engineering, manifold-learning, preprocessing]
parent_tag: machine-learning
created: 2026-06-26
updated: 2026-06-26
verification_status: cited
sources:
  - id: sklearn-pca
    citation: "scikit-learn User Guide - Decomposing signals in components"
    url: "https://scikit-learn.org/stable/modules/decomposition.html#pca"
  - id: sklearn-manifold
    citation: "scikit-learn User Guide - Manifold learning"
    url: "https://scikit-learn.org/stable/modules/manifold.html"
  - id: tenenbaum2000
    citation: "Tenenbaum, J. B., de Silva, V., and Langford, J. C. (2000), 'A global geometric framework for nonlinear dimensionality reduction,' Science"
    url: "https://doi.org/10.1126/science.290.5500.2319"
relations:
  - { type: related, target: "20260626090200" }
  - { type: related, target: "20260626090000" }
  - { type: related, target: "20260626090100" }
visualization:
  kind: svg
  alt: "Linear reduction projects data onto a flat axis, while non-linear reduction unwraps curved manifold structure."
---

## Core idea

Feature reduction methods map high-dimensional data into fewer features. Linear methods use
flat projections or matrix factorizations, while non-linear methods try to preserve curved,
local, kernel, or graph-based structure that a single flat projection can miss [^sklearn-manifold].

## Elaboration

Linear reduction methods include PCA, truncated SVD, linear discriminant analysis, and other
matrix-factorization approaches. They are usually faster, easier to inspect, easier to apply
to new data, and often work well when the important signal is close to a linear subspace
[^sklearn-pca]. PCA is the default baseline because it preserves variance through orthogonal
linear components.

Non-linear reduction methods include kernel PCA, Isomap, locally linear embedding, spectral
embedding, t-SNE, and related manifold-learning methods. These methods can reveal curved
structure, local neighborhoods, or non-linear similarity patterns, but they are often more
sensitive to hyperparameters, distance metrics, sampling density, and out-of-sample behavior.
Some are best used for visualization rather than as a stable preprocessing step for a
production model.

A practical workflow is to start with scaling plus PCA or truncated SVD, measure whether it
preserves useful signal, then try non-linear methods when there is evidence that local or
curved geometry matters.

## Syntax / example

The difference can be summarized as the form of the mapping:

```text
Linear reduction:
Z = X @ W

Examples:
PCA, TruncatedSVD, linear projection, linear discriminant analysis

Non-linear reduction:
Z = f(X)

Examples:
KernelPCA, Isomap, LocallyLinearEmbedding, SpectralEmbedding, TSNE
```

A side-by-side scikit-learn sketch:

```python
from sklearn.datasets import load_digits
from sklearn.decomposition import PCA, KernelPCA
from sklearn.manifold import Isomap, SpectralEmbedding, TSNE
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

X, y = load_digits(return_X_y=True)

linear = make_pipeline(
    StandardScaler(),
    PCA(n_components=2, random_state=42),
)

kernel = make_pipeline(
    StandardScaler(),
    KernelPCA(n_components=2, kernel="rbf", gamma=0.01),
)

isomap = make_pipeline(
    StandardScaler(),
    Isomap(n_neighbors=10, n_components=2),
)

spectral = make_pipeline(
    StandardScaler(),
    SpectralEmbedding(n_neighbors=10, n_components=2, random_state=42),
)

tsne = make_pipeline(
    StandardScaler(),
    TSNE(n_components=2, perplexity=30, init="pca", random_state=42),
)

X_pca = linear.fit_transform(X)
X_kernel = kernel.fit_transform(X)
X_isomap = isomap.fit_transform(X)
X_spectral = spectral.fit_transform(X)
X_tsne = tsne.fit_transform(X)
```

Choose the method by the downstream use case:

```text
Use PCA / TruncatedSVD when:
- you need a fast baseline
- linear combinations are acceptable
- the embedding must transform future samples predictably
- interpretability and variance accounting matter

Use non-linear reduction when:
- local neighborhoods matter more than global variance
- the data may lie on a curved manifold
- the goal is visualization or structure discovery
- you can validate sensitivity to hyperparameters
```

## Visualization

<svg viewBox="0 0 640 320" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Linear versus non-linear feature reduction"><defs><marker id="fr-arrow" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto"><path d="M0,0 L7,3 L0,6 Z" fill="#94a3b8"/></marker></defs><rect width="640" height="320" fill="#0b1220"/><path d="M90 220 C135 90, 205 90, 250 220" fill="none" stroke="#38bdf8" stroke-width="4"/><g fill="#38bdf8"><circle cx="90" cy="220" r="6"/><circle cx="120" cy="152" r="6"/><circle cx="170" cy="112" r="6"/><circle cx="220" cy="152" r="6"/><circle cx="250" cy="220" r="6"/></g><line x1="70" y1="238" x2="270" y2="116" stroke="#f472b6" stroke-width="3" marker-end="url(#fr-arrow)"/><text x="170" y="270" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">linear: one flat projection</text><path d="M390 220 C435 90, 505 90, 550 220" fill="none" stroke="#38bdf8" stroke-width="4"/><g fill="#22c55e"><circle cx="385" cy="250" r="6"/><circle cx="425" cy="250" r="6"/><circle cx="465" cy="250" r="6"/><circle cx="505" cy="250" r="6"/><circle cx="545" cy="250" r="6"/></g><path d="M390 220 C435 90, 505 90, 550 220" fill="none" stroke="#22c55e" stroke-width="2" stroke-dasharray="6 6"/><text x="470" y="270" fill="#e2e8f0" font-family="system-ui,sans-serif" font-size="13" text-anchor="middle">non-linear: preserve curved neighborhood</text></svg>

## Connections

- It is `related` to **PCA** (20260626090200) because PCA is the primary linear dimensionality-reduction baseline.
- It is `related` to **K-nearest neighbors** (20260626090000) because feature reduction changes the geometry used by distance-based models.
- It is `related` to **Graph clustering** (20260626090100) because many non-linear methods build neighborhood or affinity graphs before embedding.

## Sources

[^sklearn-pca]: scikit-learn User Guide, "Decomposing signals in components."
[^sklearn-manifold]: scikit-learn User Guide, "Manifold learning."
[^tenenbaum2000]: Tenenbaum, de Silva, and Langford, "A global geometric framework for nonlinear dimensionality reduction" (2000).