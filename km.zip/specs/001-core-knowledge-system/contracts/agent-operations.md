# Agent Operations Contract: `km` knowledge agent

This repository has no CLI. Its "interface" is an AI agent operating on the repo. This
contract defines the operations the agent MUST support, their inputs, the required effects
on the repository, and the acceptance conditions that stand in for tests. The behaviour is
codified for the agent in `AGENTS.md`; note structure is constrained by
`note-frontmatter.schema.json`.

Two primary operations correspond to the user's described workflow, plus supporting ones.

---

## Operation A — Mint notes from a knowledge dump

**Trigger (example prompt)**: "Here's some knowledge: <text>. Keywords: spaced-repetition,
memory. Make notes."

| Aspect | Contract |
|--------|----------|
| Input | Free-form knowledge text; optional keywords to steer which concepts become notes; optional source(s). |
| Effect | The agent decomposes the dump into **atomic** ideas and creates one `notes/<id>-<slug>.md` per idea, each conforming to `note-frontmatter.schema.json`, with a fresh unique `id`, today's `created`/`updated`, tags (incl. keywords), a `verification_status`, sources for any cited claim, and a self-contained `visualization` (inline SVG preferred) in the note body. It then connects each new note into the existing graph (Operation C) and runs generation (Operation D) to rebuild the site. |
| Acceptance | Every new note is atomic (one core idea); every factual claim is cited or labelled (no unattributed fact); each note has a stable `id`, required metadata, ≥1 relation (or is reported as a justified orphan), and a visual; a sibling `.html` exists and reflects the `.md`. |
| Errors / guards | If the dump is too coarse to atomize confidently, the agent proposes a decomposition and asks before writing. If a claim cannot be sourced, it is labelled `unverified`/`opinion` rather than asserted (Principle II). `id` collisions are avoided by checking `notes/`. |

## Operation B — Integrate scratch notes into the graph

**Trigger (example prompt)**: "Here are some rough notes I jotted down: <text>. Connect them
to what I already have."

| Aspect | Contract |
|--------|----------|
| Input | Rough/scratch note text (one or many ideas), unstructured. |
| Effect | The agent normalizes the scratch material into atomic notes (as in Operation A where new), then **scans existing `notes/`** and links each note to the best-fitting existing notes via typed relations, writing the inverse relation on the other end. It reports, per note, the connections it chose and a one-line rationale, and flags anything it left orphaned. Finally it runs generation (Operation D) to rebuild the site. |
| Acceptance | New/updated notes conform to the schema; every added relation is typed, resolves to an existing `id`, and appears on **both** ends (FR-009); no dangling links remain (FR-010); orphans are reported (FR-011); a connection rationale is given for auditability. |
| Errors / guards | If no good connection exists for a note, the agent says so and leaves it a (reported) orphan rather than inventing a weak link. Ambiguous merges with existing notes are surfaced for the user to confirm rather than silently overwriting. |

## Operation C — Link / relate notes (used by A and B, and standalone)

| Aspect | Contract |
|--------|----------|
| Input | Two (or more) note ids, or "find connections for note X". |
| Effect | Adds `relations: [{type, target}]` entries with `type` from the controlled vocabulary, and writes the inverse on the target. Re-runs generation (Operation D) to rebuild affected pages. |
| Acceptance | Relationship visible on both notes with correct inverse label; bumping `updated`; pages rebuilt by generation. Removing a relation from one note removes it from the other. |

## Operation D — Generate the site (run `python generate.py`)

| Aspect | Contract |
|--------|----------|
| Trigger | Run by the agent after any Operation A/B/C that creates or updates notes; also runnable on demand. |
| Effect | Reads all `notes/*.md`, renders each via `templates/note.html.j2` to `site/<id>-<slug>.html`, builds `site/index.html`, emits the connection-graph data, and copies `assets/` (CSS + vendored `cytoscape.min.js`) into `site/`. Fully rebuilds `site/` so pages for deleted notes do not persist. |
| Acceptance | Each page shows the core idea + sources + working relation links + the embedded visual (or summary) + the top-right interactive connection graph; consistent modern styling; opens and renders offline; reflects the current `.md` (FR-012, FR-015, FR-017a, FR-017b). |
| Command | `python generate.py` (dependencies in `requirements.txt`: markdown, PyYAML, Jinja2). |

## Operation E — Find / retrieve

| Aspect | Contract |
|--------|----------|
| Input | A note `id` or a `tag`. |
| Effect | Locates the matching note(s) by filename/front-matter scan. |
| Acceptance | `id` → the note's path + title; `tag` → all matching notes (by id), effectively instant (SC-007). |

---

## Cross-cutting guarantees

- **Accuracy is non-negotiable (Principle II)**: the agent never asserts unverified
  information as fact; uncertainty is labelled and surfaced.
- **Markdown is canonical (Principle IV)**: content changes happen in `.md`; the `site/` is
  rebuilt by `python generate.py` and is disposable; the agent never treats hand-edits to
  generated HTML as the source.
- **Offline**: the generated site references the vendored `cytoscape.min.js` and local CSS;
  visuals are self-contained (inline SVG); no network is required to build or view.
- **Self-contained guidance**: the agent loads `AGENTS.md` + `CONVENTIONS.md` each session so
  behaviour is reproducible across sessions and agents.
