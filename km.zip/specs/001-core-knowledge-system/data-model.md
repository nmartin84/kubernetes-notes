# Phase 1 Data Model: Core Knowledge System

Entities derive from the spec's Key Entities and Functional Requirements and from the
constitution's Note Anatomy. The canonical representation is a Markdown file with YAML
front matter (metadata) plus a Markdown body (idea + elaboration); the agent authors a
sibling HTML rendering. The JSON-schema form of the front matter is in
`contracts/note-frontmatter.schema.json`. There is no database or in-memory program — the
"graph" is the set of `relations` written across the note files.

## Entity: Note

The atomic unit of knowledge — exactly one idea (Principle I). One `.md` file (canonical)
with a sibling `.html` (AI-authored rendering).

| Field | Source | Type | Rules |
|-------|--------|------|-------|
| `id` | front matter | string | Required, immutable, unique. `YYYYMMDDHHMMSS`. Never reused (FR-002). |
| `title` | front matter | string | Required. Concise, declarative single statement. |
| core idea | body (lead section) | Markdown | Required. The one idea in the author's words (FR-001). |
| elaboration | body | Markdown | Optional. Supporting context scoped to the one idea (FR-006). |
| `tags` | front matter | string[] | Optional; used for retrieval (FR-007). |
| `parent_tag` | front matter | string | Optional. The note's primary tag; the index nests the note under it and shows its other tags as related sub-groups. Defaults to the first `tags` entry. |
| `created` | front matter | date | Required. ISO 8601 `YYYY-MM-DD`. Set once. |
| `updated` | front matter | date | Required. ISO 8601. Bumped on correction (FR-017). |
| `verification_status` | front matter | enum | Required: `cited` \| `synthesis` \| `opinion` \| `unverified` (FR-003, FR-004). |
| `sources` | front matter | Source[] | Required non-empty when `verification_status = cited` (FR-004). |
| `relations` | front matter | Relation[] | Typed links to other notes; inverse written on the other end (FR-008, FR-009). |
| `visualization` | front matter | Visualization | Required — a visual or a justified summary fallback (FR-014). |

**Validation (enforced by the agent via the playbook review checklist)**

- Atomicity (FR-005): exactly one core-idea section; agent decomposes multi-idea input and
  the user confirms.
- Sourcing (FR-004): no unattributed factual claim; `cited` ⇒ `sources` non-empty.
- Self-containment (FR-006): note reads without requiring sibling notes.
- Rendering parity (FR-015): the `.html` reflects the current `.md`.

## Entity: Identifier

- **Format**: `YYYYMMDDHHMMSS` (creation timestamp), also the filename prefix.
- **Rules**: globally unique across `notes/`; assigned once; never changes on edit; never
  reused even after deletion (FR-002). The agent checks for collision before assigning.

## Entity: Relation

A typed, directional connection from one Note to another (Principle III).

| Field | Type | Rules |
|-------|------|-------|
| `type` | enum | Required: `extends` \| `contradicts` \| `example-of` \| `prerequisite-of` \| `related`. |
| `target` | string (id) | Required. MUST resolve to an existing Note `id`; otherwise a **dangling** link (FR-010). |

**Graph rules (maintained by the agent across files)**

- **Bidirectional (FR-009)**: when relation A→B is written, the agent also writes the
  inverse on B using the inverse label; removing one end removes the other.
- **Inverse labels**: `extends`↔`extended-by`, `contradicts`↔`contradicts` (symmetric),
  `example-of`↔`has-example`, `prerequisite-of`↔`requires`, `related`↔`related` (symmetric).
- **Orphan (FR-011)**: a Note with no relations (in or out) is reported by the agent when it
  scans `notes/`; permitted only as a justified exception.
- **Connection-finding**: for "connect these" requests, the agent scans existing notes'
  titles/ideas/tags, proposes the best-fitting typed relations with a brief rationale, and
  lists any note left orphaned.

## Entity: Source / Reference

| Field | Type | Rules |
|-------|------|-------|
| `id` | string | Required; referenced by inline `[^id]` markers. Unique within the note. |
| `citation` | string | Required; human-readable reference (title/author/locator/URL). |
| `url` | string | Optional. |

## Entity: Visualization

The agent's chosen visual for the note (Principle V). The visual *content* lives in the
note body under a `## Visualization` heading; front matter declares its kind and alt text.

| Field | Type | Rules |
|-------|------|-------|
| `kind` | enum | Required: `svg` (preferred) \| `html` \| `image` \| `summary` (fallback). |
| `alt` | string | Required: short text describing the visual (accessibility + summary). |
| `src` | string | Required when `kind = image`: repo-relative asset path. |
| body `## Visualization` | Markdown/SVG/HTML | Holds the inline SVG/HTML (for `svg`/`html`), or the structured text (for `summary`). The generator embeds it into the page as-is. |

## Entity: Verification Status

Enum embedded on the Note:

- `cited` — every factual claim attributed to a Source.
- `synthesis` — the author's own synthesis across sources.
- `opinion` — the author's stance/judgment.
- `unverified` — captured but not yet checked; must be visibly labelled.

## Entity: Generated Page (HTML rendering)

A derived, disposable artifact (Principle IV) — built by `generate.py`, not the place
knowledge lives.

- One `site/<id>-<slug>.html` per note, produced from `templates/note.html.j2`.
- Contains: core idea, elaboration, sources, relations (declared + inverse) as navigable
  links, the embedded visualization, and an interactive **connection graph in the top-right
  corner** (Cytoscape) whose nodes link to connected notes — FR-012, FR-013, FR-014, FR-017a.
- Consistent modern styling from `assets/styles.css` (FR-017b).
- Rules: never hand-edited to change content; rebuilt by re-running generation when notes
  change, and a page is dropped when its note is deleted (FR-016); MUST faithfully reflect
  the current source, re-derivable at any time (FR-015).

## Entity: Connection Graph data

Generated input for the top-right graph view (not authored by hand).

- Built by `generate.py` from the union of all `relations`. For each page, the note's local
  neighbourhood (the note + directly connected notes, with typed, directed edges) is emitted
  as graph data (`site/graph.json`, or inlined per page) consumed by Cytoscape.
- Node = a note (`id`, title, url); edge = a typed relation (`type`). Clicking a node
  navigates to that note's page (FR-017a, SC-006).

## Entity: Tag

- A string applied to zero or more Notes; supports lookup of all Notes carrying it (FR-007),
  by scanning front matter (e.g., grep) — no index to maintain.

## Knowledge Graph (aggregate)

Not a stored program object — it is the union of all `relations` across the note files.
The agent reconstructs it by reading `notes/` when it needs to find connections, detect
dangling links, or report orphans.
