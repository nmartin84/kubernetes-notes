# Implementation Plan: Core Knowledge System

**Branch**: `001-core-knowledge-system` | **Date**: 2026-06-25 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `specs/001-core-knowledge-system/spec.md`

## Summary

A **hybrid** knowledge system: an AI agent authors content, and a small generator builds
the site. The user dumps knowledge + keywords (or scratch notes) into a prompt; the agent
(run via an in-repo coding agent such as Claude Code) mints atomic Zettelkasten notes as
Markdown — each with a stable timestamp id, sourced/labelled claims, typed relations
written on both ends, and a **self-contained visualization of the agent's choosing
(inline SVG preferred)**. After creating or updating notes, the agent runs a single
**generation command** (`python generate.py`) that renders every note into a styled,
modern HTML page and embeds an **interactive connection graph in the top-right corner**
(vendored Cytoscape.js) whose nodes link to the connected notes' pages. Markdown is
canonical; the HTML site is a disposable, regenerable artifact.

Deliverables: the **generator** (`generate.py` + templates + vendored assets), the
**agent guidance** (`AGENTS.md` playbook, `CONVENTIONS.md`), and the **notes** themselves.

## Technical Context

**Language/Version**: Python 3.12 — used only for the generation command. Note *authoring*
is done by the AI agent (no app); the generator is the single executable artifact.

**Primary Dependencies**: `markdown` (Markdown → HTML), `PyYAML` (front matter), `Jinja2`
(page templating). Vendored client-side: `cytoscape.min.js` (pinned) for the interactive
connection graph. No network access at build or view time.

**Storage**: Plain files. `notes/<id>-<slug>.md` (canonical) → `site/<id>-<slug>.html`
(generated) + `site/index.html`. Generated graph data as `site/graph.json` (or inlined
per page). Static assets (CSS, vendored Cytoscape) under `assets/` copied into `site/`.

**Testing**: No unit-test suite is required. The generator is validated by running it over
the notes and checking output against the quickstart scenarios (pages built, links/graph
work, re-run reflects edits). A lightweight schema check of note front matter MAY be added.

**Target Platform**: Local. Generator runs under Python 3.12 on Windows 11 / PowerShell
(cross-platform). Output is static HTML viewable offline in any modern browser.

**Project Type**: AI-operated knowledge repository **plus** a small static-site generator
command. Not an interactive application or CLI product.

**Performance Goals**: Generate a 1,000-note site in a few seconds; pages load instantly
offline; note lookup by id/tag is effectively instant.

**Constraints**: Offline (vendored Cytoscape, no CDN); Markdown is the single source of
truth; the `site/` is disposable and rebuilt by `generate.py`; each page must faithfully
reflect its note and show the top-right connection graph; visuals are self-contained
(inline SVG preferred) and require no external runtime.

**Scale/Scope**: Personal knowledge base, single author, thousands of notes, one repo.

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Gates derived from `.specify/memory/constitution.md` **v1.2.0** (amended this phase:
Principle V no longer mandates Mermaid; Principle IV/Workflow build HTML via a repeatable
generation command):

| Principle | Gate | Status |
|-----------|------|--------|
| I. Atomic Notes | Playbook + note template enforce one core idea + stable, never-reused `YYYYMMDDHHMMSS` id | PASS |
| II. Accuracy & Source Integrity (NON-NEGOTIABLE) | Conventions require `verification_status` + sources; agent cites or labels every claim, never asserts unverified fact | PASS |
| III. Connected Knowledge | Typed relation vocabulary (+ inverses); agent writes both ends; generator builds the connection graph and detects orphans/dangling | PASS |
| IV. Markdown Source of Truth, HTML Derivative | `notes/*.md` canonical; `generate.py` (re)builds `site/` from them; never hand-edited; faithful + regenerable | PASS |
| V. Visual Illustration | Agent authors a self-contained visual (inline SVG preferred) per note; generator embeds it; summary fallback allowed | PASS |

**Initial Constitution Check: PASS** — with the v1.2.0 amendment, no violations. Complexity
Tracking not required.

**Post-Design Re-evaluation: PASS** — Phase 1 artifacts add one small generator command and
a vendored client-side graph library; both are offline and disposable, and introduce no
principle violation. The generator is the only executable artifact.

## Project Structure

### Documentation (this feature)

```text
specs/001-core-knowledge-system/
├── plan.md              # This file
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output
├── quickstart.md        # Phase 1 output
├── contracts/           # Phase 1 output
│   ├── note-frontmatter.schema.json   # Canonical note metadata contract
│   └── agent-operations.md            # Agent behaviour contract (incl. run-generation)
└── tasks.md             # Phase 2 output
```

### Repository content, guidance & generator (repository root)

```text
AGENTS.md                # Agent playbook: mint notes, integrate scratch notes, run generation
CONVENTIONS.md           # id scheme, relation vocabulary + inverses, sourcing/verification, tags

generate.py              # THE generation command: notes/*.md -> site/*.html + index + graph
requirements.txt         # markdown, PyYAML, Jinja2
templates/
├── note.html.j2         # Jinja2 page template (modern layout + top-right graph mount)
└── index.html.j2        # Landing page template
assets/
├── styles.css           # Modern, consistent styling
└── cytoscape.min.js     # Vendored, pinned — interactive connection graph (offline)

notes/                   # The knowledge base (canonical)
└── <id>-<slug>.md       # Atomic note: front matter + body (incl. a Visualization section)

site/                    # Generated output (disposable; rebuilt by generate.py)
├── <id>-<slug>.html     # One styled page per note (+ top-right connection graph)
├── index.html           # Landing/overview page
├── graph.json           # Generated graph data consumed by Cytoscape
└── assets/              # Copied CSS + vendored cytoscape.min.js
```

**Structure Decision**: Hybrid. The agent authors Markdown notes (content + a
self-contained visual) under `notes/`; a single Python generator (`generate.py` +
`templates/` + `assets/`) builds the disposable `site/`. This keeps a clean Principle IV
separation (canonical `notes/` vs generated `site/`), satisfies the user's request for a
generation command, modern styling, and an interactive top-right connection graph, and
keeps everything offline via a vendored Cytoscape.js.

## Complexity Tracking

> No constitution violations — this section intentionally left empty.
