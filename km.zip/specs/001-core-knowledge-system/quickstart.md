# Quickstart & Validation Guide: Core Knowledge System

This guide proves the feature works end-to-end by driving the **AI agent** with prompts,
running the **generation command**, and checking the output — via prompt, file inspection,
running `python generate.py`, and opening the generated site in a browser.

## Prerequisites

- An AI coding agent (e.g., Claude Code) running in this repository.
- Python 3.12 with the generator deps installed (`pip install -r requirements.txt`).
- The guidance + generator in place: `AGENTS.md`, `CONVENTIONS.md`, `templates/note.md`,
  `generate.py`, `templates/note.html.j2`, `templates/index.html.j2`, `assets/styles.css`,
  vendored `assets/cytoscape.min.js`.
- A `notes/` directory (created on first note).

## Setup

Open the agent in the repo and confirm it has loaded the guidance:

> "Summarize how you will create and link notes here, and the note format you'll use."

**Expected**: the agent restates the playbook — atomic notes, timestamp ids, typed
relations written on both ends, sources/verification required, a self-contained visual
(inline SVG preferred), `.md` canonical, and `site/` rebuilt by `python generate.py`.

## Scenario A — Mint notes from a knowledge dump (User Story 1 / Operation A)

> "Here's some knowledge: *Spaced repetition schedules reviews at increasing intervals to
> exploit the spacing effect, improving long-term retention (Ebbinghaus).* Keywords:
> learning, memory. Make notes."

**Expected**:
- One or more `notes/<id>-*.md` files, each a single atomic idea conforming to
  `contracts/note-frontmatter.schema.json` (14-digit `id`, `created`/`updated` = today,
  tags incl. keywords, a `verification_status`, and a `visualization: {kind, alt}` with a
  self-contained `## Visualization` section (inline SVG preferred)).
- The Ebbinghaus claim is `cited` with a source, or labelled — never an unattributed fact.
- **Negative check**: ask the agent to assert a fact it can't source — it must label it
  `unverified`/`opinion` or decline, not state it as fact (FR-004, Principle II).
- **Atomicity check**: feed a two-idea blob; the agent must split it into separate notes
  (FR-005), not one combined note.
- **Stability check**: ask it to rewrite a note's title; the `id` must not change (FR-002).

## Scenario B — Integrate scratch notes into the graph (User Story 2 / Operation B)

> "Here are rough notes: *interleaving practice mixes problem types; testing yourself beats
> rereading.* Connect them to what I already have."

**Expected**:
- Scratch material becomes atomic notes, then is linked to existing notes (e.g.,
  `related`/`extends` to the spaced-repetition note) via typed relations.
- Each added relation appears on **both** notes with the correct inverse label (FR-009).
- The agent reports the connections chosen with a one-line rationale each, and names any
  note it left orphaned (FR-011).
- **Negative check**: reference a non-existent id in a relation; the agent flags it as a
  dangling link (FR-010) rather than leaving it silently broken.

## Scenario C — Generate and browse the styled site (User Story 3 / Operation D)

> "Run the generation command."  → `python generate.py`

Then open `site/index.html` (and a note page, e.g. `site/<id>-spaced-repetition.html`) in a
browser.

**Expected**:
- The command builds one styled page per note under `site/`, with a consistent modern look.
- Each page shows the core idea, sources, navigable relation links, and the embedded visual
  (inline SVG, offline) — FR-012–014, FR-017b.
- The **top-right corner shows an interactive connection graph**; clicking a connected node
  navigates to that note's page (FR-017a, SC-006). Inline relation links also navigate (FR-013).
- A note authored with `visualization.kind: summary` shows its structured summary instead of
  a diagram, with no empty visual section (FR-014).

## Scenario D — Regenerable, faithful site (SC-005 / FR-015, FR-016)

> Edit a note's `.md` (and separately, delete a note), then re-run `python generate.py`.

**Expected**: the rebuilt `site/` reflects the edit on the corresponding page, and the
deleted note's page no longer exists. Deleting `site/` entirely and re-running fully
recreates it from the Markdown. (Byte-identical output is not required; faithful
correspondence to source is.)

## Scenario E — Retrieval (SC-007 / FR-007 / Operation E)

> "Find the note with id <id>." and "List all notes tagged `memory`."

**Expected**: id lookup returns the note's path + title; tag lookup returns all matching
notes — effectively instant via a front-matter/filename scan.

## Success-criteria coverage map

| Criterion | Validated by |
|-----------|--------------|
| SC-001 (capture a note quickly) | Scenario A |
| SC-002 (all claims cited/labelled) | Scenario A (negative check) |
| SC-003 (relations both ends; no dangling) | Scenario B |
| SC-004 (page has idea, sources, links, visual) | Scenario C |
| SC-005 (page re-derivable, reflects source) | Scenario D |
| SC-006 (one click to related note) | Scenario C |
| SC-007 (find by id/tag fast) | Scenario E |
