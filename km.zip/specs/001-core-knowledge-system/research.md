# Phase 0 Research: Core Knowledge System

This repository is operated by an AI agent rather than built as software. The decisions
below establish *how the agent should behave* and *what conventions notes follow*, each
justified against the constitution (v1.1.0) and the spec's success criteria. There is no
language/framework selection because no program is produced.

## 1. Operating model — AI agent on the repo (no application)

- **Decision**: The system is an AI coding agent (e.g., Claude Code) run inside this repo.
  The user provides knowledge + keywords (or raw scratch notes) in a prompt; the agent
  reads existing notes, writes new note files, and updates relations on both ends. After
  authoring, the agent runs a single **generation command** (`python generate.py`) that
  builds the HTML site. The "product" is the agent's guidance + conventions + the generator,
  captured as repo files loaded every session.
- **Rationale**: Authoring is a judgement task suited to the agent; rendering a styled,
  consistent, navigable site is a mechanical task suited to a small deterministic script.
  This split honours the user's request for a generation command, modern styling, and an
  interactive connection graph, while keeping authoring agent-driven.
- **Alternatives considered**: Agent hand-authors each `.html` (rejected at the user's
  request — inconsistent styling, no shared graph widget, error-prone); a large hosted note
  app (rejected — out of scope for a single-author local workflow).

## 2. Stable identifier scheme

- **Decision**: Timestamp ID at creation, `YYYYMMDDHHMMSS`, recorded in front matter `id`
  and used as the filename prefix (`20260625153012-spaced-repetition.md`). Immutable; links
  resolve by `id`, never by title or filename.
- **Rationale**: Unique without a central counter, sortable, human-legible; satisfies FR-002
  ("stable across edits, never reused"). The agent generates it from the current time when
  minting a note and checks `notes/` for collisions.
- **Alternatives considered**: Sequential integers (rejected — needs a shared counter,
  fragile for an agent writing files); content hashes (rejected — change on edit, breaking
  stability); UUIDs (rejected — not sortable/legible, no benefit here).

## 3. Note format — Markdown + YAML front matter

- **Decision**: One Markdown file per note. YAML front matter holds metadata (`id`, `title`,
  `tags`, `created`, `updated`, `verification_status`, `sources`, `relations`,
  `visualization`); the body holds the core idea and elaboration. Codified in
  `templates/note.md` and `contracts/note-frontmatter.schema.json`.
- **Rationale**: Satisfies Principle IV (Markdown canonical, human-readable, self-contained
  note). Front matter is the de-facto metadata convention and is easy for an agent to write
  and for a human to diff.
- **Alternatives considered**: Sidecar JSON metadata (rejected — splits a note across files,
  breaking self-containment); a database (rejected — violates Markdown-as-source-of-truth).

## 4. Enforcing atomicity (Principle I / FR-005)

- **Decision**: The playbook instructs the agent to decompose a knowledge dump into the
  smallest single-idea units, create one note per idea, and refuse to combine unrelated
  ideas into a single note. The note template's single core-idea section makes a violation
  visually obvious; the review checklist requires the author to confirm atomicity.
- **Rationale**: With an AI as the engine, atomicity is enforced by *instruction + judgment
  + human review* rather than code. This is the honest mechanism — deciding "one idea" is a
  semantic judgment the agent is well-suited to, with the user as the final check.
- **Alternatives considered**: Algorithmic idea-counting (rejected — no reliable rule);
  no enforcement (rejected — violates Principle I).

## 5. Claim sourcing & verification status (Principle II / FR-003, FR-004)

- **Decision**: Front matter carries a required `verification_status`
  (`cited` | `synthesis` | `opinion` | `unverified`) and a `sources` list; inline claims
  needing individual attribution use `[^id]` markers resolved against `sources`. The
  playbook makes Principle II non-negotiable: the agent MUST cite or explicitly label every
  factual claim and MUST NOT assert unverified information as fact, flagging uncertainty for
  the user instead.
- **Rationale**: Turns the accuracy principle into concrete, checkable note structure and a
  hard behavioural rule for the agent — the core of the NON-NEGOTIABLE principle.
- **Alternatives considered**: Free-text references only (rejected — not checkable);
  per-sentence mandatory citation (rejected — too heavy, harms SC-001 authoring speed).

## 6. Typed relations, bidirectional linking & finding connections (Principle III / FR-008..011)

- **Decision**: Relations live in front matter as `relations: [{type, target}]` with
  `target` = another note's `id` and `type` from a controlled vocabulary (`extends`,
  `contradicts`, `example-of`, `prerequisite-of`, `related`). When the agent links A→B it
  MUST also write the inverse relation on B (using the inverse label) so both ends stay
  consistent (FR-009). For "connect these scratch notes" requests, the playbook directs the
  agent to scan existing notes (titles, core ideas, tags) to find the best-fitting targets,
  propose typed relations with a one-line rationale, and report any note left orphaned.
  Dangling targets (id not found) MUST be flagged (FR-010).
- **Rationale**: The "weave scratch notes into the graph" behaviour is the user's central
  request; making the agent both write the inverse edge and explain its chosen links keeps
  the graph consistent (FR-009) and the reasoning auditable. Orphan/dangling checks are a
  scan the agent performs over `notes/`.
- **Alternatives considered**: Store edges once and *derive* the reverse only at render time
  (viable, but writing the inverse into both files keeps each note self-contained and
  greppable without a render step — preferred here given there is no build pipeline);
  untyped links (rejected — Principle III requires typed relationships).

## 7. HTML generation — a Python generator command (Principle IV / FR-012, FR-015, FR-016)

- **Decision**: A single generator `generate.py` (Python 3.12) reads all `notes/*.md`
  (front matter via `PyYAML`, body via `markdown`), renders each through a `Jinja2`
  template (`templates/note.html.j2`), and writes `site/<id>-<slug>.html` plus
  `site/index.html`, copying `assets/` (CSS + vendored Cytoscape) into `site/`. The agent
  runs it after creating or updating notes. `site/` is disposable and fully rebuilt each
  run; each page faithfully reflects its source. This drove the constitution amendment to
  v1.2.0 (HTML built by a repeatable command).
- **Rationale**: A small deterministic script gives consistent modern styling and a shared
  graph widget across all pages — which per-note hand-authoring cannot guarantee — while
  keeping Markdown canonical and the output disposable. Python + Jinja2 is a lightweight,
  readable, cross-platform choice (chosen over a stdlib-only or Node generator for clarity).
- **Alternatives considered**: Agent hand-authors each `.html` (rejected at user request —
  inconsistent, no shared graph); a heavyweight static-site generator like MkDocs/Hugo
  (rejected — more than needed and harder to control the bespoke graph/visual layout).

## 8. Visual representation — agent's choice, inline SVG preferred (Principle V / FR-014)

- **Decision**: The agent authors each note's visualization in whatever self-contained,
  offline-renderable form best fits the concept; **inline SVG is preferred** (no runtime
  required). The visual lives in the note body under a `## Visualization` section, with
  `visualization.kind` (`svg` | `html` | `image` | `summary`) declared in front matter and
  an `alt` text for accessibility. The generator embeds the visual into the page as-is.
  Genuinely non-visual concepts use `kind: summary` with structured text.
- **Rationale**: The user removed the Mermaid mandate. Inline SVG is self-contained,
  version-controllable, diff-able, and renders offline with no library — the cleanest fit
  for "agent builds it however it sees fit" plus the offline constraint.
- **Alternatives considered**: Mandated Mermaid (rejected at user request); CDN-hosted
  rendering libraries (rejected — break offline); raster images only (rejected — not
  diff-friendly, though `kind: image` remains available for photos/figures).

## 8a. Connection graph view (Principle III / FR-017a, SC-006)

- **Decision**: Each page shows an interactive connection graph in the top-right corner via
  a **vendored, pinned `cytoscape.min.js`**. The generator emits the note's local
  neighbourhood (the note + its directly connected notes, with typed edges) as graph data
  (`graph.json` or inlined), and Cytoscape renders it with hover/pan/zoom; clicking a node
  navigates to that note's page. Vendored, so it works fully offline.
- **Rationale**: Cytoscape.js is a mature, dependency-free graph library well-suited to
  clickable node navigation; the user chose an interactive graph over a static SVG.
- **Alternatives considered**: Static server-rendered SVG with `<a>` links (rejected at user
  request — no pan/zoom/hover); D3 from scratch (rejected — more effort for the same result).

## 9. Agent guidance artifacts (the deliverable)

- **Decision**: Capture behaviour in `AGENTS.md` (playbook: the operations — *mint notes
  from a dump+keywords*, *integrate scratch notes*, and *run generation* — plus the per-note
  review checklist), `CONVENTIONS.md` (id scheme, relation vocabulary + inverse labels,
  sourcing/verification, tags), and ship the generator (`generate.py`, `requirements.txt`,
  `templates/*.j2`, `assets/styles.css`, vendored `assets/cytoscape.min.js`). Wire
  `CLAUDE.md` to point the agent at these each session.
- **Rationale**: These files are what make the AI behave as the spec requires, session after
  session — the no-code equivalent of an implementation.
- **Alternatives considered**: Relying on ad-hoc prompts each time (rejected — not
  reproducible, would drift from the constitution).

## Open questions

None. Out-of-scope items (multi-author, hosting, full-text/semantic search) remain in the
spec's Assumptions and are not part of this plan.
