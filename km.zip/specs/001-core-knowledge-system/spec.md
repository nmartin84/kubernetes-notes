# Feature Specification: Core Knowledge System

**Feature Branch**: `001-core-knowledge-system`

**Created**: 2026-06-25

**Status**: Draft

**Input**: User description: "Rich knowledge management focused on accuracy. Create
concepts as atomic notes (Zettelkasten). Each note holds the core idea plus its
relationships to other notes (PKM). Store rich data as Markdown, generate an HTML page
per note, and include a section that illustrates the concept visually."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Capture a single idea as an atomic note (Priority: P1)

A knowledge worker has just learned or synthesized one idea. They create a note that
holds exactly that one idea, written in their own words, with the supporting context
that makes it precise. They attach the source(s) the idea came from, or explicitly mark
the parts that are their own synthesis or are not yet verified. The system gives the
note a stable identifier and records when it was created, so the idea can be found and
referenced later without ambiguity.

**Why this priority**: A note is the atomic unit of the entire system. Until an author
can reliably capture one accurate, well-formed idea, nothing else (linking, publishing,
visualizing) has anything to operate on. This story alone delivers a trustworthy,
searchable store of single-idea notes — a usable product on its own.

**Independent Test**: Can be fully tested by authoring several notes — including one
that mixes two ideas and one that asserts an uncited claim — and confirming the system
flags the multi-idea note, requires the claim to be cited or labelled, assigns a stable
ID, and stores the note as a self-contained, human-readable record.

**Acceptance Scenarios**:

1. **Given** an author with a single idea, **When** they create a note containing the
   core idea, its elaboration, at least one source, and tags, **Then** the system
   stores it with a unique stable identifier and creation date and the note is
   retrievable by that identifier.
2. **Given** a draft note that contains two unrelated ideas, **When** the author tries
   to mark it complete, **Then** the system flags it as violating atomicity and the note
   cannot be accepted until split.
3. **Given** a note asserting a factual claim with no source, **When** the author tries
   to mark it complete, **Then** the system requires the claim to be either cited or
   explicitly labelled as unverified/opinion before acceptance.
4. **Given** an existing note, **When** the author edits its title or wording, **Then**
   its identifier does not change.

---

### User Story 2 - Connect a note to related knowledge (Priority: P2)

Having captured several atomic notes, the author connects an idea to the others it
relates to — what it extends, what it contradicts, what it is an example of, what it
depends on. Each connection states the *kind* of relationship. When the author links
note A to note B, the relationship is visible from both notes. The author can see, from
any note, the web of ideas around it, and can spot notes that have drifted into
isolation.

**Why this priority**: Connections are what turn a pile of notes into knowledge. They
depend on notes existing (US1), so they come second — but they are the core
differentiator that makes the repository more than a folder of files.

**Independent Test**: Can be tested by linking two existing notes with a typed
relationship and confirming the connection appears on both notes, that linking to a
non-existent note is prevented or flagged, and that notes with no connections are
reported as orphans.

**Acceptance Scenarios**:

1. **Given** two existing notes, **When** the author adds a typed relationship from one
   to the other, **Then** the relationship appears in the relations section of both
   notes with its type.
2. **Given** a note that references an identifier that does not exist, **When** the
   author marks the note complete, **Then** the system flags the dangling reference.
3. **Given** a set of notes, **When** the author requests a list of unconnected notes,
   **Then** the system returns every note that has no relationships.
4. **Given** a relationship between two notes, **When** the author removes it from one
   note, **Then** it is removed from the other note as well.

---

### User Story 3 - Publish browsable, illustrated pages (Priority: P3)

The author turns the knowledge base into something they can browse and share. After
creating or updating notes, the author runs a single generation command that (re)builds
one web page per note from the plain-text source notes. Each page has a clean, modern,
consistent look and shows the note's idea, its sources, clickable links to its related
notes, and a visual representation of the concept (whatever form best fits it). In the
top-right corner, each page shows an interactive graph of the current note and the notes
it connects to; the reader can click a node in that graph to navigate to that note's
page. The author never edits the generated pages to change content; they change the
source note and re-run generation, so every page faithfully reflects its current source.

**Why this priority**: Publishing makes the accumulated, connected knowledge consumable
and shareable. It depends on notes (US1) and ideally their connections (US2), so it is
the last slice — valuable, but not required for the knowledge itself to exist and be
trusted.

**Independent Test**: Can be tested by running the generation command over a small set of
linked notes and confirming each note yields a styled, browsable page with working links
to related notes, an embedded visual, and a clickable top-right connection graph; that
each page faithfully reflects its source note; and that an edit to a source note is
reflected after re-running generation.

**Acceptance Scenarios**:

1. **Given** a set of source notes, **When** the author runs the generation command,
   **Then** the system produces one browsable page per note, with a consistent modern
   style, containing the core idea, sources, relations, and a visual representation.
2. **Given** a published note that links to another note, **When** a reader opens the
   page and follows the link, **Then** they arrive at the related note's page.
6. **Given** a published page, **When** a reader views the connection graph in the
   top-right corner and clicks a connected note's node, **Then** they navigate to that
   note's page.
3. **Given** a published page, **When** it is deleted, **Then** it can be re-derived from
   its source note with no loss of the note's knowledge.
4. **Given** a note whose source has been edited, **When** its page is re-derived,
   **Then** the regenerated page reflects the edit.
5. **Given** a concept that cannot be meaningfully diagrammed, **When** the page is
   generated, **Then** it includes a structured summary in place of a diagram rather
   than an empty visual section.

---

### Edge Cases

- What happens when an author deletes a note that other notes link to? The linking notes
  must surface the now-dangling relationship rather than silently breaking.
- How does the system handle two notes claiming the same identifier? Identifiers must be
  unique; a collision must be prevented at creation.
- What happens when a source note's visual specification is malformed? Publication must
  report the affected note rather than producing a broken or empty page.
- How does the system handle a factual claim whose cited source is later found to
  contradict it? The note must be correctable and the correction recorded.
- What happens to a generated page if its source note is removed? The stale page must
  not persist as a misleading orphan after republication.

## Requirements *(mandatory)*

### Functional Requirements

**Authoring atomic notes (US1)**

- **FR-001**: System MUST allow an author to create a note capturing exactly one idea.
- **FR-002**: System MUST assign each note a unique, stable identifier that does not
  change when the note's title or content changes, and MUST never reuse an identifier.
- **FR-003**: System MUST capture, for each note, at minimum: the core idea, supporting
  elaboration/context, sources or references, tags, a creation date, a last-updated
  date, and a verification status.
- **FR-004**: System MUST require every factual claim in a note to be either traceable
  to a cited source or explicitly labelled as the author's synthesis/opinion or as
  unverified, and MUST prevent a note that mixes unattributed fact with speculation from
  being marked complete.
- **FR-005**: System MUST flag a note that contains more than one distinct idea as
  violating atomicity and prevent it from being accepted until split.
- **FR-006**: System MUST store each note as a self-contained, human-readable source
  record that can be understood without reading neighbouring notes.
- **FR-007**: System MUST allow notes to be retrieved by identifier and by tag.

**Connecting notes (US2)**

- **FR-008**: System MUST allow an author to declare relationships from one note to
  other notes, each relationship carrying a type (e.g., extends, contradicts,
  example-of, prerequisite-of).
- **FR-009**: System MUST present a relationship on both the originating and the target
  note, keeping the connection bidirectionally consistent when it is added or removed.
- **FR-010**: System MUST detect and flag any relationship that references a
  non-existent note (a dangling link).
- **FR-011**: System MUST be able to report notes that have no relationships (orphans).

**Publishing & visualizing (US3)**

- **FR-012**: System MUST provide a single generation command that (re)builds one
  browsable page per note from the source notes; the author runs it after creating or
  updating notes.
- **FR-013**: Each generated page MUST present the note's core idea, its sources, and
  navigable links to its related notes.
- **FR-014**: Each generated page MUST include a visual representation of the concept in
  whatever self-contained form the author/agent chooses (no specific diagram tool is
  required); when the concept cannot be meaningfully visualized, a structured summary
  MUST be shown in its place.
- **FR-015**: Each generated page MUST faithfully reflect its note's current source and
  be re-derivable from that source at any time; no knowledge may exist only in a page.
- **FR-016**: System MUST treat generated pages as disposable artifacts: content is
  changed in the source note, never by hand-editing the page; re-running generation MUST
  reflect source edits, and a page whose source note was deleted MUST be removed.
- **FR-017a**: Each generated page MUST display, in the top-right corner, an interactive
  graph of the current note and the notes it is connected to, where clicking a connected
  node navigates to that note's page.
- **FR-017b**: Generated pages MUST share a consistent, modern visual style.

**Accuracy & integrity (cross-cutting)**

- **FR-017**: System MUST allow a note to be corrected when a source is found to
  contradict it, and MUST record that the note was updated (via the last-updated date).

### Key Entities *(include if feature involves data)*

- **Note**: The atomic unit of knowledge — one idea, with its core statement,
  elaboration, sources, relations, visualization, and metadata.
- **Identifier**: The stable, unique handle for a note; durable across edits.
- **Relation**: A typed, directional connection between two notes that is reflected on
  both ends.
- **Source/Reference**: A citation backing a factual claim in a note.
- **Visualization**: The visual representation of a note's concept (diagram, map, or
  illustration), authored alongside the note's source.
- **Verification Status**: A note-level label indicating whether its claims are cited,
  author synthesis/opinion, or unverified.
- **Generated Page**: The browsable, derived output produced from a note's source.
- **Tag**: A label used to group and retrieve related notes.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: An author can capture a new single-idea note, complete with sources and
  metadata, in under 5 minutes.
- **SC-002**: 100% of notes accepted as complete have every factual claim either cited
  or explicitly labelled, with zero unattributed factual claims.
- **SC-003**: 100% of relationships are visible from both connected notes; no
  one-directional or dangling links remain in an accepted knowledge base.
- **SC-004**: Every published note page includes the core idea, its sources, working
  links to all of its related notes, and a visual (or a structured summary substitute).
- **SC-005**: 100% of generated pages can be deleted and re-derived from their source
  notes with no loss of the notes' knowledge, and every page reflects its current source.
- **SC-006**: From any published note, a reader can reach any directly related note in a
  single click — via either an inline relation link or the top-right connection graph.
- **SC-007**: An author can locate any existing note by its identifier or a tag in under
  10 seconds.

## Assumptions

- The primary user is an individual knowledge worker authoring their own notes
  (personal knowledge management); multi-author concurrent editing is out of scope for
  this feature.
- The "system" is an AI agent operating directly on this repository (e.g., via an
  in-repo coding agent): the user supplies knowledge and keywords in a prompt, and the
  agent authors notes (each with a visualization of its choosing) and connects them to
  existing notes. The agent then runs a single generation command/script to (re)build the
  HTML site. That generation command is the only executable artifact — there is no larger
  application or interactive CLI; the other deliverables are conventions, templates, and
  an agent playbook.
- Canonical knowledge is stored as human-readable plain-text source (Markdown), and the
  browsable output is web pages (HTML) — these are product requirements stated by the
  user, not incidental technical choices, and are therefore named here. HTML pages are
  produced by the generation command and are faithful, regenerable renderings of the
  Markdown (byte-for-byte reproducibility is not required).
- The per-note visualization form is the author/agent's choice (inline SVG preferred for
  offline self-containment); no specific diagram tool is mandated.
- The recommended visual format is the one named in the project constitution; the spec
  treats "a visual representation" generically and defers the specific format to
  planning.
- Notes, their relationships, and generated output all live within a single repository;
  external/remote knowledge bases are out of scope for this feature.
- Access control, authentication, and publishing/hosting of the generated pages beyond
  producing the files are out of scope for this feature.
- Search is satisfied by retrieval via identifier and tag; full-text or semantic search
  is out of scope for this feature.
