---
description: "Task list for Core Knowledge System implementation"
---

# Tasks: Core Knowledge System

**Input**: Design documents from `specs/001-core-knowledge-system/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/, quickstart.md

**Tests**: No unit-test suite. The agent authors notes; a small Python generator builds the
site. Each user story ends with a **manual validation task** that drives the agent/generator
and inspects the output, per `quickstart.md`.

**Organization**: Tasks are grouped by user story (US1–US3). Deliverables: the **generator**
(`generate.py` + `templates/*.j2` + `assets/`), the **agent guidance** (`AGENTS.md`,
`CONVENTIONS.md`), and the **notes**.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: US1, US2, US3
- Paths are repo-root-relative.

## Path Conventions

Hybrid repo: agent-authored content + a small generator. Deliverables at the repo root:
`AGENTS.md`, `CONVENTIONS.md`, `README.md`, `generate.py`, `requirements.txt`, `templates/`,
`assets/`, `notes/` (canonical), `site/` (generated, disposable).

---

## Phase 1: Setup (Shared Infrastructure)

- [ ] T001 Create the repo skeleton: `notes/` (with `notes/.gitkeep`), `templates/`, and `assets/` directories at the repo root
- [ ] T002 [P] Create `requirements.txt` (markdown, PyYAML, Jinja2) and a `README.md` skeleton stating the purpose (AI-authored Zettelkasten + a `python generate.py` site generator) with placeholder "Prompt patterns" and "Build the site" sections
- [ ] T003 [P] Add a non-SPECKIT pointer in `CLAUDE.md` instructing the agent to load `AGENTS.md` and `CONVENTIONS.md` every session

---

## Phase 2: Foundational (Blocking Prerequisites)

**⚠️ CRITICAL**: No user story work can begin until this phase is complete.

- [ ] T004 [P] Create `CONVENTIONS.md`: id scheme (`YYYYMMDDHHMMSS`), relation vocabulary with inverse labels (`extends`↔`extended-by`, `contradicts`↔`contradicts`, `example-of`↔`has-example`, `prerequisite-of`↔`requires`, `related`↔`related`), `verification_status` + sourcing rules, tag guidance, and **visualization guidance** (agent's choice; inline SVG preferred; visual content lives in a `## Visualization` body section; front matter declares `visualization: {kind, alt}`) — per `data-model.md` and `research.md`
- [ ] T005 [P] Create `templates/note.md`: canonical atomic-note skeleton with YAML front matter conforming to `contracts/note-frontmatter.schema.json` (incl. `visualization: {kind, alt}`) and body sections (Core Idea, Elaboration, Visualization, Sources, Connections)
- [ ] T006 Create `AGENTS.md` shell: repo map, the five constitution principles (v1.2.0) as operating rules, the per-note **review checklist** (atomicity; every claim cited or labelled; ≥1 typed relation or justified orphan; a self-contained visual or summary; required metadata), and empty stubs for Operations A–E (references T004 + T005)

**Checkpoint**: Note format + conventions + playbook shell ready.

---

## Phase 3: User Story 1 - Capture a single idea as an atomic note (Priority: P1) 🎯 MVP

**Goal**: The agent turns a knowledge dump + keywords into well-formed, accurate, atomic Markdown notes, each with a self-contained visual.

**Independent Test**: quickstart Scenario A — atomic, cited/labelled, stable id, schema-valid front matter, incl. unsourced-claim and two-idea negative checks.

- [ ] T007 [US1] Write the "Operation A — Mint notes from a knowledge dump" section in `AGENTS.md`: decompose input into atomic ideas, assign `id`, fill `templates/note.md`, map keywords→tags, cite or label every claim, author a **self-contained visualization (inline SVG preferred)** in the `## Visualization` section, then check id collisions — per `contracts/agent-operations.md` Operation A
- [ ] T008 [P] [US1] Create a seed exemplar note `notes/20260625-100000-spaced-repetition.md` with full anatomy: one core idea, a cited source, tags, ISO dates, `verification_status: cited`, and an **inline-SVG** `## Visualization`
- [ ] T009 [US1] Validate US1 against quickstart **Scenario A**; record results

**Checkpoint**: US1 functional — a trustworthy store of atomic Markdown notes (usable MVP even before the site is generated).

---

## Phase 4: User Story 2 - Connect a note to related knowledge (Priority: P2)

**Goal**: The agent links notes with typed relations written on both ends, reporting orphans/dangling.

**Independent Test**: quickstart Scenario B — typed relations on both ends, per-connection rationale, orphan reporting, dangling-link flag.

- [ ] T010 [US2] Write the "Operation B — Integrate scratch notes" and "Operation C — Link/relate notes" sections in `AGENTS.md`: scan existing `notes/`, propose best-fitting typed relations with rationale, write the inverse on the target, report orphans, flag dangling targets — per `contracts/agent-operations.md` Operations B/C
- [ ] T011 [P] [US2] Create a second exemplar note `notes/20260625-100500-testing-effect.md` and link it to the spaced-repetition note (T008) with a typed relation written on **both** files (depends on T008)
- [ ] T012 [US2] Validate US2 against quickstart **Scenario B**; record results

**Checkpoint**: US1 + US2 form a consistent, typed knowledge graph.

---

## Phase 5: User Story 3 - Generate the styled site with connection graph (Priority: P3)

**Goal**: A single command builds a modern, consistent HTML site from the notes, each page embedding its visual and an interactive top-right connection graph that clicks through to related notes.

**Independent Test**: quickstart Scenarios C & D — run `python generate.py`; pages are styled, links + top-right graph navigate, visuals render offline, and re-running reflects edits/deletions.

- [ ] T013 [US3] Create `generate.py`: read all `notes/*.md` (front matter via PyYAML, body via markdown), render each through `templates/note.html.j2` to `site/<id>-<slug>.html`, build `site/index.html`, and copy `assets/` → `site/assets/`; fully rebuild `site/` each run (drop pages for deleted notes) — per `contracts/agent-operations.md` Operation D
- [ ] T014 [P] [US3] Create `templates/note.html.j2` (modern layout: core idea, elaboration, sources, relation links, embedded `## Visualization`, and a top-right graph mount) and `templates/index.html.j2` (overview/landing)
- [ ] T015 [P] [US3] Create `assets/styles.css` — a clean, modern, consistent visual style for all pages (FR-017b)
- [ ] T016 [US3] Vendor a pinned `assets/cytoscape.min.js`; in `generate.py` emit each note's local connection-graph data (the note + directly connected notes, with typed edges) and wire the top-right Cytoscape mount with click-to-navigate (FR-017a, SC-006) — depends on T013, T014
- [ ] T017 [US3] Write the "Operation D — Generate the site" section in `AGENTS.md`: run `python generate.py` after creating/updating notes; `site/` is disposable and faithful to source — per `contracts/agent-operations.md` Operation D
- [ ] T018 [P] [US3] Migrate the existing black-hole notes in `notes/` (the test-run set) from Mermaid front-matter visuals to inline SVG in a `## Visualization` body section with `visualization: {kind: svg, alt}`
- [ ] T019 [US3] Validate US3 against quickstart **Scenarios C & D**: run generation over the exemplar + black-hole notes; verify styling, inline-link and top-right-graph navigation, offline visuals, and that a re-run reflects an edit and a deletion. Record results.

**Checkpoint**: All three user stories independently functional; the site is browsable.

---

## Phase 6: Polish & Cross-Cutting Concerns

- [ ] T020 [P] Fill in the `README.md` "Prompt patterns" and "Build the site" sections (the "make notes" and "connect these" recipes; `python generate.py`; how to open `site/index.html` offline)
- [ ] T021 [P] Write the "Operation E — Find/retrieve" section in `AGENTS.md` (locate notes by `id` or `tag` via a front-matter/filename scan) — FR-007 / SC-007
- [ ] T022 Run the full `quickstart.md` (Scenarios A–E) and confirm every Success Criterion SC-001–SC-007; fix any gaps
- [ ] T023 [P] Final constitution compliance review (v1.2.0) across `AGENTS.md`, `CONVENTIONS.md`, `generate.py`, `templates/`, `assets/`, and the notes

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)** → **Foundational (Phase 2, BLOCKS all stories)** → **User Stories (3–5)** → **Polish (6)**.

### User Story Dependencies

- **US1 (P1)**: after Foundational. No dependency on other stories.
- **US2 (P2)**: after Foundational. T011 links to US1's exemplar (T008).
- **US3 (P3)**: after Foundational. `generate.py` (T013) needs notes to exist to render; the graph wiring (T016) depends on T013+T014. US3 renders US1/US2 exemplars and the migrated black-hole notes.

### Within Each User Story

- `AGENTS.md` is one file edited once per story (T006 → T007 → T010 → T017 → T021): sequential, never [P] with each other.
- Conventions/templates before generator; generator before graph wiring; everything before validation.

### Parallel Opportunities

- Setup: T002, T003.
- Foundational: T004, T005 (T006 after).
- US1: T007 ∥ T008.
- US3: T014 ∥ T015; T016 after T013+T014; T018 ∥ the generator tasks (it edits notes, not generator files).
- Polish: T020, T021, T023.

---

## Implementation Strategy

### MVP First (User Story 1 only)

1. Setup → 2. Foundational → 3. US1 (atomic, accurate Markdown notes) → **STOP and VALIDATE** (Scenario A). Usable knowledge base even before the site exists.

### Incremental Delivery

1. Setup + Foundational → format & playbook ready.
2. US1 → trustworthy atomic notes (MVP).
3. US2 → typed, bidirectional graph.
4. US3 → styled site + interactive connection graph via `python generate.py`.
5. Polish → retrieval, prompt docs, full validation.

---

## Notes

- The only executable artifact is `generate.py`; everything else is content/guidance.
- Accuracy (Principle II) is non-negotiable: cite or label every claim; never assert unverified info as fact.
- Markdown is canonical; `site/` is disposable and rebuilt by `python generate.py`.
- Visuals are the agent's choice, self-contained, offline (inline SVG preferred); the top-right graph uses vendored Cytoscape.js.
- Commit after each task or logical group; stop at any checkpoint to validate a story.
